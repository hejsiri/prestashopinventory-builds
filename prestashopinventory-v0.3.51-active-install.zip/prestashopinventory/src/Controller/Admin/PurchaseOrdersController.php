<?php
declare(strict_types=1);

namespace PrestaShop\Module\PrestashopInventory\Controller\Admin;

require_once dirname(__DIR__, 3) . '/classes/PrestashopInventoryService.php';

use PrestaShopBundle\Security\Annotation\AdminSecurity;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

class PurchaseOrdersController extends AbstractInventoryController
{
    /**
     * @AdminSecurity("is_granted('read', request.get('_legacy_controller'))")
     */
    public function indexAction(Request $request): Response
    {
        $module = \Module::getInstanceByName('prestashopinventory');
        $context = \Context::getContext();
        $purchaseOrders = [];
        $selectedOrder = null;
        $messages = [];
        $errors = [];

        if ($module instanceof \Module) {
            if ($module instanceof \PrestashopInventory) {
                $module->ensureTabsAvailable();
            }

            $service = new \PrestashopInventoryService($module->getLocalPath(), $context, $module);
            $service->ensurePurchaseOrderInfrastructure();

            if ($request->isMethod('POST')) {
                try {
                    if (\Tools::isSubmit('submitPrestashopInventoryCreatePurchaseOrder')) {
                        $idPurchaseOrder = $service->createPurchaseOrder();

                        return $this->redirectToRoute('prestashop_inventory_purchase_orders', [
                            'id_purchase_order' => $idPurchaseOrder,
                            'purchase_order_status' => 'created',
                        ]);
                    }

                    if (\Tools::isSubmit('submitPrestashopInventorySavePurchaseOrder')) {
                        $idPurchaseOrder = (int) \Tools::getValue('id_purchase_order');
                        $service->savePurchaseOrder($idPurchaseOrder, $request->request->all());

                        return $this->redirectToRoute('prestashop_inventory_purchase_orders', [
                            'id_purchase_order' => $idPurchaseOrder,
                            'purchase_order_status' => 'saved',
                        ]);
                    }

                    if (\Tools::isSubmit('submitPrestashopInventoryDeletePurchaseOrder')) {
                        $service->deletePurchaseOrder((int) \Tools::getValue('id_purchase_order'));

                        return $this->redirectToRoute('prestashop_inventory_purchase_orders', [
                            'purchase_order_status' => 'deleted',
                        ]);
                    }

                    if (\Tools::isSubmit('submitPrestashopInventoryDeletePurchaseOrderItem')) {
                        $idPurchaseOrder = (int) \Tools::getValue('id_purchase_order');
                        $service->deletePurchaseOrderItem(
                            (int) \Tools::getValue('id_purchase_order_item'),
                            $idPurchaseOrder
                        );

                        return $this->redirectToRoute('prestashop_inventory_purchase_orders', [
                            'id_purchase_order' => $idPurchaseOrder,
                            'purchase_order_status' => 'item_deleted',
                        ]);
                    }

                    if (\Tools::isSubmit('submitPrestashopInventoryUploadPurchaseOrderFile')) {
                        $idPurchaseOrder = (int) \Tools::getValue('id_purchase_order');
                        $service->uploadPurchaseOrderFile(
                            $idPurchaseOrder,
                            $_FILES['purchase_order_file'] ?? [],
                            (string) \Tools::getValue('purchase_order_file_description', '')
                        );

                        return $this->redirectToRoute('prestashop_inventory_purchase_orders', [
                            'id_purchase_order' => $idPurchaseOrder,
                            'purchase_order_status' => 'file_uploaded',
                        ]);
                    }

                    if (\Tools::isSubmit('submitPrestashopInventoryDeletePurchaseOrderFile')) {
                        $idPurchaseOrder = (int) \Tools::getValue('id_purchase_order');
                        $service->deletePurchaseOrderFile(
                            (int) \Tools::getValue('id_purchase_order_file'),
                            $idPurchaseOrder
                        );

                        return $this->redirectToRoute('prestashop_inventory_purchase_orders', [
                            'id_purchase_order' => $idPurchaseOrder,
                            'purchase_order_status' => 'file_deleted',
                        ]);
                    }
                } catch (\Throwable $e) {
                    $errors[] = $e->getMessage() !== '' ? $e->getMessage() : 'Nie udało się zapisać zamówienia.';
                }
            }

            $status = (string) $request->query->get('purchase_order_status', '');
            if ($status === 'created') {
                $messages[] = 'Nowe zamówienie zostało utworzone.';
            } elseif ($status === 'saved') {
                $messages[] = 'Zamówienie zostało zapisane.';
            } elseif ($status === 'deleted') {
                $messages[] = 'Zamówienie zostało usunięte.';
            } elseif ($status === 'item_deleted') {
                $messages[] = 'Pozycja zamówienia została usunięta.';
            } elseif ($status === 'file_uploaded') {
                $messages[] = 'Plik został dodany do zamówienia.';
            } elseif ($status === 'file_deleted') {
                $messages[] = 'Plik został usunięty z zamówienia.';
            }

            $purchaseOrders = array_map(function (array $order): array {
                $detailUrl = $this->generateUrl('prestashop_inventory_purchase_orders', [
                    'id_purchase_order' => (int) ($order['id_purchase_order'] ?? 0),
                ]);

                $order['detail_url'] = $detailUrl;
                $order['preview_url'] = $detailUrl;
                $order['share_url'] = 'mailto:?subject=' . rawurlencode('Zamówienie ' . (string) ($order['number'] ?? '')) . '&body=' . rawurlencode($detailUrl);

                return $order;
            }, $service->getPurchaseOrders());

            $selectedOrderId = (int) $request->query->get('id_purchase_order', (int) \Tools::getValue('id_purchase_order', 0));
            if ($selectedOrderId > 0) {
                try {
                    $selectedOrder = $service->getPurchaseOrder($selectedOrderId);
                } catch (\Throwable $e) {
                    $errors[] = $e->getMessage() !== '' ? $e->getMessage() : 'Nie znaleziono zamówienia.';
                }
            }
        }

        return $this->renderInventoryPage(
            '@Modules/prestashopinventory/views/templates/admin-modern/purchase_orders.html.twig',
            'prestashop_inventory_purchase_orders',
            'purchase_orders_tab',
            [
                'purchaseOrders' => $purchaseOrders,
                'selectedOrder' => $selectedOrder,
                'purchaseOrderMessages' => $messages,
                'purchaseOrderErrors' => $errors,
                'purchaseOrdersUrl' => $this->generateUrl('prestashop_inventory_purchase_orders'),
            ]
        );
    }
}
