<div class="inventory-module-content{if !empty($prestashopInventoryEmbeddedInModernLayout)} inventory-module-content--embedded{/if}">
{if empty($prestashopInventoryEmbeddedInModernLayout)}
<div id="psinventory-config-head-tabs-source" class="page-head-tabs inventory-panel-tabs" role="tablist" aria-label="{$prestashopInventoryTranslations.module_navigation|escape:'html':'UTF-8'}">
  <ul class="nav nav-pills">
    <li class="nav-item">
      <a href="{$prestashopInventoryBackUrl|escape:'html':'UTF-8'}" class="nav-link" role="tab"><span class="inventory-tab-link-content"><span class="menu-icon material-icons" aria-hidden="true">list_alt</span><span>{$prestashopInventoryTranslations.products_tab|escape:'html':'UTF-8'}</span></span></a>
    </li>
    <li class="nav-item">
      <a href="{$prestashopInventorySuppliersUrl|escape:'html':'UTF-8'}" class="nav-link" role="tab"><span class="inventory-tab-link-content"><span class="menu-icon material-icons" aria-hidden="true">local_shipping</span><span>{$prestashopInventoryTranslations.suppliers_tab|escape:'html':'UTF-8'}</span></span></a>
    </li>
    <li class="nav-item">
      <a href="{$prestashopInventoryPurchaseOrdersUrl|escape:'html':'UTF-8'}" class="nav-link" role="tab"><span class="inventory-tab-link-content"><span class="menu-icon material-icons" aria-hidden="true">inventory_2</span><span>{$prestashopInventoryTranslations.purchase_orders_tab|escape:'html':'UTF-8'}</span></span></a>
    </li>
    <li class="nav-item">
      <a href="{$prestashopInventoryConfigAction|escape:'html':'UTF-8'}" class="router-link-active router-link-exact-active nav-link active" aria-current="page" role="tab"><span class="inventory-tab-link-content"><span class="menu-icon material-icons" aria-hidden="true">settings</span><span>{$prestashopInventoryTranslations.settings_tab|escape:'html':'UTF-8'}</span></span></a>
    </li>
  </ul>
  <div class="inventory-update-meta">
    <div class="inventory-update-meta-status"></div>
  </div>
</div>
{/if}
{foreach from=$prestashopInventoryMessages item=message}
  <div class="alert alert-success">{$message|escape:'html':'UTF-8'}</div>
{/foreach}

{foreach from=$prestashopInventoryErrors item=errorMessage}
  <div class="alert alert-danger">{$errorMessage|escape:'html':'UTF-8'}</div>
{/foreach}

<div class="card js-grid-panel prestashopinventory-config-list">
  <div class="card-header js-grid-header">
    <h3 class="d-inline-block card-header-title">Informacje o module</h3>
  </div>
  <div class="card-body">
    <div class="inventory-settings-meta">
      <div class="inventory-settings-meta-grid">
        <div class="inventory-settings-meta-item">
          <div class="inventory-settings-meta-label">Wersja modułu</div>
          <div class="inventory-settings-meta-value">{$prestashopInventoryModuleVersion|escape:'html':'UTF-8'}</div>
        </div>

        <div class="inventory-settings-meta-item">
          <div class="inventory-settings-meta-label">Licencja dla</div>
          <div class="inventory-settings-meta-value">{$prestashopInventoryLicenseSummary.customer|escape:'html':'UTF-8'}</div>
        </div>

        <div class="inventory-settings-meta-item">
          <div class="inventory-settings-meta-label">Domena</div>
          <div class="inventory-settings-meta-value">{$prestashopInventoryLicenseSummary.domain|escape:'html':'UTF-8'}</div>
        </div>

        <div class="inventory-settings-meta-item">
          <div class="inventory-settings-meta-label">Wygasa</div>
          <div class="inventory-settings-meta-value">{$prestashopInventoryLicenseSummary.expires_at|escape:'html':'UTF-8'}</div>
        </div>
      </div>

      {if !$prestashopInventoryLicenseStatus.valid}
        <div class="alert alert-danger inventory-settings-license-alert" role="alert">
          <strong>{$prestashopInventoryTranslations.license_required_title|escape:'html':'UTF-8'}:</strong>
          <span>{$prestashopInventoryLicenseStatus.message|escape:'html':'UTF-8'}</span>
        </div>
      {/if}
    </div>
  </div>
</div>

<div class="card js-grid-panel prestashopinventory-config-list">
  <div class="card-header js-grid-header">
    <h3 class="d-inline-block card-header-title">Lista ukrytych produktów</h3>
  </div>
  <div class="card-body">
    {if $prestashopInventoryIgnoredProducts}
      <div class="table-responsive-row clearfix">
        <table class="grid-table js-grid-table table">
          <thead class="thead-default">
            <tr>
              <th>ID</th>
              <th>{$prestashopInventoryTranslations.image|escape:'html':'UTF-8'}</th>
              <th>{$prestashopInventoryTranslations.product_name|escape:'html':'UTF-8'}</th>
              <th>{$prestashopInventoryTranslations.ean13|escape:'html':'UTF-8'}</th>
              <th class="text-center">{$prestashopInventoryTranslations.displayed|escape:'html':'UTF-8'}</th>
              <th class="text-center">{$prestashopInventoryTranslations.actions|escape:'html':'UTF-8'}</th>
            </tr>
          </thead>
          <tbody>
            {foreach from=$prestashopInventoryIgnoredProducts item=product}
              <tr>
                <td>{$product.id_product|intval}</td>
                <td>
                  {if $product.image_url}
                    <img src="{$product.image_url|escape:'html':'UTF-8'}" alt="" class="img-thumbnail">
                  {else}
                    <span class="text-muted">{$prestashopInventoryTranslations.no_image|escape:'html':'UTF-8'}</span>
                  {/if}
                </td>
                <td>{$product.product_name|escape:'html':'UTF-8'}</td>
                <td>{$product.ean13|escape:'html':'UTF-8'}</td>
                <td class="text-center">
                  <div class="ps-switch ps-switch-sm ps-switch-nolabel ps-switch-center">
                    <input type="radio" name="hidden_product_active_{$product.id_product|intval}" id="hidden_product_active_{$product.id_product|intval}_off" value="0" {if !$product.active}checked{/if} disabled>
                    <label for="hidden_product_active_{$product.id_product|intval}_off">Off</label>
                    <input type="radio" name="hidden_product_active_{$product.id_product|intval}" id="hidden_product_active_{$product.id_product|intval}_on" value="1" {if $product.active}checked{/if} disabled>
                    <label for="hidden_product_active_{$product.id_product|intval}_on">On</label>
                    <span class="slide-button"></span>
                  </div>
                </td>
                <td class="text-center">
                  <form method="post" action="{$prestashopInventoryConfigAction|escape:'html':'UTF-8'}" class="mb-0">
                    <input type="hidden" name="id_product" value="{$product.id_product|intval}">
                    <button type="submit" name="submitPrestashopInventoryRestoreHidden" class="btn btn-outline-secondary btn-sm">
                      <i class="icon-undo"></i> {$prestashopInventoryTranslations.restore|escape:'html':'UTF-8'}
                    </button>
                  </form>
                </td>
              </tr>
            {/foreach}
          </tbody>
        </table>
      </div>
    {else}
      <p class="alert alert-info">{$prestashopInventoryTranslations.hidden_products_empty|escape:'html':'UTF-8'}</p>
    {/if}
  </div>
</div>

<form method="post" action="{$prestashopInventoryConfigAction|escape:'html':'UTF-8'}" class="prestashopinventory-settings-form">
  <div class="card js-grid-panel prestashopinventory-config-list">
    <div class="card-header js-grid-header">
      <h3 class="d-inline-block card-header-title">Ustawienia zamówień</h3>
    </div>
    <div class="card-body">
      <div class="form-group mb-0">
        <label for="prestashopInventoryDeliveryAddress">Adres dostawy</label>
        <textarea
          id="prestashopInventoryDeliveryAddress"
          name="prestashopInventoryDeliveryAddress"
          class="form-control"
          rows="5"
          placeholder="Wpisz domyślny adres dostawy dla zamówień"
        >{$prestashopInventoryDeliveryAddress|escape:'html':'UTF-8'}</textarea>
      </div>
    </div>
  </div>

  <div class="card js-grid-panel prestashopinventory-config-list">
    <div class="card-header js-grid-header">
      <div class="prestashopinventory-order-status-panel-head">
        <div>
          <h3 class="d-inline-block card-header-title">Statusy zamówień</h3>
          <p class="text-muted mb-0">Kolejność z tej listy będzie używana na osi statusów oraz w zmianie statusu zamówienia.</p>
        </div>
        <button type="button" class="btn btn-outline-secondary btn-sm" id="prestashopInventoryAddOrderStatus">Dodaj status</button>
      </div>
    </div>
    <div class="card-body">
      <div class="table-responsive">
        <table class="table mb-0 prestashopinventory-order-status-table">
          <thead class="thead-default">
            <tr>
              <th>Status</th>
              <th>Kolor plakietki</th>
              <th>Podgląd</th>
              <th class="text-right">Akcje</th>
            </tr>
          </thead>
          <tbody id="prestashopInventoryOrderStatusRows">
            {foreach from=$prestashopInventoryOrderStatuses item=status name=orderStatuses}
              <tr class="prestashopinventory-order-status-row">
                <td class="prestashopinventory-order-status-main">
                  <input type="hidden" name="prestashopInventoryOrderStatuses[{$smarty.foreach.orderStatuses.index|intval}][key]" value="{$status.key|escape:'html':'UTF-8'}" class="js-order-status-key">
                  <input
                    type="text"
                    name="prestashopInventoryOrderStatuses[{$smarty.foreach.orderStatuses.index|intval}][label]"
                    value="{$status.label|escape:'html':'UTF-8'}"
                    class="form-control js-order-status-label"
                    placeholder="np. Wysłane"
                  >
                </td>
                <td>
                  <div class="prestashopinventory-status-color-field">
                    <div class="prestashopinventory-status-color-line">
                      <div class="prestashopinventory-status-swatches">
                        <label class="prestashopinventory-status-choice" title="Szary">
                          <input type="radio" name="prestashopInventoryOrderStatuses[{$smarty.foreach.orderStatuses.index|intval}][color_mode]" value="#B7C1CB" class="prestashopinventory-status-choice-input" {if $status.color == '#B7C1CB'}checked{/if}>
                          <span class="prestashopinventory-status-swatch" style="background-color: #B7C1CB;"></span>
                        </label>
                        <label class="prestashopinventory-status-choice" title="Czerwony">
                          <input type="radio" name="prestashopInventoryOrderStatuses[{$smarty.foreach.orderStatuses.index|intval}][color_mode]" value="#EF5A67" class="prestashopinventory-status-choice-input" {if $status.color == '#EF5A67'}checked{/if}>
                          <span class="prestashopinventory-status-swatch" style="background-color: #EF5A67;"></span>
                        </label>
                        <label class="prestashopinventory-status-choice" title="Pomarańczowy">
                          <input type="radio" name="prestashopInventoryOrderStatuses[{$smarty.foreach.orderStatuses.index|intval}][color_mode]" value="#F28C28" class="prestashopinventory-status-choice-input" {if $status.color == '#F28C28'}checked{/if}>
                          <span class="prestashopinventory-status-swatch" style="background-color: #F28C28;"></span>
                        </label>
                        <label class="prestashopinventory-status-choice" title="Złoty">
                          <input type="radio" name="prestashopInventoryOrderStatuses[{$smarty.foreach.orderStatuses.index|intval}][color_mode]" value="#D4A017" class="prestashopinventory-status-choice-input" {if $status.color == '#D4A017'}checked{/if}>
                          <span class="prestashopinventory-status-swatch" style="background-color: #D4A017;"></span>
                        </label>
                        <label class="prestashopinventory-status-choice" title="Błękitny">
                          <input type="radio" name="prestashopInventoryOrderStatuses[{$smarty.foreach.orderStatuses.index|intval}][color_mode]" value="#25B9D7" class="prestashopinventory-status-choice-input" {if $status.color == '#25B9D7'}checked{/if}>
                          <span class="prestashopinventory-status-swatch" style="background-color: #25B9D7;"></span>
                        </label>
                        <label class="prestashopinventory-status-choice" title="Niebieski">
                          <input type="radio" name="prestashopInventoryOrderStatuses[{$smarty.foreach.orderStatuses.index|intval}][color_mode]" value="#3E7BFA" class="prestashopinventory-status-choice-input" {if $status.color == '#3E7BFA'}checked{/if}>
                          <span class="prestashopinventory-status-swatch" style="background-color: #3E7BFA;"></span>
                        </label>
                        <label class="prestashopinventory-status-choice" title="Zielony">
                          <input type="radio" name="prestashopInventoryOrderStatuses[{$smarty.foreach.orderStatuses.index|intval}][color_mode]" value="#35B36B" class="prestashopinventory-status-choice-input" {if $status.color == '#35B36B'}checked{/if}>
                          <span class="prestashopinventory-status-swatch" style="background-color: #35B36B;"></span>
                        </label>
                        <label class="prestashopinventory-status-choice" title="Fioletowy">
                          <input type="radio" name="prestashopInventoryOrderStatuses[{$smarty.foreach.orderStatuses.index|intval}][color_mode]" value="#7B61FF" class="prestashopinventory-status-choice-input" {if $status.color == '#7B61FF'}checked{/if}>
                          <span class="prestashopinventory-status-swatch" style="background-color: #7B61FF;"></span>
                        </label>
                        <label class="prestashopinventory-status-choice prestashopinventory-status-choice--custom" title="Własny HEX">
                          <input type="radio" name="prestashopInventoryOrderStatuses[{$smarty.foreach.orderStatuses.index|intval}][color_mode]" value="__custom__" class="prestashopinventory-status-choice-input" {if $status.color != '#B7C1CB' && $status.color != '#EF5A67' && $status.color != '#F28C28' && $status.color != '#D4A017' && $status.color != '#25B9D7' && $status.color != '#3E7BFA' && $status.color != '#35B36B' && $status.color != '#7B61FF'}checked{/if}>
                          <span class="prestashopinventory-status-choice-label">HEX</span>
                        </label>
                      </div>
                      <input
                        type="text"
                        name="prestashopInventoryOrderStatuses[{$smarty.foreach.orderStatuses.index|intval}][color_custom]"
                        value="{if $status.color != '#B7C1CB' && $status.color != '#EF5A67' && $status.color != '#F28C28' && $status.color != '#D4A017' && $status.color != '#25B9D7' && $status.color != '#3E7BFA' && $status.color != '#35B36B' && $status.color != '#7B61FF'}{$status.color|escape:'html':'UTF-8'}{/if}"
                        class="form-control prestashopinventory-status-color-text"
                        maxlength="7"
                        spellcheck="false"
                        placeholder="#25B9D7"
                      >
                    </div>
                  </div>
                </td>
                <td class="prestashopinventory-order-status-preview-cell">
                  <span class="badge purchase-order-status js-order-status-preview" style="{$status.badge_style|escape:'html':'UTF-8'}">{$status.label|escape:'html':'UTF-8'}</span>
                </td>
                <td class="prestashopinventory-order-status-actions">
                  <button type="button" class="btn btn-outline-danger btn-sm js-order-status-remove" title="Usuń status" aria-label="Usuń status">
                    <span class="material-icons" aria-hidden="true">delete</span>
                  </button>
                </td>
              </tr>
            {/foreach}
          </tbody>
        </table>
      </div>

      <div class="mt-3">
        <button type="submit" name="submitPrestashopInventorySaveOrderSettings" class="btn btn-primary">
          Zapisz ustawienia
        </button>
      </div>
    </div>
  </div>
</form>
</div>

<style>
  .inventory-module-content {
    padding-top: 60px;
    clear: both;
    position: relative;
  }

  .inventory-module-content--embedded {
    padding-top: 0;
  }

  .inventory-panel-tabs {
    margin: 0;
  }

  .page-head > .inventory-panel-tabs {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 14px;
    min-height: 58px;
    margin: 0;
    padding: 0;
    border-top: 1px solid #eaebec;
    border-bottom: 1px solid #eaebec;
    background: #fff;
    box-shadow: none;
  }

  .page-head > .inventory-panel-tabs .nav.nav-pills {
    display: flex;
    flex: 1 1 auto;
    align-self: stretch;
    gap: 0;
    margin: 0;
    padding: 0;
  }

  .page-head > .inventory-panel-tabs .nav-item {
    display: flex;
    margin: 0;
  }

  .page-head > .inventory-panel-tabs .nav-link {
    position: relative;
    display: inline-flex;
    align-items: center;
    margin: 0;
    min-height: 56px;
    padding: 0 1.6rem;
    border: 0;
    border-radius: 0;
    background: transparent;
    color: #6c868e;
    font-size: 0.95rem;
    font-weight: 400;
    line-height: 1.3;
    transition: color .2s ease, background-color .2s ease;
    box-shadow: none;
  }

  .page-head > .inventory-panel-tabs .inventory-tab-link-content {
    display: inline-flex;
    align-items: center;
    gap: 12px;
  }

  .page-head > .inventory-panel-tabs .inventory-tab-link-content .menu-icon.material-icons {
    width: 22px;
    height: 22px;
    font-size: 22px;
    line-height: 1;
  }

  .page-head > .inventory-panel-tabs .nav-link:hover,
  .page-head > .inventory-panel-tabs .nav-link:focus {
    background: #fff;
    color: #25b9d7;
    box-shadow: none;
  }

  .page-head > .inventory-panel-tabs .nav-link::after {
    content: "";
    position: absolute;
    right: 0;
    bottom: 0;
    left: 0;
    height: 3px;
    background: #25b9d7;
    opacity: 0;
    transition: opacity .2s ease;
  }

  .page-head > .inventory-panel-tabs .nav-link:hover::after,
  .page-head > .inventory-panel-tabs .nav-link:focus::after,
  .page-head > .inventory-panel-tabs .nav-link.active::after,
  .page-head > .inventory-panel-tabs .nav-link[aria-current="page"]::after {
    opacity: 1;
  }

  .page-head > .inventory-panel-tabs .nav-link.active,
  .page-head > .inventory-panel-tabs .nav-link[aria-current="page"] {
    background: #eef8fd;
    color: #363a41;
    font-weight: 400;
    box-shadow: none;
  }

  .page-head > .inventory-panel-tabs .inventory-update-meta {
    display: flex;
    flex: 0 0 260px;
    align-items: center;
    justify-content: center;
    min-height: 56px;
    height: 56px;
    margin: 0 18px 0 0;
    text-align: right;
    overflow: hidden;
  }

  .page-head > .inventory-panel-tabs .inventory-update-meta-status {
    display: block;
    width: 100%;
    margin: 0;
    padding: 0;
    border: 0;
    background: transparent;
    font-size: 11px;
    font-weight: 600;
    color: #7a8f9d;
    line-height: 1.25;
    min-height: 0;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  @media (max-width: 1100px) {
    .page-head > .inventory-panel-tabs .inventory-update-meta {
      flex-basis: 180px;
      margin-right: 12px;
    }
  }

  @media (max-width: 920px) {
    .page-head > .inventory-panel-tabs .inventory-update-meta {
      display: none;
    }
  }

  .prestashopinventory-config-list.card {
    margin-bottom: 1rem;
    margin-top: 0 !important;
  }

  .prestashopinventory-config-list .card-header {
    padding: 1rem 1.25rem;
  }

  .prestashopinventory-config-list .card-body {
    padding: 20px 28px 24px;
  }

  .prestashopinventory-config-list .inventory-settings-meta {
    margin-bottom: 24px;
    padding: 18px 20px;
    border: 1px solid #dce7ef;
    border-radius: 4px;
    background: linear-gradient(180deg, #f9fcfe 0%, #f3f8fb 100%);
  }

  .prestashopinventory-config-list .inventory-settings-meta-header {
    margin-bottom: 14px;
  }

  .prestashopinventory-config-list .inventory-settings-meta-title {
    margin: 0;
    font-size: 18px;
    font-weight: 700;
    color: #243746;
  }

  .prestashopinventory-config-list .inventory-settings-meta-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
    gap: 14px;
  }

  .prestashopinventory-config-list .inventory-settings-meta-item {
    padding: 14px 16px;
    border: 1px solid #d8e4ec;
    border-radius: 4px;
    background: #fff;
  }

  .prestashopinventory-config-list .inventory-settings-meta-label {
    margin-bottom: 6px;
    font-size: 12px;
    font-weight: 700;
    letter-spacing: 0.04em;
    text-transform: uppercase;
    color: #6f8796;
  }

  .prestashopinventory-config-list .inventory-settings-meta-value {
    font-size: 15px;
    font-weight: 600;
    color: #243746;
    word-break: break-word;
  }

  .prestashopinventory-config-list .inventory-settings-license-alert {
    margin: 16px 0 0;
  }

  .prestashopinventory-config-list table {
    margin-bottom: 0;
  }

  .prestashopinventory-config-list .table-responsive-row {
    overflow-x: auto;
  }

  .prestashopinventory-config-list .img-thumbnail {
    width: 45px;
    height: 45px;
    object-fit: cover;
    padding: 2px;
  }

  .prestashopinventory-config-list .ps-switch {
    display: inline-block;
  }

  .prestashopinventory-settings-form {
    margin: 0;
  }

  .prestashopinventory-order-status-panel-head {
    display: flex;
    flex-wrap: wrap;
    align-items: flex-start;
    justify-content: space-between;
    gap: 12px;
  }

  .prestashopinventory-settings-subtitle {
    margin: 0 0 4px;
    font-size: 16px;
    font-weight: 600;
    color: #363a41;
  }

  .prestashopinventory-order-status-table th,
  .prestashopinventory-order-status-row td {
    vertical-align: middle;
  }

  .prestashopinventory-status-color-field {
    display: block;
  }

  .prestashopinventory-status-color-line {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    gap: 10px;
  }

  .prestashopinventory-status-color-text {
    width: 110px;
    min-width: 110px;
    text-transform: uppercase;
    letter-spacing: 0.03em;
  }

  .prestashopinventory-status-swatches {
    display: inline-flex;
    flex-wrap: wrap;
    gap: 6px;
  }

  .prestashopinventory-order-status-actions {
    width: 1%;
    text-align: right;
    white-space: nowrap;
  }

  .prestashopinventory-order-status-preview-cell {
    white-space: nowrap;
  }

  .prestashopinventory-status-choice {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    margin: 0;
    cursor: pointer;
  }

  .prestashopinventory-status-choice-input {
    position: absolute;
    opacity: 0;
    pointer-events: none;
  }

  .prestashopinventory-status-swatch {
    width: 22px;
    height: 22px;
    border: 2px solid #d4dde3;
    border-radius: 50%;
    padding: 0;
    box-shadow: none;
    cursor: pointer;
    transition: transform 0.15s ease, border-color 0.15s ease;
  }

  .prestashopinventory-status-swatch:hover,
  .prestashopinventory-status-swatch:focus {
    transform: scale(1.08);
    border-color: #363a41;
    outline: none;
  }

  .prestashopinventory-status-choice-input:checked + .prestashopinventory-status-swatch,
  .prestashopinventory-status-choice-input:checked + .prestashopinventory-status-choice-label {
    border-color: #363a41;
    box-shadow: 0 0 0 2px rgba(54, 58, 65, 0.16);
  }

  .prestashopinventory-status-choice-label {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-width: 42px;
    height: 22px;
    padding: 0 8px;
    border: 2px solid #d4dde3;
    border-radius: 999px;
    background: #fff;
    color: #5d7178;
    font-size: 11px;
    font-weight: 700;
    line-height: 1;
  }

  .js-order-status-remove .material-icons {
    font-size: 18px;
    line-height: 1;
  }

  .purchase-order-status {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-width: 110px;
    padding: 0.36rem 0.8rem;
    border: 1px solid transparent;
    border-radius: 999px;
    font-size: 12px;
    font-weight: 700;
    line-height: 1.2;
    text-align: center;
  }
</style>

<script>
  (function () {
    function normalizeHex(value) {
      var hex = String(value || '').trim().toUpperCase();
      if (hex === '') {
        return '';
      }

      if (hex.charAt(0) !== '#') {
        hex = '#' + hex;
      }

      return /^#[0-9A-F]{6}$/.test(hex) ? hex : '';
    }

    function buildBadgeStyle(color) {
      var normalizedColor = normalizeHex(color) || '#25B9D7';
      var red = parseInt(normalizedColor.substr(1, 2), 16);
      var green = parseInt(normalizedColor.substr(3, 2), 16);
      var blue = parseInt(normalizedColor.substr(5, 2), 16);

      return 'background-color: rgba(' + red + ', ' + green + ', ' + blue + ', 0.14); border-color: rgba(' + red + ', ' + green + ', ' + blue + ', 0.32); color: ' + normalizedColor + ';';
    }

    function getStatusColorInput(row) {
      return row.querySelector('.prestashopinventory-status-color-text');
    }

    function getCheckedStatusChoice(row) {
      return row.querySelector('.prestashopinventory-status-choice-input:checked');
    }

    function updateStatusPreview(row) {
      if (!row) {
        return;
      }

      var labelInput = row.querySelector('.js-order-status-label');
      var preview = row.querySelector('.js-order-status-preview');
      var colorInput = getStatusColorInput(row);
      var checkedChoice = getCheckedStatusChoice(row);
      var label = labelInput && labelInput.value.trim() !== '' ? labelInput.value.trim() : 'Nowy status';
      var color = '#25B9D7';

      if (checkedChoice && checkedChoice.value !== '__custom__') {
        color = checkedChoice.value;
      } else if (colorInput) {
        color = normalizeHex(colorInput.value) || '#25B9D7';
      }

      if (colorInput && checkedChoice && checkedChoice.value !== '__custom__') {
        colorInput.value = normalizeHex(checkedChoice.value) || checkedChoice.value;
      }

      if (preview) {
        preview.textContent = label;
        preview.setAttribute('style', buildBadgeStyle(color));
      }
    }

    function reindexStatusRows(tableBody) {
      var rows = tableBody.querySelectorAll('.prestashopinventory-order-status-row');
      Array.prototype.forEach.call(rows, function (row, index) {
        var fields = row.querySelectorAll('[name]');
        Array.prototype.forEach.call(fields, function (field) {
          field.name = field.name.replace(/prestashopInventoryOrderStatuses\[\d+\]/, 'prestashopInventoryOrderStatuses[' + index + ']');
        });
      });
    }

    function createStatusRow(index) {
      var row = document.createElement('tr');
      row.className = 'prestashopinventory-order-status-row';
      row.innerHTML = ''
        + '<td class="prestashopinventory-order-status-main">'
        + '  <input type="hidden" name="prestashopInventoryOrderStatuses[' + index + '][key]" value="" class="js-order-status-key">'
        + '  <input type="text" name="prestashopInventoryOrderStatuses[' + index + '][label]" value="" class="form-control js-order-status-label" placeholder="np. Zaksięgowane">'
        + '</td>'
        + '<td>'
        + '  <div class="prestashopinventory-status-color-field">'
        + '    <div class="prestashopinventory-status-color-line">'
        + '      <div class="prestashopinventory-status-swatches">'
        + '        <label class="prestashopinventory-status-choice" title="Szary"><input type="radio" name="prestashopInventoryOrderStatuses[' + index + '][color_mode]" value="#B7C1CB" class="prestashopinventory-status-choice-input"><span class="prestashopinventory-status-swatch" style="background-color: #B7C1CB;"></span></label>'
        + '        <label class="prestashopinventory-status-choice" title="Czerwony"><input type="radio" name="prestashopInventoryOrderStatuses[' + index + '][color_mode]" value="#EF5A67" class="prestashopinventory-status-choice-input"><span class="prestashopinventory-status-swatch" style="background-color: #EF5A67;"></span></label>'
        + '        <label class="prestashopinventory-status-choice" title="Pomarańczowy"><input type="radio" name="prestashopInventoryOrderStatuses[' + index + '][color_mode]" value="#F28C28" class="prestashopinventory-status-choice-input"><span class="prestashopinventory-status-swatch" style="background-color: #F28C28;"></span></label>'
        + '        <label class="prestashopinventory-status-choice" title="Złoty"><input type="radio" name="prestashopInventoryOrderStatuses[' + index + '][color_mode]" value="#D4A017" class="prestashopinventory-status-choice-input"><span class="prestashopinventory-status-swatch" style="background-color: #D4A017;"></span></label>'
        + '        <label class="prestashopinventory-status-choice" title="Błękitny"><input type="radio" name="prestashopInventoryOrderStatuses[' + index + '][color_mode]" value="#25B9D7" class="prestashopinventory-status-choice-input"><span class="prestashopinventory-status-swatch" style="background-color: #25B9D7;"></span></label>'
        + '        <label class="prestashopinventory-status-choice" title="Niebieski"><input type="radio" name="prestashopInventoryOrderStatuses[' + index + '][color_mode]" value="#3E7BFA" class="prestashopinventory-status-choice-input"><span class="prestashopinventory-status-swatch" style="background-color: #3E7BFA;"></span></label>'
        + '        <label class="prestashopinventory-status-choice" title="Zielony"><input type="radio" name="prestashopInventoryOrderStatuses[' + index + '][color_mode]" value="#35B36B" class="prestashopinventory-status-choice-input"><span class="prestashopinventory-status-swatch" style="background-color: #35B36B;"></span></label>'
        + '        <label class="prestashopinventory-status-choice" title="Fioletowy"><input type="radio" name="prestashopInventoryOrderStatuses[' + index + '][color_mode]" value="#7B61FF" class="prestashopinventory-status-choice-input"><span class="prestashopinventory-status-swatch" style="background-color: #7B61FF;"></span></label>'
        + '        <label class="prestashopinventory-status-choice prestashopinventory-status-choice--custom" title="Własny HEX"><input type="radio" name="prestashopInventoryOrderStatuses[' + index + '][color_mode]" value="__custom__" class="prestashopinventory-status-choice-input"><span class="prestashopinventory-status-choice-label">HEX</span></label>'
        + '      </div>'
        + '      <input type="text" name="prestashopInventoryOrderStatuses[' + index + '][color_custom]" value="" class="form-control prestashopinventory-status-color-text" maxlength="7" spellcheck="false" placeholder="#25B9D7">'
        + '    </div>'
        + '  </div>'
        + '</td>'
        + '<td class="prestashopinventory-order-status-preview-cell"><span class="badge purchase-order-status js-order-status-preview" style="background-color: rgba(37, 185, 215, 0.14); border-color: rgba(37, 185, 215, 0.32); color: #25B9D7;">Nowy status</span></td>'
        + '<td class="prestashopinventory-order-status-actions"><button type="button" class="btn btn-outline-danger btn-sm js-order-status-remove" title="Usuń status" aria-label="Usuń status"><span class="material-icons" aria-hidden="true">delete</span></button></td>';

      return row;
    }

    function bindStatusSettings() {
      var tableBody = document.getElementById('prestashopInventoryOrderStatusRows');
      var addButton = document.getElementById('prestashopInventoryAddOrderStatus');
      if (!tableBody || !addButton) {
        return;
      }

      Array.prototype.forEach.call(tableBody.querySelectorAll('.prestashopinventory-order-status-row'), function (row) {
        updateStatusPreview(row);
      });

      addButton.addEventListener('click', function () {
        var row = createStatusRow(tableBody.children.length);
        tableBody.appendChild(row);
        reindexStatusRows(tableBody);
        updateStatusPreview(row);

        var labelInput = row.querySelector('.js-order-status-label');
        if (labelInput) {
          labelInput.focus();
        }
      });

      tableBody.addEventListener('input', function (event) {
        var target = event.target;
        var row = target && target.closest ? target.closest('.prestashopinventory-order-status-row') : null;
        if (!row) {
          return;
        }

        if (target.classList.contains('js-order-status-label')) {
          updateStatusPreview(row);
          return;
        }

        if (target.classList.contains('prestashopinventory-status-color-text')) {
          var customChoice = row.querySelector('.prestashopinventory-status-choice-input[value="__custom__"]');
          if (customChoice) {
            customChoice.checked = true;
          }
          updateStatusPreview(row);
        }
      });

      tableBody.addEventListener('change', function (event) {
        var target = event.target;
        var row = target && target.closest ? target.closest('.prestashopinventory-order-status-row') : null;
        if (!row) {
          return;
        }

        if (target.classList.contains('prestashopinventory-status-choice-input')) {
          updateStatusPreview(row);
          return;
        }

        if (target.classList.contains('prestashopinventory-status-color-text')) {
          var normalized = normalizeHex(target.value);
          if (normalized !== '') {
            target.value = normalized;
          }
          updateStatusPreview(row);
        }
      });

      tableBody.addEventListener('click', function (event) {
        var button = event.target && event.target.closest ? event.target.closest('.js-order-status-remove') : null;
        if (!button) {
          return;
        }

        var row = button.closest('.prestashopinventory-order-status-row');
        if (!row) {
          return;
        }

        row.parentNode.removeChild(row);
        reindexStatusRows(tableBody);
      });
    }

    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', bindStatusSettings);
    } else {
      bindStatusSettings();
    }
  })();
</script>

{if empty($prestashopInventoryEmbeddedInModernLayout)}
<script>
  (function () {
    function syncBreadcrumb(currentLabel) {
      var breadcrumb = document.querySelector('.header-toolbar .breadcrumb');
      if (!breadcrumb) {
        return;
      }

      while (breadcrumb.firstChild) {
        breadcrumb.removeChild(breadcrumb.firstChild);
      }

      var catalogItem = document.createElement('li');
      catalogItem.className = 'breadcrumb-item';
      var catalogIcon = document.createElement('i');
      catalogIcon.className = 'material-icons';
      catalogIcon.textContent = 'store';
      catalogItem.appendChild(catalogIcon);
      catalogItem.appendChild(document.createTextNode('Katalog'));
      breadcrumb.appendChild(catalogItem);

      var moduleItem = document.createElement('li');
      moduleItem.className = 'breadcrumb-item';
      var moduleLink = document.createElement('a');
      moduleLink.href = '{$prestashopInventoryBackUrl|escape:'javascript'}';
      moduleLink.textContent = 'Inventory';
      moduleItem.appendChild(moduleLink);
      breadcrumb.appendChild(moduleItem);

      var currentItem = document.createElement('li');
      currentItem.className = 'breadcrumb-item active breadcrumb-item--inventory-current';
      var currentSpan = document.createElement('span');
      currentSpan.textContent = currentLabel;
      currentItem.appendChild(currentSpan);
      breadcrumb.appendChild(currentItem);
    }

    function getDirectContainerFluid(headerToolbar) {
      if (!headerToolbar) {
        return null;
      }

      var children = headerToolbar.children || [];
      for (var i = 0; i < children.length; i++) {
        if (children[i].classList && children[i].classList.contains('container-fluid')) {
          return children[i];
        }
      }

      return headerToolbar.querySelector('.container-fluid');
    }

    function mountBoTabs(sourceId, attempt) {
      var source = document.getElementById(sourceId);
      if (!source) {
        return true;
      }

      var pageHead = document.querySelector('.page-head');
      var pageHeadWrapper = pageHead ? pageHead.querySelector('.wrapper.clearfix') : null;
      if (!pageHead) {
        if ((attempt || 0) < 100) {
          window.setTimeout(function () {
            mountBoTabs(sourceId, (attempt || 0) + 1);
          }, 100);
          return false;
        }

        source.hidden = false;
        return false;
      }

      var mounted = document.getElementById('head_tabs');
      if (mounted && mounted !== source && mounted.parentNode) {
        mounted.parentNode.removeChild(mounted);
      }

      if (pageHeadWrapper) {
        if (source.parentNode !== pageHead || source.previousElementSibling !== pageHeadWrapper) {
          pageHeadWrapper.insertAdjacentElement('afterend', source);
        }
      } else if (source.parentNode !== pageHead) {
        pageHead.appendChild(source);
      }

      var contentDiv = document.querySelector('#main-div > .content-div');
      if (contentDiv) {
        contentDiv.classList.add('with-tabs');
      }

      syncBreadcrumb('Ustawienia');

      source.hidden = false;
      return true;
    }

    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', function () {
        mountBoTabs('psinventory-config-head-tabs-source', 0);
      });
    } else {
      mountBoTabs('psinventory-config-head-tabs-source', 0);
    }

    window.addEventListener('load', function () {
      mountBoTabs('psinventory-config-head-tabs-source', 0);
    });

    var mountObserver = new MutationObserver(function () {
      mountBoTabs('psinventory-config-head-tabs-source', 0);
    });
    mountObserver.observe(document.documentElement, {ldelim}childList: true, subtree: true{rdelim});
    window.setTimeout(function () {
      mountObserver.disconnect();
    }, 10000);
  })();
</script>
{/if}
