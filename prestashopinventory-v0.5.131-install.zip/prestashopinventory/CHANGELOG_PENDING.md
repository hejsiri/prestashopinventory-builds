# Wpisz tu zmiany do następnego release (jedna linia = jeden bullet)
# Przykład:
# Poprawa walidacji wymiarów w modalu produktu.
# Usunięcie znaku % z nagłówka kolumny Cło.
Przeniesienie wersji modułu w stopce na lewą stronę.
Usunięcie efektu obramowania po najechaniu na skrajne numery stron w paginacji.
