<?php

class PrestashopInventoryI18n
{
    public const DOMAIN = 'Modules.Prestashopinventory.Admin';
    private const SOURCE_MESSAGES = [
        'warehouse_tab' => 'Warehouse',
        'settings_tab' => 'Settings',
        'inventory_report' => 'Inventory report',
        'new_warehouse_view_scaffold' => 'New Warehouse view scaffold for the Inventory module.',
        'new_settings_view_scaffold' => 'New Settings view scaffold for the Inventory module.',
        'warehouse_migration_notice' => 'This tab will become the new place for the inventory table after the migration to the PrestaShop 8.2+ / 9.x compatible architecture is completed.',
        'settings_migration_notice' => 'This tab will become the new place for hidden products configuration and module settings after the migration is completed.',
        'no_image' => 'None',
        'no_data' => 'No data',
        'actions' => 'Actions',
        'hide_forever' => 'Hide permanently',
        'total_purchase_value_net' => 'Total net purchase value:',
        'total_retail_value_gross' => 'Total gross retail value:',
        'no_results' => 'No results.',
        'report_title' => 'Inventory status',
        'show_only_active_products' => 'Show only active products',
        'show_only_available_in_stock' => 'Show only available in stock',
        'show_only_missing_purchase_price' => 'Show only with missing purchase price',
        'show_product_weight' => 'Show product weight',
        'show_only_missing_weight' => 'Show products without weight',
        'show_retail_prices_gross' => 'Show retail gross prices',
        'row_number' => 'No.',
        'image' => 'Image',
        'name' => 'Name',
        'product_name' => 'Product name',
        'product_weight' => 'Product weight',
        'active' => 'Active',
        'purchase_price_net' => 'Purchase price (net)',
        'retail_price_gross' => 'Retail price (gross)',
        'quantity' => 'Quantity',
        'available_quantity' => 'Available quantity',
        'purchase_value_net' => 'Purchase value (net)',
        'retail_value_gross' => 'Retail value (gross)',
        'products_per_page' => 'Products per page:',
        'current_page' => 'Current page',
        'previous' => 'Previous',
        'next' => 'Next',
        'id' => 'ID',
        'ean13' => 'EAN13',
        'module_navigation' => 'Module navigation',
        'filters' => 'Filters',
        'clear' => 'Clear',
        'search_placeholder' => 'Search table...',
        'save' => 'Save',
        'cancel' => 'Cancel',
        'enter_qty' => 'e.g. 12',
        'enter_price' => 'e.g. 12.34',
        'enter_retail_price' => 'e.g. 99.99',
        'enter_weight' => 'e.g. 1.250',
        'error_save' => 'Save error',
        'error_network' => 'Connection / server error while saving.',
        'error_qty_save' => 'Could not save quantity.',
        'error_weight_save' => 'Could not save weight.',
        'error_hide' => 'Could not hide the product.',
        'type_qty' => 'Enter an integer quantity.',
        'type_price' => 'Enter a price.',
        'type_weight' => 'Enter a valid weight.',
        'error_toggle' => 'Could not change product status.',
        'copied' => 'Copied',
        'copy_error' => 'Could not copy EAN13.',
        'load_error' => 'Loading error.',
        'product_restored' => 'Product restored to the list.',
        'product_restore_error' => 'Could not restore the product.',
        'restore' => 'Restore',
        'displayed' => 'Displayed',
        'hidden_products_empty' => 'No hidden products.',
        'module_parent_tab_error' => 'Could not resolve the parent Back Office tab for Inventory.',
        'module_tab_create_error' => 'Could not create the Inventory tab in Back Office.',
        'access_denied' => 'Access denied',
        'db_update_error' => 'Database update error',
        'stock_update_error' => 'Stock update error',
        'hide_product_error' => 'Hide product error',
        'missing_id_product' => 'Missing product ID',
        'invalid_price' => 'Invalid price',
        'price_must_be_greater_than_zero' => 'Price must be greater than 0',
        'invalid_quantity' => 'Invalid quantity',
        'invalid_weight' => 'Invalid weight',
        'stock_api_not_available' => 'Stock API is not available.',
        'product_not_found' => 'Product not found',
    ];

    public static function all($translator): array
    {
        if (is_object($translator) && method_exists($translator, 'getTranslationCatalogue')) {
            return $translator->getTranslationCatalogue();
        }

        return [
            'warehouse_tab' => self::trans($translator, self::SOURCE_MESSAGES['warehouse_tab']),
            'settings_tab' => self::trans($translator, self::SOURCE_MESSAGES['settings_tab']),
            'inventory_report' => self::trans($translator, self::SOURCE_MESSAGES['inventory_report']),
            'new_warehouse_view_scaffold' => self::trans($translator, self::SOURCE_MESSAGES['new_warehouse_view_scaffold']),
            'new_settings_view_scaffold' => self::trans($translator, self::SOURCE_MESSAGES['new_settings_view_scaffold']),
            'warehouse_migration_notice' => self::trans($translator, self::SOURCE_MESSAGES['warehouse_migration_notice']),
            'settings_migration_notice' => self::trans($translator, self::SOURCE_MESSAGES['settings_migration_notice']),
            'no_image' => self::trans($translator, self::SOURCE_MESSAGES['no_image']),
            'no_data' => self::trans($translator, self::SOURCE_MESSAGES['no_data']),
            'combination_id' => self::trans($translator, 'Combination ID: %id%', ['%id%' => '{{ id }}']),
            'actions' => self::trans($translator, self::SOURCE_MESSAGES['actions']),
            'hide_forever' => self::trans($translator, self::SOURCE_MESSAGES['hide_forever']),
            'total_purchase_value_net' => self::trans($translator, self::SOURCE_MESSAGES['total_purchase_value_net']),
            'total_retail_value_gross' => self::trans($translator, self::SOURCE_MESSAGES['total_retail_value_gross']),
            'no_results' => self::trans($translator, self::SOURCE_MESSAGES['no_results']),
            'report_title' => self::trans($translator, self::SOURCE_MESSAGES['report_title']),
            'show_only_active_products' => self::trans($translator, self::SOURCE_MESSAGES['show_only_active_products']),
            'show_only_available_in_stock' => self::trans($translator, self::SOURCE_MESSAGES['show_only_available_in_stock']),
            'show_only_missing_purchase_price' => self::trans($translator, self::SOURCE_MESSAGES['show_only_missing_purchase_price']),
            'show_product_weight' => self::trans($translator, self::SOURCE_MESSAGES['show_product_weight']),
            'show_only_missing_weight' => self::trans($translator, self::SOURCE_MESSAGES['show_only_missing_weight']),
            'show_retail_prices_gross' => self::trans($translator, self::SOURCE_MESSAGES['show_retail_prices_gross']),
            'row_number' => self::trans($translator, self::SOURCE_MESSAGES['row_number']),
            'image' => self::trans($translator, self::SOURCE_MESSAGES['image']),
            'name' => self::trans($translator, self::SOURCE_MESSAGES['name']),
            'product_name' => self::trans($translator, self::SOURCE_MESSAGES['product_name']),
            'product_weight' => self::trans($translator, self::SOURCE_MESSAGES['product_weight']),
            'active' => self::trans($translator, self::SOURCE_MESSAGES['active']),
            'purchase_price_net' => self::trans($translator, self::SOURCE_MESSAGES['purchase_price_net']),
            'retail_price_gross' => self::trans($translator, self::SOURCE_MESSAGES['retail_price_gross']),
            'quantity' => self::trans($translator, self::SOURCE_MESSAGES['quantity']),
            'available_quantity' => self::trans($translator, self::SOURCE_MESSAGES['available_quantity']),
            'purchase_value_net' => self::trans($translator, self::SOURCE_MESSAGES['purchase_value_net']),
            'retail_value_gross' => self::trans($translator, self::SOURCE_MESSAGES['retail_value_gross']),
            'products_per_page' => self::trans($translator, self::SOURCE_MESSAGES['products_per_page']),
            'visible_range' => self::trans($translator, 'Showing %from%-%to% of %total% (page %page% / %total_pages%)', [
                '%from%' => '{{ from }}',
                '%to%' => '{{ to }}',
                '%total%' => '{{ total }}',
                '%page%' => '{{ page }}',
                '%total_pages%' => '{{ total_pages }}',
            ]),
            'current_page' => self::trans($translator, self::SOURCE_MESSAGES['current_page']),
            'previous' => self::trans($translator, self::SOURCE_MESSAGES['previous']),
            'next' => self::trans($translator, self::SOURCE_MESSAGES['next']),
            'id' => self::trans($translator, self::SOURCE_MESSAGES['id']),
            'ean13' => self::trans($translator, self::SOURCE_MESSAGES['ean13']),
            'module_navigation' => self::trans($translator, self::SOURCE_MESSAGES['module_navigation']),
            'filters' => self::trans($translator, self::SOURCE_MESSAGES['filters']),
            'clear' => self::trans($translator, self::SOURCE_MESSAGES['clear']),
            'search_placeholder' => self::trans($translator, self::SOURCE_MESSAGES['search_placeholder']),
            'save' => self::trans($translator, self::SOURCE_MESSAGES['save']),
            'cancel' => self::trans($translator, self::SOURCE_MESSAGES['cancel']),
            'enter_qty' => self::trans($translator, self::SOURCE_MESSAGES['enter_qty']),
            'enter_price' => self::trans($translator, self::SOURCE_MESSAGES['enter_price']),
            'enter_retail_price' => self::trans($translator, self::SOURCE_MESSAGES['enter_retail_price']),
            'enter_weight' => self::trans($translator, self::SOURCE_MESSAGES['enter_weight']),
            'error_save' => self::trans($translator, self::SOURCE_MESSAGES['error_save']),
            'error_network' => self::trans($translator, self::SOURCE_MESSAGES['error_network']),
            'error_qty_save' => self::trans($translator, self::SOURCE_MESSAGES['error_qty_save']),
            'error_weight_save' => self::trans($translator, self::SOURCE_MESSAGES['error_weight_save']),
            'error_hide' => self::trans($translator, self::SOURCE_MESSAGES['error_hide']),
            'type_qty' => self::trans($translator, self::SOURCE_MESSAGES['type_qty']),
            'type_price' => self::trans($translator, self::SOURCE_MESSAGES['type_price']),
            'type_weight' => self::trans($translator, self::SOURCE_MESSAGES['type_weight']),
            'error_toggle' => self::trans($translator, self::SOURCE_MESSAGES['error_toggle']),
            'copied' => self::trans($translator, self::SOURCE_MESSAGES['copied']),
            'copy_error' => self::trans($translator, self::SOURCE_MESSAGES['copy_error']),
            'load_error' => self::trans($translator, self::SOURCE_MESSAGES['load_error']),
            'product_restored' => self::trans($translator, self::SOURCE_MESSAGES['product_restored']),
            'product_restore_error' => self::trans($translator, self::SOURCE_MESSAGES['product_restore_error']),
            'restore' => self::trans($translator, self::SOURCE_MESSAGES['restore']),
            'displayed' => self::trans($translator, self::SOURCE_MESSAGES['displayed']),
            'hidden_products_empty' => self::trans($translator, self::SOURCE_MESSAGES['hidden_products_empty']),
            'module_parent_tab_error' => self::trans($translator, self::SOURCE_MESSAGES['module_parent_tab_error']),
            'module_tab_create_error' => self::trans($translator, self::SOURCE_MESSAGES['module_tab_create_error']),
            'access_denied' => self::trans($translator, self::SOURCE_MESSAGES['access_denied']),
            'db_update_error' => self::trans($translator, self::SOURCE_MESSAGES['db_update_error']),
            'stock_update_error' => self::trans($translator, self::SOURCE_MESSAGES['stock_update_error']),
            'hide_product_error' => self::trans($translator, self::SOURCE_MESSAGES['hide_product_error']),
            'missing_id_product' => self::trans($translator, self::SOURCE_MESSAGES['missing_id_product']),
            'invalid_price' => self::trans($translator, self::SOURCE_MESSAGES['invalid_price']),
            'price_must_be_greater_than_zero' => self::trans($translator, self::SOURCE_MESSAGES['price_must_be_greater_than_zero']),
            'invalid_quantity' => self::trans($translator, self::SOURCE_MESSAGES['invalid_quantity']),
            'invalid_weight' => self::trans($translator, self::SOURCE_MESSAGES['invalid_weight']),
            'stock_api_not_available' => self::trans($translator, self::SOURCE_MESSAGES['stock_api_not_available']),
            'product_not_found' => self::trans($translator, self::SOURCE_MESSAGES['product_not_found']),
            'pdf_filename' => self::trans($translator, 'Inventory_status_%date%', ['%date%' => '{{ date }}']),
        ];
    }

    public static function translate($translator, string $key, array $params = []): string
    {
        switch ($key) {
            case 'combination_id':
                return self::trans($translator, 'Combination ID: %id%', ['%id%' => (string) ($params['id'] ?? '')]);
            case 'visible_range':
                return self::trans($translator, 'Showing %from%-%to% of %total% (page %page% / %total_pages%)', [
                    '%from%' => (string) ($params['from'] ?? ''),
                    '%to%' => (string) ($params['to'] ?? ''),
                    '%total%' => (string) ($params['total'] ?? ''),
                    '%page%' => (string) ($params['page'] ?? ''),
                    '%total_pages%' => (string) ($params['total_pages'] ?? ''),
                ]);
            case 'pdf_filename':
                return self::trans($translator, 'Inventory_status_%date%', ['%date%' => (string) ($params['date'] ?? '')]);
            default:
                $messages = self::all($translator);

                return $messages[$key] ?? $key;
        }
    }

    private static function trans($translator, string $message, array $params = []): string
    {
        if (is_object($translator) && method_exists($translator, 'transModule')) {
            return $translator->transModule($message, $params);
        }

        return $translator->trans($message, $params, self::DOMAIN);
    }
}
