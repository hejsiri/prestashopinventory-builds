# Wpisz tu zmiany do następnego release (jedna linia = jeden bullet)
# Przykład:
# Poprawa walidacji wymiarów w modalu produktu.
# Usunięcie znaku % z nagłówka kolumny Cło.
Lista produktów: paginacja na dole dopasowana bliżej domyślnych styli BO PrestaShop.
