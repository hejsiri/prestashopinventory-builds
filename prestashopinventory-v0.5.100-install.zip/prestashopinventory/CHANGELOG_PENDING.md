Poprawiono regresję ikony Edytuj w Safari: usunięto błąd setSharedScannerState is not defined.
Dodano stabilne aliasy window.prestashopInventorySetScannerState i window.prestashopInventoryGetScannerState dla współdzielonego stanu modala.
