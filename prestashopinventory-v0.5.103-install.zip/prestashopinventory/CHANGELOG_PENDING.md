Naprawiony podgląd PDF w zamówieniach zakupowych bez błędu 404 w modalu.
Poprawiony układ formularza dodawania plików w zamówieniach.
Przyciski Dodaj i Anuluj przy wybranym pliku ustawione w jednej linii.
