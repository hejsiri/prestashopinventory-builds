<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_5_103(Module $module): bool
{
    return true;
}
