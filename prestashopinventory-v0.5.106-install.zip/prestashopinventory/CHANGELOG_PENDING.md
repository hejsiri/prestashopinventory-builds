Dostawcy w module są teraz niezależni od dostawców PrestaShop i używają własnej tabeli modułu.
Zamówienia zakupowe korzystają z listy dostawców modułu zamiast z danych `ps_supplier`.
