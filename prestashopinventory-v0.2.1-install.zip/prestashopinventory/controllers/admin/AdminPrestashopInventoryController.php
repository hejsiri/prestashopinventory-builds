<?php

require_once dirname(__DIR__, 2) . '/classes/PrestashopInventoryService.php';
require_once dirname(__DIR__, 2) . '/classes/PrestashopInventoryI18n.php';

class AdminPrestashopInventoryController extends ModuleAdminController
{
    private PrestashopInventoryService $inventoryService;

    public function __construct()
    {
        $this->bootstrap = true;

        parent::__construct();

        $this->inventoryService = new PrestashopInventoryService($this->module->getLocalPath(), $this->context);
    }

    public function initContent(): void
    {
        $this->assertViewAccess();

        $translations = $this->inventoryService->getTranslations();

        $this->context->smarty->assign([
            'inventoryCatalogUrl' => $this->context->link->getAdminLink('AdminProducts', true),
            'inventoryModuleUrl' => $this->context->link->getAdminLink('AdminPrestashopInventory', true),
            'inventoryAjaxUrl' => $this->context->link->getAdminLink('AdminPrestashopInventory', true, [], [
                'ajax' => 1,
            ]),
            'inventoryExportUrl' => $this->context->link->getAdminLink('AdminPrestashopInventory', true, [], [
                'exportPdf' => 1,
            ]),
            'inventoryConfigUrl' => $this->context->link->getAdminLink('AdminModules', true, [], [
                'configure' => $this->module->name,
                'module_name' => $this->module->name,
                'tab_module' => $this->module->tab,
            ]),
            'inventoryCanEdit' => $this->access('edit'),
            'inventoryTranslations' => $translations,
            'inventoryTranslationsJson' => json_encode($translations, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
        ]);

        $this->content = $this->module->display(
            $this->module->getLocalPath() . $this->module->name . '.php',
            'views/templates/admin/app.tpl'
        );

        parent::initContent();
    }

    public function postProcess(): void
    {
        if (Tools::getIsset('exportPdf')) {
            $this->assertViewAccess();
            $this->inventoryService->outputPdfReport([
                'lang' => (string) Tools::getValue('lang', (string) $this->context->language->iso_code),
                'activeOnly' => (string) Tools::getValue('activeOnly', '0'),
                'onlyAvailable' => (string) Tools::getValue('onlyAvailable', '0'),
                'missingPurchasePriceOnly' => (string) Tools::getValue('missingPurchasePriceOnly', '0'),
                'missingWeightOnly' => (string) Tools::getValue('missingWeightOnly', '0'),
                'showWeight' => (string) Tools::getValue('showWeight', '1'),
                'showBrutto' => (string) Tools::getValue('showBrutto', '1'),
                'query' => (string) Tools::getValue('query', ''),
            ]);
        }

        parent::postProcess();
    }

    public function ajaxProcessFetchProducts(): void
    {
        $this->assertViewAccess();

        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($this->inventoryService->renderProductsTable([
            'query' => (string) Tools::getValue('query', ''),
            'keywords' => Tools::getValue('keywords'),
            'activeOnly' => Tools::getValue('activeOnly'),
            'onlyAvailable' => Tools::getValue('onlyAvailable'),
            'missingPurchasePriceOnly' => Tools::getValue('missingPurchasePriceOnly'),
            'missingWeightOnly' => Tools::getValue('missingWeightOnly'),
            'showWeight' => Tools::getValue('showWeight', 1),
            'showBrutto' => Tools::getValue('showBrutto', 1),
            'lang' => (string) Tools::getValue('lang', (string) $this->context->language->iso_code),
            'sort_field' => (string) Tools::getValue('sort_field', 'product_name'),
            'sort_dir' => (string) Tools::getValue('sort_dir', 'ASC'),
            'page' => (int) Tools::getValue('page', 1),
            'per_page' => (int) Tools::getValue('per_page', 20),
        ]));
        exit;
    }

    public function ajaxProcessSavePrice(): void
    {
        $this->assertEditAccess();

        header('Content-Type: application/json; charset=utf-8');

        try {
            $price = $this->inventoryService->saveWholesalePrice(
                (int) Tools::getValue('id_product'),
                (int) Tools::getValue('id_product_attribute'),
                (string) Tools::getValue('price', '')
            );

            echo json_encode([
                'ok' => true,
                'price' => $price,
            ]);
        } catch (InvalidArgumentException $e) {
            http_response_code(400);
            echo json_encode([
                'ok' => false,
                'error' => $e->getMessage(),
            ]);
        } catch (Throwable $e) {
            http_response_code(500);
            echo json_encode([
                'ok' => false,
                'error' => PrestashopInventoryI18n::translate($this->context, 'db_update_error'),
            ]);
        }

        exit;
    }

    public function ajaxProcessSaveRetailPrice(): void
    {
        $this->assertEditAccess();

        header('Content-Type: application/json; charset=utf-8');

        try {
            $price = $this->inventoryService->saveRetailGrossPrice(
                (int) Tools::getValue('id_product'),
                (int) Tools::getValue('id_product_attribute'),
                (string) Tools::getValue('price', '')
            );

            echo json_encode([
                'ok' => true,
                'price' => $price,
            ]);
        } catch (InvalidArgumentException $e) {
            http_response_code(400);
            echo json_encode([
                'ok' => false,
                'error' => $e->getMessage(),
            ]);
        } catch (Throwable $e) {
            http_response_code(500);
            echo json_encode([
                'ok' => false,
                'error' => PrestashopInventoryI18n::translate($this->context, 'db_update_error'),
            ]);
        }

        exit;
    }

    public function ajaxProcessToggleProductActive(): void
    {
        $this->assertEditAccess();

        header('Content-Type: application/json; charset=utf-8');

        try {
            $isActive = $this->inventoryService->setProductActive(
                (int) Tools::getValue('id_product'),
                Tools::getValue('active')
            );

            echo json_encode([
                'ok' => true,
                'active' => $isActive ? 1 : 0,
            ]);
        } catch (InvalidArgumentException $e) {
            http_response_code(400);
            echo json_encode([
                'ok' => false,
                'error' => $e->getMessage(),
            ]);
        } catch (Throwable $e) {
            http_response_code(500);
            echo json_encode([
                'ok' => false,
                'error' => PrestashopInventoryI18n::translate($this->context, 'db_update_error'),
            ]);
        }

        exit;
    }

    public function ajaxProcessSaveQuantity(): void
    {
        $this->assertEditAccess();

        header('Content-Type: application/json; charset=utf-8');

        try {
            $quantity = $this->inventoryService->saveQuantity(
                (int) Tools::getValue('id_product'),
                (int) Tools::getValue('id_product_attribute'),
                (string) Tools::getValue('quantity', '')
            );

            echo json_encode([
                'ok' => true,
                'quantity' => $quantity,
            ]);
        } catch (InvalidArgumentException $e) {
            http_response_code(400);
            echo json_encode([
                'ok' => false,
                'error' => $e->getMessage(),
            ]);
        } catch (Throwable $e) {
            http_response_code(500);
            echo json_encode([
                'ok' => false,
                'error' => PrestashopInventoryI18n::translate($this->context, 'stock_update_error'),
            ]);
        }

        exit;
    }

    public function ajaxProcessHideProduct(): void
    {
        $this->assertEditAccess();

        header('Content-Type: application/json; charset=utf-8');

        try {
            $result = $this->inventoryService->hideProduct(
                (int) Tools::getValue('id_product')
            );

            echo json_encode([
                'ok' => true,
                'id_product' => (int) $result['id_product'],
            ]);
        } catch (InvalidArgumentException $e) {
            http_response_code(400);
            echo json_encode([
                'ok' => false,
                'error' => $e->getMessage(),
            ]);
        } catch (Throwable $e) {
            http_response_code(500);
            echo json_encode([
                'ok' => false,
                'error' => PrestashopInventoryI18n::translate($this->context, 'hide_product_error'),
            ]);
        }

        exit;
    }

    private function assertViewAccess(): void
    {
        if (!$this->access('view')) {
            throw new PrestaShopException(PrestashopInventoryI18n::translate($this->context, 'access_denied'));
        }
    }

    private function assertEditAccess(): void
    {
        if (!$this->access('edit')) {
            http_response_code(403);
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode([
                'ok' => false,
                'error' => PrestashopInventoryI18n::translate($this->context, 'access_denied'),
            ]);
            exit;
        }
    }
}
