<?php

declare(strict_types=1);

session_start();

$flash = $_SESSION['crm_order_import_flash'] ?? null;
unset($_SESSION['crm_order_import_flash']);

$dumpPath = trim((string) ($_REQUEST['dump'] ?? ''));
$dbHost = trim((string) ($_REQUEST['db_host'] ?? 'localhost'));
$dbPort = trim((string) ($_REQUEST['db_port'] ?? ''));
$dbName = trim((string) ($_REQUEST['db_name'] ?? ''));
$dbUser = trim((string) ($_REQUEST['db_user'] ?? ''));
$dbPass = (string) ($_REQUEST['db_pass'] ?? '');
$dbPrefix = trim((string) ($_REQUEST['db_prefix'] ?? ''));
$errors = [];
$messages = [];
$orders = [];
$existingOrders = [];
$existingSuppliers = [];
$configuredStatuses = [];
$prefix = '';
$configPath = null;

try {
    if ($dbName !== '' && $dbUser !== '') {
        $config = [
            'host' => $dbHost !== '' ? $dbHost : 'localhost',
            'port' => $dbPort !== '' ? (int) $dbPort : 3306,
            'db' => $dbName,
            'user' => $dbUser,
            'pass' => $dbPass,
            'prefix' => $dbPrefix !== '' ? $dbPrefix : 'ps_',
        ];
    } else {
        $configPath = detectPrestashopConfig();
        if ($configPath === null) {
            throw new RuntimeException('Nie udało się automatycznie odnaleźć konfiguracji PrestaShop. Wpisz ręcznie dane DB poniżej.');
        }

        $config = loadPrestashopConfig($configPath);
        $dbHost = (string) ($config['host'] ?? 'localhost');
        $dbPort = (string) ((int) ($config['port'] ?? 3306) ?: '');
        $dbName = (string) ($config['db'] ?? '');
        $dbUser = (string) ($config['user'] ?? '');
        $dbPass = (string) ($config['pass'] ?? '');
        $dbPrefix = (string) ($config['prefix'] ?? 'ps_');
    }

    $prefix = $config['prefix'];
    $pdo = createPdoFromConfig($config);
    ensureModuleSupplierTable($pdo, $prefix);
    ensurePurchaseOrderTables($pdo, $prefix);
    $configuredStatuses = loadConfiguredPurchaseOrderStatuses($pdo, $prefix);

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $action = trim((string) ($_POST['action'] ?? ''));
        $dumpPath = trim((string) ($_POST['dump'] ?? ''));
        $dbHost = trim((string) ($_POST['db_host'] ?? $dbHost));
        $dbPort = trim((string) ($_POST['db_port'] ?? $dbPort));
        $dbName = trim((string) ($_POST['db_name'] ?? $dbName));
        $dbUser = trim((string) ($_POST['db_user'] ?? $dbUser));
        $dbPass = (string) ($_POST['db_pass'] ?? $dbPass);
        $dbPrefix = trim((string) ($_POST['db_prefix'] ?? $dbPrefix));

        $resolvedDumpPath = resolveDumpPath($dumpPath);
        if ($resolvedDumpPath === null) {
            throw new RuntimeException('Podaj poprawną ścieżkę do pliku SQL na serwerze.');
        }

        $crmData = loadCrmOrderImportData($resolvedDumpPath);
        if ($crmData['orders'] === []) {
            throw new RuntimeException('Nie znaleziono tabeli `orders` w podanym dumpie.');
        }

        $existingSuppliers = loadExistingSuppliers($pdo, $prefix);

        if ($action === 'import_one') {
            $orderId = (int) ($_POST['order_id'] ?? 0);
            $order = $crmData['orders_by_id'][$orderId] ?? null;
            if ($order === null) {
                throw new RuntimeException('Nie znaleziono wybranego zamówienia w dumpie.');
            }

            $supplierId = (int) ($order['supplier_id'] ?? 0);
            if ($supplierId <= 0 || !isset($existingSuppliers[$supplierId])) {
                throw new RuntimeException('Nie można przenieść zamówienia, bo dostawca nie istnieje w module.');
            }

            importOrder(
                $pdo,
                $prefix,
                $order,
                $existingSuppliers[$supplierId],
                $crmData['order_items'][$orderId] ?? [],
                $crmData['products_by_id'],
                $crmData['delivery_addresses'],
                $crmData['carrier_labels'],
                $crmData['documents'][$orderId] ?? []
            );

            $_SESSION['crm_order_import_flash'] = [
                'messages' => [
                    'Przeniesiono zamówienie ID ' . $orderId . '.',
                ],
                'errors' => [],
            ];

            header('Location: ' . buildSelfUrl([
                'dump' => $dumpPath,
                'db_host' => $dbHost,
                'db_port' => $dbPort,
                'db_name' => $dbName,
                'db_user' => $dbUser,
                'db_pass' => $dbPass,
                'db_prefix' => $dbPrefix,
            ]));
            exit;
        }

        if ($action === 'import_selected') {
            $selectedIds = array_values(array_unique(array_filter(array_map('intval', (array) ($_POST['order_ids'] ?? [])))));
            if ($selectedIds === []) {
                throw new RuntimeException('Nie zaznaczono żadnych zamówień do przeniesienia.');
            }

            $importedCount = 0;
            $skipped = [];
            foreach ($selectedIds as $orderId) {
                $order = $crmData['orders_by_id'][$orderId] ?? null;
                if ($order === null) {
                    $skipped[] = 'ID ' . $orderId . ': brak w dumpie.';
                    continue;
                }

                $supplierId = (int) ($order['supplier_id'] ?? 0);
                if ($supplierId <= 0 || !isset($existingSuppliers[$supplierId])) {
                    $skipped[] = 'ID ' . $orderId . ': brak dostawcy ID ' . $supplierId . ' w module.';
                    continue;
                }

                importOrder(
                    $pdo,
                    $prefix,
                    $order,
                    $existingSuppliers[$supplierId],
                    $crmData['order_items'][$orderId] ?? [],
                    $crmData['products_by_id'],
                    $crmData['delivery_addresses'],
                    $crmData['carrier_labels'],
                    $crmData['documents'][$orderId] ?? []
                );
                ++$importedCount;
            }

            $_SESSION['crm_order_import_flash'] = [
                'messages' => [
                    'Przeniesiono zamówień: ' . $importedCount . '.',
                ],
                'errors' => $skipped,
            ];

            header('Location: ' . buildSelfUrl([
                'dump' => $dumpPath,
                'db_host' => $dbHost,
                'db_port' => $dbPort,
                'db_name' => $dbName,
                'db_user' => $dbUser,
                'db_pass' => $dbPass,
                'db_prefix' => $dbPrefix,
            ]));
            exit;
        }
    }

    if ($dumpPath !== '') {
        $resolvedDumpPath = resolveDumpPath($dumpPath);
        if ($resolvedDumpPath === null) {
            $errors[] = 'Plik dumpa nie istnieje: ' . $dumpPath;
        } else {
            $crmData = loadCrmOrderImportData($resolvedDumpPath);
            if ($crmData['orders'] === []) {
                $errors[] = 'Nie znaleziono tabeli `orders` w podanym dumpie.';
            } else {
                $existingSuppliers = loadExistingSuppliers($pdo, $prefix);
                $existingOrders = loadExistingOrders($pdo, $prefix);
                foreach ($crmData['orders'] as $order) {
                    $orderId = (int) ($order['id'] ?? 0);
                    $supplierId = (int) ($order['supplier_id'] ?? 0);
                    $items = $crmData['order_items'][$orderId] ?? [];
                    $productNames = [];
                    $itemsValue = 0.0;
                    $totalQuantity = 0.0;

                    foreach ($items as $item) {
                        $product = $crmData['products_by_id'][(int) ($item['products_id'] ?? 0)] ?? null;
                        $productNames[] = resolveLegacyProductName($product, (int) ($item['products_id'] ?? 0));
                        $itemsValue += (float) ($item['quantity'] ?? 0) * (float) ($item['price'] ?? 0);
                        $totalQuantity += (float) ($item['quantity'] ?? 0);
                    }

                    $documents = $crmData['documents'][$orderId] ?? [];
                    $notes = $crmData['notes'][$orderId] ?? [];
                    $currencyCode = resolveLegacyOrderCurrencyCode($order, $items);
                    $shippingCost = (float) ($order['shipping_cost'] ?? 0);
                    $targetStatus = mapLegacyOrderStatus((string) ($order['status'] ?? ''), $configuredStatuses);
                    $targetIncoterm = mapLegacyIncoterm((string) ($order['condition_delivery'] ?? ''));
                    $existingOrder = $existingOrders[$orderId] ?? null;
                    $supplier = $existingSuppliers[$supplierId] ?? null;
                    $canImport = $supplier !== null;

                    $orders[] = [
                        'id' => $orderId,
                        'reference' => buildLegacyOrderReference($orderId),
                        'supplier_id' => $supplierId,
                        'supplier_exists' => $canImport,
                        'supplier_label' => $supplier !== null
                            ? trim((string) ($supplier['name'] ?? ''))
                            : ('Brak dostawcy ID ' . $supplierId . ' w module'),
                        'supplier_status_label' => $supplier !== null ? 'OK' : 'Brak',
                        'order_date' => (string) ($order['order_date'] ?? ''),
                        'delivery_date' => (string) ($order['delivery_date'] ?? ''),
                        'status' => (string) ($order['status'] ?? ''),
                        'target_status' => $targetStatus,
                        'carrier' => resolveLegacyCarrierName((string) ($order['carrier'] ?? ''), $crmData['carrier_labels']),
                        'package_no' => trim((string) ($order['package_no'] ?? '')),
                        'incoterm_label' => buildMappedIncotermLabel((string) ($order['condition_delivery'] ?? ''), $targetIncoterm),
                        'currency_code' => $currencyCode,
                        'items_count' => count($items),
                        'total_quantity' => $totalQuantity,
                        'items_value' => $itemsValue,
                        'shipping_cost' => $shippingCost,
                        'total_value' => $itemsValue + $shippingCost,
                        'product_preview' => array_slice(array_values(array_unique(array_filter($productNames))), 0, 3),
                        'documents_count' => count($documents),
                        'notes_count' => count($notes),
                        'first_note' => isset($notes[0]) ? trim((string) ($notes[0]['note'] ?? '')) : '',
                        'delivery_address' => resolveLegacyDeliveryAddress((string) ($order['delivery_address'] ?? ''), $crmData['delivery_addresses']),
                        'existing_order' => $existingOrder,
                        'can_import' => $canImport,
                    ];
                }

                usort($orders, static function (array $a, array $b): int {
                    return $b['id'] <=> $a['id'];
                });
            }
        }
    }
} catch (Throwable $e) {
    $errors[] = $e->getMessage();
}

if (is_array($flash)) {
    foreach ((array) ($flash['messages'] ?? []) as $message) {
        $message = trim((string) $message);
        if ($message !== '') {
            $messages[] = $message;
        }
    }
    foreach ((array) ($flash['errors'] ?? []) as $error) {
        $error = trim((string) $error);
        if ($error !== '') {
            $errors[] = $error;
        }
    }
}

header('Content-Type: text/html; charset=utf-8');

?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="utf-8">
    <title>Import zamówień CRM</title>
    <style>
        body {
            margin: 0;
            padding: 24px;
            font-family: Arial, sans-serif;
            background: #f5f7fa;
            color: #1f2933;
        }
        .wrap {
            max-width: 1700px;
            margin: 0 auto;
        }
        .card {
            background: #fff;
            border: 1px solid #d9e2ec;
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(15, 23, 42, 0.06);
            padding: 20px;
            margin-bottom: 20px;
        }
        h1 {
            margin: 0 0 10px;
            font-size: 28px;
        }
        p.note {
            margin: 0;
            color: #52606d;
        }
        .note-strong {
            margin-top: 10px;
            color: #1f2933;
            font-size: 13px;
        }
        .warning-note {
            margin-top: 12px;
            padding: 12px 14px;
            border-radius: 10px;
            background: #fff7ed;
            border: 1px solid #fdba74;
            color: #9a3412;
            font-size: 14px;
        }
        .form-row {
            display: grid;
            grid-template-columns: 1fr auto;
            gap: 12px;
            align-items: end;
        }
        .form-grid {
            display: grid;
            grid-template-columns: repeat(4, minmax(0, 1fr));
            gap: 12px;
            margin-top: 16px;
        }
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 700;
        }
        input[type="text"],
        input[type="password"] {
            width: 100%;
            height: 46px;
            box-sizing: border-box;
            border: 1px solid #bcccdc;
            border-radius: 8px;
            padding: 0 14px;
            font-size: 15px;
        }
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            height: 46px;
            border: 1px solid transparent;
            border-radius: 8px;
            padding: 0 18px;
            font-size: 15px;
            font-weight: 700;
            cursor: pointer;
            text-decoration: none;
            white-space: nowrap;
        }
        .btn-primary {
            background: #25b9d7;
            border-color: #25b9d7;
            color: #fff;
        }
        .btn-secondary {
            background: #fff;
            border-color: #bcccdc;
            color: #52606d;
        }
        .btn[disabled] {
            opacity: 0.45;
            cursor: not-allowed;
        }
        .btn-row {
            display: flex;
            gap: 8px;
            align-items: center;
            justify-content: flex-end;
            flex-wrap: wrap;
        }
        .alert {
            border-radius: 10px;
            padding: 14px 16px;
            margin-bottom: 16px;
        }
        .alert-success {
            background: #ecfdf3;
            color: #166534;
            border: 1px solid #86efac;
        }
        .alert-danger {
            background: #fef2f2;
            color: #991b1b;
            border: 1px solid #fca5a5;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 14px;
        }
        th, td {
            padding: 12px 10px;
            border-bottom: 1px solid #e5e7eb;
            vertical-align: top;
            text-align: left;
        }
        th {
            font-size: 13px;
            text-transform: uppercase;
            letter-spacing: 0.04em;
            color: #52606d;
            background: #f8fafc;
        }
        .status {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            border-radius: 999px;
            padding: 4px 10px;
            font-size: 12px;
            font-weight: 700;
        }
        .status-new {
            background: #eff6ff;
            color: #1d4ed8;
        }
        .status-update {
            background: #fff7ed;
            color: #c2410c;
        }
        .status-ok {
            background: #ecfdf3;
            color: #166534;
        }
        .status-missing {
            background: #fef2f2;
            color: #991b1b;
        }
        .muted {
            color: #7b8794;
        }
        .mono {
            font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
            font-size: 12px;
        }
        .small {
            font-size: 12px;
        }
        .cell-lines div + div {
            margin-top: 4px;
        }
        .table-wrap {
            overflow-x: auto;
            overflow-y: visible;
        }
        .checkbox-cell {
            width: 36px;
            text-align: center;
        }
        input[type="checkbox"] {
            width: 18px;
            height: 18px;
            accent-color: #25b9d7;
            cursor: pointer;
        }
        .summary-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 12px;
            margin-bottom: 16px;
            flex-wrap: wrap;
        }
        .nowrap {
            white-space: nowrap;
        }
        @media (max-width: 960px) {
            body {
                padding: 12px;
            }
            .form-row {
                grid-template-columns: 1fr;
            }
            .form-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
<div class="wrap">
    <div class="card">
        <h1>Import zamówień CRM</h1>
        <p class="note">To narzędzie czyta tabele <span class="mono">orders</span>, <span class="mono">orders_products</span> i <span class="mono">products</span> ze starego dumpa CRM i przenosi zamówienia do tabel modułu <span class="mono"><?= h(($prefix !== '' ? $prefix : 'pr_') . 'prestashopinventory_purchase_order') ?></span> oraz <span class="mono"><?= h(($prefix !== '' ? $prefix : 'pr_') . 'prestashopinventory_purchase_order_item') ?></span>.</p>
        <?php if ($configPath !== null): ?>
            <div class="note-strong">Wykryta konfiguracja PrestaShop: <span class="mono"><?= h($configPath) ?></span></div>
        <?php else: ?>
            <div class="note-strong">Tryb ręczny DB: używane są dane wpisane w formularzu poniżej.</div>
        <?php endif; ?>
        <div class="warning-note">Skrypt sprawdza, czy dostawca z CRM istnieje już w module. Zamówienia bez pasującego dostawcy nie mogą być przeniesione. Podgląd pokazuje też liczbę notatek i dokumentów, ale ten importer przenosi tylko nagłówek zamówienia i pozycje.</div>
    </div>

    <?php foreach ($messages as $message): ?>
        <div class="alert alert-success"><?= h($message) ?></div>
    <?php endforeach; ?>

    <?php foreach ($errors as $error): ?>
        <div class="alert alert-danger"><?= h($error) ?></div>
    <?php endforeach; ?>

    <div class="card">
        <form method="get" action="">
            <div class="form-row">
                <div>
                    <label for="dump">Ścieżka do dumpa SQL na serwerze</label>
                    <input type="text" id="dump" name="dump" value="<?= h($dumpPath) ?>" placeholder="/ścieżka/do/pliku.sql albo sam plik z bieżącego katalogu">
                </div>
                <button type="submit" class="btn btn-primary">Wczytaj podgląd</button>
            </div>
            <div class="form-grid">
                <div>
                    <label for="db_host">DB host</label>
                    <input type="text" id="db_host" name="db_host" value="<?= h($dbHost) ?>" placeholder="localhost">
                </div>
                <div>
                    <label for="db_port">DB port</label>
                    <input type="text" id="db_port" name="db_port" value="<?= h($dbPort) ?>" placeholder="3306">
                </div>
                <div>
                    <label for="db_name">DB name</label>
                    <input type="text" id="db_name" name="db_name" value="<?= h($dbName) ?>">
                </div>
                <div>
                    <label for="db_prefix">DB prefix</label>
                    <input type="text" id="db_prefix" name="db_prefix" value="<?= h($dbPrefix) ?>" placeholder="pr_">
                </div>
                <div>
                    <label for="db_user">DB user</label>
                    <input type="text" id="db_user" name="db_user" value="<?= h($dbUser) ?>">
                </div>
                <div>
                    <label for="db_pass">DB password</label>
                    <input type="password" id="db_pass" name="db_pass" value="<?= h($dbPass) ?>">
                </div>
            </div>
        </form>
    </div>

    <?php if ($orders !== []): ?>
        <?php $bulkFormId = 'bulk-import-orders'; ?>
        <div class="card">
            <div class="summary-bar">
                <div>
                    <strong>Znaleziono zamówień:</strong> <?= count($orders) ?>
                </div>
                <div class="btn-row">
                    <button type="button" class="btn btn-secondary" data-select-orders="ready">Zaznacz z dostawcą</button>
                    <button type="button" class="btn btn-secondary" data-select-orders="all">Zaznacz wszystkie możliwe</button>
                    <button type="button" class="btn btn-secondary" data-select-orders="none">Odznacz wszystko</button>
                    <form method="post" action="" id="<?= h($bulkFormId) ?>" style="margin:0;">
                        <input type="hidden" name="dump" value="<?= h($dumpPath) ?>">
                        <input type="hidden" name="db_host" value="<?= h($dbHost) ?>">
                        <input type="hidden" name="db_port" value="<?= h($dbPort) ?>">
                        <input type="hidden" name="db_name" value="<?= h($dbName) ?>">
                        <input type="hidden" name="db_user" value="<?= h($dbUser) ?>">
                        <input type="hidden" name="db_pass" value="<?= h($dbPass) ?>">
                        <input type="hidden" name="db_prefix" value="<?= h($dbPrefix) ?>">
                        <input type="hidden" name="action" value="import_selected">
                        <button type="submit" class="btn btn-primary">Przenieś zaznaczone</button>
                    </form>
                </div>
            </div>
            <div class="table-wrap">
                <table>
                    <thead>
                    <tr>
                        <th class="checkbox-cell"></th>
                        <th>ID CRM</th>
                        <th>Status</th>
                        <th>Dostawca</th>
                        <th>Daty / transport</th>
                        <th>Pozycje</th>
                        <th>Wartość</th>
                        <th>Dok. / notatki</th>
                        <th>Adres dostawy</th>
                        <th>Obecnie w module</th>
                        <th>Akcja</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($orders as $order): ?>
                        <?php
                        $orderId = (int) $order['id'];
                        $existingOrder = is_array($order['existing_order'] ?? null) ? $order['existing_order'] : null;
                        $statusClass = $existingOrder === null ? 'status-new' : 'status-update';
                        $statusLabel = $existingOrder === null ? 'Nowe' : 'Aktualizacja';
                        $supplierStatusClass = $order['supplier_exists'] ? 'status-ok' : 'status-missing';
                        $rowFormId = 'import-order-' . $orderId;
                        ?>
                        <tr>
                            <td class="checkbox-cell">
                                <?php if ($order['can_import']): ?>
                                    <input
                                        type="checkbox"
                                        name="order_ids[]"
                                        value="<?= h((string) $orderId) ?>"
                                        form="<?= h($bulkFormId) ?>"
                                        data-order-selectable="1"
                                    >
                                <?php endif; ?>
                            </td>
                            <td class="mono">
                                <div><?= h((string) $orderId) ?></div>
                                <div class="muted"><?= h((string) $order['reference']) ?></div>
                            </td>
                            <td class="cell-lines">
                                <div><span class="status <?= h($statusClass) ?>"><?= h($statusLabel) ?></span></div>
                                <div class="small muted">CRM: <?= h((string) $order['status']) ?></div>
                                <div class="small muted">Moduł: <?= h((string) $order['target_status']) ?></div>
                            </td>
                            <td class="cell-lines">
                                <div><strong><?= h((string) $order['supplier_label']) ?></strong></div>
                                <div class="small muted">ID dostawcy: <?= h((string) $order['supplier_id']) ?></div>
                                <div><span class="status <?= h($supplierStatusClass) ?>"><?= h((string) $order['supplier_status_label']) ?></span></div>
                            </td>
                            <td class="cell-lines">
                                <div>Zamówienie: <?= h((string) ($order['order_date'] !== '' ? $order['order_date'] : '—')) ?></div>
                                <div>Dostawa: <?= h((string) ($order['delivery_date'] !== '' ? $order['delivery_date'] : '—')) ?></div>
                                <div class="small muted"><?= h((string) $order['carrier']) ?><?= $order['package_no'] !== '' ? ' / ' . h((string) $order['package_no']) : '' ?></div>
                                <div class="small muted"><?= h((string) $order['incoterm_label']) ?></div>
                            </td>
                            <td class="cell-lines">
                                <div><strong><?= h((string) $order['items_count']) ?></strong> pozycji, ilość <?= h(formatDecimal($order['total_quantity'])) ?></div>
                                <?php foreach ((array) $order['product_preview'] as $productName): ?>
                                    <div class="small muted"><?= h((string) $productName) ?></div>
                                <?php endforeach; ?>
                            </td>
                            <td class="cell-lines nowrap">
                                <div>Pozycje: <?= h(formatMoney($order['items_value'], (string) $order['currency_code'])) ?></div>
                                <div>Transport: <?= h(formatMoney($order['shipping_cost'], (string) $order['currency_code'])) ?></div>
                                <div><strong>Razem: <?= h(formatMoney($order['total_value'], (string) $order['currency_code'])) ?></strong></div>
                            </td>
                            <td class="cell-lines">
                                <div>Dokumenty: <?= h((string) $order['documents_count']) ?></div>
                                <div>Notatki: <?= h((string) $order['notes_count']) ?></div>
                                <?php if ($order['first_note'] !== ''): ?>
                                    <div class="small muted"><?= h(truncateText((string) $order['first_note'], 120)) ?></div>
                                <?php endif; ?>
                            </td>
                            <td class="cell-lines">
                                <div><?= nl2br(h((string) $order['delivery_address'])) ?></div>
                            </td>
                            <td class="cell-lines">
                                <?php if ($existingOrder === null): ?>
                                    <div class="muted">Brak</div>
                                <?php else: ?>
                                    <div><strong><?= h((string) ($existingOrder['reference'] ?? '')) ?></strong></div>
                                    <div class="small muted"><?= h((string) ($existingOrder['supplier_name'] ?? '—')) ?></div>
                                    <div class="small muted"><?= h((string) ($existingOrder['ordered_at'] ?? '—')) ?></div>
                                <?php endif; ?>
                            </td>
                            <td>
                                <form method="post" action="" style="margin:0;" id="<?= h($rowFormId) ?>">
                                    <input type="hidden" name="dump" value="<?= h($dumpPath) ?>">
                                    <input type="hidden" name="db_host" value="<?= h($dbHost) ?>">
                                    <input type="hidden" name="db_port" value="<?= h($dbPort) ?>">
                                    <input type="hidden" name="db_name" value="<?= h($dbName) ?>">
                                    <input type="hidden" name="db_user" value="<?= h($dbUser) ?>">
                                    <input type="hidden" name="db_pass" value="<?= h($dbPass) ?>">
                                    <input type="hidden" name="db_prefix" value="<?= h($dbPrefix) ?>">
                                    <input type="hidden" name="order_id" value="<?= h((string) $orderId) ?>">
                                    <input type="hidden" name="action" value="import_one">
                                    <div class="btn-row">
                                        <button type="submit" class="btn btn-primary" <?php if (!$order['can_import']) echo 'disabled'; ?>>Przenieś</button>
                                    </div>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php endif; ?>
</div>
<script>
document.addEventListener('click', function (event) {
    var trigger = event.target.closest('[data-select-orders]');
    if (!trigger) {
        return;
    }

    var mode = trigger.getAttribute('data-select-orders');
    var checkboxes = document.querySelectorAll('input[data-order-selectable="1"]');
    checkboxes.forEach(function (checkbox) {
        checkbox.checked = mode === 'none' ? false : true;
    });
});
</script>
</body>
</html>
<?php

function h(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}

function buildSelfUrl(array $params = []): string
{
    $path = strtok((string) ($_SERVER['REQUEST_URI'] ?? ''), '?') ?: '';
    $query = http_build_query($params);

    return $query !== '' ? $path . '?' . $query : $path;
}

function detectPrestashopConfig(): ?string
{
    $dir = __DIR__;
    for ($i = 0; $i < 8; $i++) {
        $candidates = [
            $dir . '/config/settings.inc.php',
            $dir . '/app/config/parameters.php',
            $dir . '/app/config/parameters.yml',
            $dir . '/app/config/parameters.yml.dist',
        ];
        foreach ($candidates as $candidate) {
            if (is_file($candidate)) {
                return $candidate;
            }
        }
        $parent = dirname($dir);
        if ($parent === $dir) {
            break;
        }
        $dir = $parent;
    }

    return null;
}

function loadPrestashopConfig(string $configPath): array
{
    $extension = strtolower(pathinfo($configPath, PATHINFO_EXTENSION));

    if ($extension === 'php') {
        if (basename($configPath) === 'settings.inc.php') {
            require_once $configPath;

            $server = (string) _DB_SERVER_;
            $name = (string) _DB_NAME_;
            $user = (string) _DB_USER_;
            $pass = defined('_DB_PASSWD_') ? (string) _DB_PASSWD_ : '';
            $prefix = defined('_DB_PREFIX_') ? (string) _DB_PREFIX_ : 'ps_';
            $port = 3306;

            if (strpos($server, ':') !== false) {
                [$server, $portValue] = explode(':', $server, 2);
                $port = (int) $portValue > 0 ? (int) $portValue : 3306;
            }

            return [
                'host' => $server,
                'port' => $port,
                'db' => $name,
                'user' => $user,
                'pass' => $pass,
                'prefix' => $prefix,
            ];
        }

        $parameters = @include $configPath;
        if (is_array($parameters) && isset($parameters['parameters']) && is_array($parameters['parameters'])) {
            $parameters = $parameters['parameters'];
        }
        if (is_array($parameters)) {
            $server = (string) ($parameters['database_host'] ?? '');
            $name = (string) ($parameters['database_name'] ?? '');
            $user = (string) ($parameters['database_user'] ?? '');
            $pass = (string) ($parameters['database_password'] ?? '');
            $prefix = (string) ($parameters['database_prefix'] ?? 'ps_');
            $port = (int) ($parameters['database_port'] ?? 3306);

            if ($server !== '' && $name !== '' && $user !== '') {
                return [
                    'host' => $server,
                    'port' => $port > 0 ? $port : 3306,
                    'db' => $name,
                    'user' => $user,
                    'pass' => $pass,
                    'prefix' => $prefix !== '' ? $prefix : 'ps_',
                ];
            }
        }
    }

    if (in_array($extension, ['yml', 'yaml', 'dist'], true) || str_ends_with($configPath, '.yml.dist')) {
        $contents = (string) file_get_contents($configPath);
        if ($contents !== '') {
            $map = [];
            foreach ([
                'database_host',
                'database_port',
                'database_name',
                'database_user',
                'database_password',
                'database_prefix',
            ] as $key) {
                if (preg_match('/^\s*' . preg_quote($key, '/') . ':\s*["\']?(.*?)["\']?\s*$/m', $contents, $match)) {
                    $map[$key] = trim((string) $match[1]);
                }
            }

            if (($map['database_host'] ?? '') !== '' && ($map['database_name'] ?? '') !== '' && ($map['database_user'] ?? '') !== '') {
                return [
                    'host' => (string) $map['database_host'],
                    'port' => (int) (($map['database_port'] ?? '3306')) > 0 ? (int) $map['database_port'] : 3306,
                    'db' => (string) $map['database_name'],
                    'user' => (string) $map['database_user'],
                    'pass' => (string) ($map['database_password'] ?? ''),
                    'prefix' => (string) (($map['database_prefix'] ?? 'ps_') !== '' ? $map['database_prefix'] : 'ps_'),
                ];
            }
        }
    }

    throw new RuntimeException('Nie udało się odczytać danych DB z konfiguracji PrestaShop.');
}

function createPdoFromConfig(array $config): PDO
{
    $dsn = sprintf(
        'mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4',
        (string) $config['host'],
        (int) $config['port'],
        (string) $config['db']
    );

    return new PDO($dsn, (string) $config['user'], (string) $config['pass'], [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
}

function resolveDumpPath(string $dumpPath): ?string
{
    $dumpPath = trim($dumpPath);
    if ($dumpPath === '') {
        return null;
    }

    if (is_file($dumpPath)) {
        return $dumpPath;
    }

    $candidate = __DIR__ . '/' . ltrim($dumpPath, '/');
    if (is_file($candidate)) {
        return $candidate;
    }

    return null;
}

function loadCrmOrderImportData(string $dumpPath): array
{
    $sql = (string) file_get_contents($dumpPath);
    if ($sql === '') {
        return [
            'orders' => [],
            'orders_by_id' => [],
            'order_items' => [],
            'products_by_id' => [],
            'documents' => [],
            'notes' => [],
            'delivery_addresses' => [],
            'carrier_labels' => [],
        ];
    }

    $orders = parseOrdersFromSql($sql);
    $ordersById = [];
    foreach ($orders as $order) {
        $orderId = (int) ($order['id'] ?? 0);
        if ($orderId > 0) {
            $ordersById[$orderId] = $order;
        }
    }

    return [
        'orders' => $orders,
        'orders_by_id' => $ordersById,
        'order_items' => parseOrderItemsFromSql($sql),
        'products_by_id' => parseProductsFromSql($sql),
        'documents' => parseOrderDocumentsFromSql($sql),
        'notes' => parseOrderNotesFromSql($sql),
        'delivery_addresses' => parseSettingMapFromSql($sql, 'delivery_address'),
        'carrier_labels' => parseSettingMapFromSql($sql, 'carriers'),
    ];
}

function parseOrdersFromSql(string $sql): array
{
    $tuples = extractInsertTuples($sql, 'orders');
    $rows = [];
    foreach ($tuples as $tuple) {
        $values = str_getcsv($tuple, ',', "'", "\\");
        if (count($values) < 13) {
            continue;
        }

        $rows[] = [
            'id' => (int) normalizeSqlValue($values[0]),
            'supplier_id' => (int) normalizeSqlValue($values[1]),
            'order_date' => (string) (normalizeSqlValue($values[2]) ?? ''),
            'delivery_date' => (string) (normalizeSqlValue($values[3]) ?? ''),
            'datetime_change' => (string) (normalizeSqlValue($values[4]) ?? ''),
            'status' => (string) (normalizeSqlValue($values[5]) ?? ''),
            'carrier' => (string) (normalizeSqlValue($values[6]) ?? ''),
            'package_no' => (string) (normalizeSqlValue($values[7]) ?? ''),
            'condition_delivery' => (string) (normalizeSqlValue($values[8]) ?? ''),
            'delivery_address' => (string) (normalizeSqlValue($values[9]) ?? ''),
            'invoice_no' => (string) (normalizeSqlValue($values[10]) ?? ''),
            'exchange_rate' => normalizeSqlValue($values[11]),
            'shipping_cost' => normalizeSqlValue($values[12]),
        ];
    }

    return $rows;
}

function parseOrderItemsFromSql(string $sql): array
{
    $tuples = extractInsertTuples($sql, 'orders_products');
    $itemsByOrder = [];
    foreach ($tuples as $tuple) {
        $values = str_getcsv($tuple, ',', "'", "\\");
        if (count($values) < 6) {
            continue;
        }

        $orderId = (int) normalizeSqlValue($values[0]);
        if ($orderId <= 0) {
            continue;
        }

        $itemsByOrder[$orderId][] = [
            'orders_id' => $orderId,
            'products_id' => (int) normalizeSqlValue($values[1]),
            'quantity' => (float) normalizeSqlValue($values[2]),
            'price' => (float) normalizeSqlValue($values[3]),
            'currency' => (string) (normalizeSqlValue($values[4]) ?? ''),
            'datetime_add' => (string) (normalizeSqlValue($values[5]) ?? ''),
        ];
    }

    return $itemsByOrder;
}

function parseProductsFromSql(string $sql): array
{
    $tuples = extractInsertTuples($sql, 'products');
    $products = [];
    foreach ($tuples as $tuple) {
        $values = str_getcsv($tuple, ',', "'", "\\");
        if (count($values) < 16) {
            continue;
        }

        $id = (int) normalizeSqlValue($values[0]);
        if ($id <= 0) {
            continue;
        }

        $products[$id] = [
            'id' => $id,
            'model' => (string) (normalizeSqlValue($values[1]) ?? ''),
            'name' => (string) (normalizeSqlValue($values[2]) ?? ''),
            'name_pl' => (string) (normalizeSqlValue($values[3]) ?? ''),
            'material' => (string) (normalizeSqlValue($values[4]) ?? ''),
            'description' => (string) (normalizeSqlValue($values[5]) ?? ''),
            'ean' => (string) (normalizeSqlValue($values[6]) ?? ''),
            'hs_code' => (string) (normalizeSqlValue($values[7]) ?? ''),
            'duty' => normalizeSqlValue($values[8]),
            'price' => normalizeSqlValue($values[9]),
            'currency' => (string) (normalizeSqlValue($values[10]) ?? ''),
            'weight' => normalizeSqlValue($values[13]),
        ];
    }

    return $products;
}

function parseOrderDocumentsFromSql(string $sql): array
{
    $tuples = extractInsertTuples($sql, 'orders_documents');
    $documentsByOrder = [];
    foreach ($tuples as $tuple) {
        $values = str_getcsv($tuple, ',', "'", "\\");
        if (count($values) < 4) {
            continue;
        }

        $orderId = (int) normalizeSqlValue($values[1]);
        if ($orderId <= 0) {
            continue;
        }

        $documentsByOrder[$orderId][] = [
            'id' => (int) normalizeSqlValue($values[0]),
            'order_id' => $orderId,
            'filename' => (string) (normalizeSqlValue($values[2]) ?? ''),
            'type' => (string) (normalizeSqlValue($values[3]) ?? ''),
        ];
    }

    return $documentsByOrder;
}

function parseOrderNotesFromSql(string $sql): array
{
    $tuples = extractInsertTuples($sql, 'orders_notes');
    $notesByOrder = [];
    foreach ($tuples as $tuple) {
        $values = str_getcsv($tuple, ',', "'", "\\");
        if (count($values) < 3) {
            continue;
        }

        $orderId = (int) normalizeSqlValue($values[1]);
        if ($orderId <= 0) {
            continue;
        }

        $notesByOrder[$orderId][] = [
            'id' => (int) normalizeSqlValue($values[0]),
            'orders_id' => $orderId,
            'note' => (string) (normalizeSqlValue($values[2]) ?? ''),
        ];
    }

    return $notesByOrder;
}

function parseSettingMapFromSql(string $sql, string $settingName): array
{
    $tuples = extractInsertTuples($sql, 'settings');
    $map = [];
    foreach ($tuples as $tuple) {
        $values = str_getcsv($tuple, ',', "'", "\\");
        if (count($values) < 4) {
            continue;
        }

        $setting = (string) (normalizeSqlValue($values[0]) ?? '');
        if ($setting !== $settingName) {
            continue;
        }

        $map[(string) (normalizeSqlValue($values[1]) ?? '')] = (string) (normalizeSqlValue($values[2]) ?? '');
    }

    return $map;
}

function extractInsertTuples(string $sql, string $table): array
{
    if (!preg_match('/INSERT INTO `' . preg_quote($table, '/') . '` VALUES\s*(.+?);/s', $sql, $matches)) {
        return [];
    }

    return splitSqlTuples(trim((string) $matches[1]));
}

function splitSqlTuples(string $rowsSql): array
{
    $rowsSql = trim($rowsSql);
    $length = strlen($rowsSql);
    $tuples = [];
    $buffer = '';
    $depth = 0;
    $inString = false;
    $prevChar = '';

    for ($i = 0; $i < $length; $i++) {
        $char = $rowsSql[$i];

        if ($char === "'" && $prevChar !== '\\') {
            $inString = !$inString;
        }

        if (!$inString) {
            if ($char === '(') {
                ++$depth;
                if ($depth === 1) {
                    $buffer = '';
                    $prevChar = $char;
                    continue;
                }
            } elseif ($char === ')') {
                --$depth;
                if ($depth === 0) {
                    $tuples[] = $buffer;
                    $buffer = '';
                    $prevChar = $char;
                    continue;
                }
            }
        }

        if ($depth >= 1) {
            $buffer .= $char;
        }

        $prevChar = $char;
    }

    return $tuples;
}

function normalizeSqlValue(string $value)
{
    $trimmed = trim($value);
    if (strcasecmp($trimmed, 'NULL') === 0) {
        return null;
    }

    return str_replace(["\\'", '\r\n', '\n', '\r'], ["'", "\r\n", "\n", "\r"], $trimmed);
}

function ensureModuleSupplierTable(PDO $pdo, string $prefix): void
{
    $table = $prefix . 'prestashopinventory_supplier';
    $pdo->exec('
        CREATE TABLE IF NOT EXISTS `' . $table . '` (
            `id_supplier` INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `name` VARCHAR(191) NOT NULL DEFAULT "",
            `description` TEXT NULL,
            `active` TINYINT(1) NOT NULL DEFAULT 1,
            `phone` VARCHAR(64) NOT NULL DEFAULT "",
            `email` VARCHAR(191) NOT NULL DEFAULT "",
            `address1` VARCHAR(255) NOT NULL DEFAULT "",
            `address2` VARCHAR(255) NOT NULL DEFAULT "",
            `postcode` VARCHAR(32) NOT NULL DEFAULT "",
            `city` VARCHAR(191) NOT NULL DEFAULT "",
            `id_country` INT UNSIGNED NOT NULL DEFAULT 0,
            `date_add` DATETIME NOT NULL,
            `date_upd` DATETIME NOT NULL,
            PRIMARY KEY (`id_supplier`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ');
}

function ensurePurchaseOrderTables(PDO $pdo, string $prefix): void
{
    $carrierTable = $prefix . 'prestashopinventory_carrier';
    $orderTable = $prefix . 'prestashopinventory_purchase_order';
    $itemTable = $prefix . 'prestashopinventory_purchase_order_item';

    $pdo->exec('
        CREATE TABLE IF NOT EXISTS `' . $carrierTable . '` (
            `id_psinv_carrier` INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `name` VARCHAR(191) NOT NULL DEFAULT "",
            `date_add` DATETIME NOT NULL,
            PRIMARY KEY (`id_psinv_carrier`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ');

    $pdo->exec('
        CREATE TABLE IF NOT EXISTS `' . $orderTable . '` (
            `id_purchase_order` INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `reference` VARCHAR(64) NOT NULL,
            `id_supplier` INT UNSIGNED NULL DEFAULT NULL,
            `supplier_name` VARCHAR(255) NOT NULL DEFAULT "",
            `delivery_address` TEXT NULL,
            `ordered_at` DATETIME NULL DEFAULT NULL,
            `delivery_at` DATETIME NULL DEFAULT NULL,
            `shipment_number` VARCHAR(128) NOT NULL DEFAULT "",
            `invoice_number` VARCHAR(128) NOT NULL DEFAULT "",
            `currency_code` VARCHAR(8) NOT NULL DEFAULT "PLN",
            `currency_rate` DECIMAL(20,6) NOT NULL DEFAULT 1.000000,
            `status_key` VARCHAR(32) NOT NULL DEFAULT "draft",
            `incoterm_code` VARCHAR(16) NOT NULL DEFAULT "FOB",
            `transport_cost` DECIMAL(20,6) NOT NULL DEFAULT 0.000000,
            `carrier_name` VARCHAR(191) NOT NULL DEFAULT "",
            `date_add` DATETIME NOT NULL,
            `date_upd` DATETIME NOT NULL,
            PRIMARY KEY (`id_purchase_order`),
            KEY `psinv_purchase_order_supplier` (`id_supplier`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ');

    $pdo->exec('
        CREATE TABLE IF NOT EXISTS `' . $itemTable . '` (
            `id_purchase_order_item` INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `id_purchase_order` INT UNSIGNED NOT NULL,
            `position` INT UNSIGNED NOT NULL DEFAULT 0,
            `id_product` INT UNSIGNED NULL DEFAULT NULL,
            `id_product_attribute` INT UNSIGNED NOT NULL DEFAULT 0,
            `model` VARCHAR(128) NOT NULL DEFAULT "",
            `product_name` VARCHAR(255) NOT NULL DEFAULT "",
            `ean13` VARCHAR(32) NOT NULL DEFAULT "",
            `quantity` DECIMAL(20,3) NOT NULL DEFAULT 0.000,
            `purchase_price` DECIMAL(20,6) NOT NULL DEFAULT 0.000000,
            `weight` DECIMAL(20,6) NOT NULL DEFAULT 0.000000,
            `image_id` INT UNSIGNED NOT NULL DEFAULT 0,
            `date_add` DATETIME NOT NULL,
            `date_upd` DATETIME NOT NULL,
            PRIMARY KEY (`id_purchase_order_item`),
            KEY `psinv_purchase_order_item_order` (`id_purchase_order`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ');
}

function loadExistingSuppliers(PDO $pdo, string $prefix): array
{
    $table = $prefix . 'prestashopinventory_supplier';
    $rows = $pdo->query('SELECT * FROM `' . $table . '`')->fetchAll();
    $indexed = [];
    foreach ($rows as $row) {
        $id = (int) ($row['id_supplier'] ?? 0);
        if ($id > 0) {
            $indexed[$id] = $row;
        }
    }

    return $indexed;
}

function loadExistingOrders(PDO $pdo, string $prefix): array
{
    $table = $prefix . 'prestashopinventory_purchase_order';
    $rows = $pdo->query('SELECT id_purchase_order, reference, supplier_name, ordered_at FROM `' . $table . '`')->fetchAll();
    $indexed = [];
    foreach ($rows as $row) {
        $id = (int) ($row['id_purchase_order'] ?? 0);
        if ($id > 0) {
            $indexed[$id] = $row;
        }
    }

    return $indexed;
}

function importOrder(PDO $pdo, string $prefix, array $order, array $supplier, array $items, array $productsById, array $deliveryAddresses, array $carrierLabels, array $documents): void
{
    $orderId = (int) ($order['id'] ?? 0);
    if ($orderId <= 0) {
        throw new RuntimeException('Nieprawidłowy identyfikator zamówienia.');
    }

    $supplierId = (int) ($supplier['id_supplier'] ?? 0);
    if ($supplierId <= 0) {
        throw new RuntimeException('Brak poprawnego dostawcy dla zamówienia.');
    }

    $transportData = resolveLegacyTransportCost($order, $items, $productsById);
    $items = $transportData['items'];
    $currencyCode = resolveLegacyOrderCurrencyCode($order, $items);
    $currencyRate = (float) ($order['exchange_rate'] ?? 0);
    if ($currencyRate <= 0) {
        $currencyRate = 1.0;
    }

    $orderTable = $prefix . 'prestashopinventory_purchase_order';
    $itemTable = $prefix . 'prestashopinventory_purchase_order_item';
    $reference = buildLegacyOrderReference($orderId);
    $orderedAt = resolveLegacyOrderedAt($order);
    $deliveryAt = resolveLegacyDeliveryAt($order, $orderedAt);
    $statusKey = mapLegacyOrderStatus((string) ($order['status'] ?? ''), loadConfiguredPurchaseOrderStatuses($pdo, $prefix));
    $incotermCode = mapLegacyIncoterm((string) ($order['condition_delivery'] ?? ''));
    $deliveryAddress = resolveLegacyDeliveryAddress((string) ($order['delivery_address'] ?? ''), $deliveryAddresses);
    $carrierName = resolveLegacyCarrierName((string) ($order['carrier'] ?? ''), $carrierLabels);
    $invoiceNumber = resolveLegacyInvoiceNumber($order, $documents);
    $transportCost = $transportData['transport_cost'];

    if ($carrierName !== '') {
        ensureCarrierExists($pdo, $prefix, $carrierName);
    }

    $stmt = $pdo->prepare('
        INSERT INTO `' . $orderTable . '` (
            id_purchase_order,
            reference,
            id_supplier,
            supplier_name,
            delivery_address,
            ordered_at,
            delivery_at,
            shipment_number,
            invoice_number,
            currency_code,
            currency_rate,
            status_key,
            incoterm_code,
            transport_cost,
            carrier_name,
            date_add,
            date_upd
        ) VALUES (
            :id_purchase_order,
            :reference,
            :id_supplier,
            :supplier_name,
            :delivery_address,
            :ordered_at,
            :delivery_at,
            :shipment_number,
            :invoice_number,
            :currency_code,
            :currency_rate,
            :status_key,
            :incoterm_code,
            :transport_cost,
            :carrier_name,
            NOW(),
            NOW()
        )
        ON DUPLICATE KEY UPDATE
            reference = VALUES(reference),
            id_supplier = VALUES(id_supplier),
            supplier_name = VALUES(supplier_name),
            delivery_address = VALUES(delivery_address),
            ordered_at = VALUES(ordered_at),
            delivery_at = VALUES(delivery_at),
            shipment_number = VALUES(shipment_number),
            invoice_number = VALUES(invoice_number),
            currency_code = VALUES(currency_code),
            currency_rate = VALUES(currency_rate),
            status_key = VALUES(status_key),
            incoterm_code = VALUES(incoterm_code),
            transport_cost = VALUES(transport_cost),
            carrier_name = VALUES(carrier_name),
            date_upd = NOW()
    ');
    $stmt->execute([
        ':id_purchase_order' => $orderId,
        ':reference' => $reference,
        ':id_supplier' => $supplierId,
        ':supplier_name' => trim((string) ($supplier['name'] ?? '')),
        ':delivery_address' => $deliveryAddress,
        ':ordered_at' => $orderedAt,
        ':delivery_at' => $deliveryAt,
        ':shipment_number' => trim((string) ($order['package_no'] ?? '')),
        ':invoice_number' => $invoiceNumber,
        ':currency_code' => $currencyCode,
        ':currency_rate' => number_format($currencyRate, 6, '.', ''),
        ':status_key' => $statusKey,
        ':incoterm_code' => $incotermCode,
        ':transport_cost' => number_format($transportCost, 6, '.', ''),
        ':carrier_name' => $carrierName,
    ]);

    $deleteItems = $pdo->prepare('DELETE FROM `' . $itemTable . '` WHERE id_purchase_order = :id_purchase_order');
    $deleteItems->execute([':id_purchase_order' => $orderId]);

    $insertItem = $pdo->prepare('
        INSERT INTO `' . $itemTable . '` (
            id_purchase_order,
            position,
            id_product,
            id_product_attribute,
            model,
            product_name,
            ean13,
            quantity,
            purchase_price,
            weight,
            image_id,
            date_add,
            date_upd
        ) VALUES (
            :id_purchase_order,
            :position,
            :id_product,
            :id_product_attribute,
            :model,
            :product_name,
            :ean13,
            :quantity,
            :purchase_price,
            :weight,
            :image_id,
            NOW(),
            NOW()
        )
    ');

    foreach (array_values($items) as $position => $item) {
        $productId = (int) ($item['products_id'] ?? 0);
        $product = $productsById[$productId] ?? null;
        $matchedProduct = matchPrestashopProduct(
            $pdo,
            $prefix,
            trim((string) ($product['ean'] ?? '')),
            resolveLegacyProductModel($product, $productId)
        );

        $insertItem->execute([
            ':id_purchase_order' => $orderId,
            ':position' => $position + 1,
            ':model' => resolveLegacyProductModel($product, $productId),
            ':product_name' => resolveLegacyProductName($product, $productId),
            ':ean13' => trim((string) ($product['ean'] ?? ($matchedProduct['ean13'] ?? ''))),
            ':quantity' => number_format((float) ($item['quantity'] ?? 0), 3, '.', ''),
            ':purchase_price' => number_format((float) ($item['price'] ?? 0), 6, '.', ''),
            ':weight' => number_format((float) ($product['weight'] ?? ($matchedProduct['weight'] ?? 0)), 6, '.', ''),
            ':id_product' => (int) ($matchedProduct['id_product'] ?? 0) > 0 ? (int) $matchedProduct['id_product'] : null,
            ':id_product_attribute' => (int) ($matchedProduct['id_product_attribute'] ?? 0),
            ':image_id' => (int) ($matchedProduct['image_id'] ?? 0),
        ]);
    }

    $maxOrderId = (int) $pdo->query('SELECT IFNULL(MAX(id_purchase_order), 0) FROM `' . $orderTable . '`')->fetchColumn();
    $pdo->exec('ALTER TABLE `' . $orderTable . '` AUTO_INCREMENT = ' . max(1, $maxOrderId + 1));

    $maxItemId = (int) $pdo->query('SELECT IFNULL(MAX(id_purchase_order_item), 0) FROM `' . $itemTable . '`')->fetchColumn();
    $pdo->exec('ALTER TABLE `' . $itemTable . '` AUTO_INCREMENT = ' . max(1, $maxItemId + 1));
}

function buildLegacyOrderReference(int $orderId): string
{
    return 'CRM-' . $orderId;
}

function resolveLegacyOrderCurrencyCode(array $order, array $items): string
{
    foreach ($items as $item) {
        $code = strtoupper(trim((string) ($item['currency'] ?? '')));
        if ($code !== '') {
            return $code === 'CNY' ? 'CNY' : substr($code, 0, 8);
        }
    }

    return 'PLN';
}

function resolveLegacyOrderedAt(array $order): ?string
{
    $orderedAt = normalizeDateForDb((string) ($order['order_date'] ?? ''));
    if ($orderedAt !== null) {
        return $orderedAt;
    }

    $datetimeChange = trim((string) ($order['datetime_change'] ?? ''));
    if ($datetimeChange !== '' && preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/', $datetimeChange)) {
        return $datetimeChange;
    }

    return null;
}

function resolveLegacyDeliveryAt(array $order, ?string $orderedAt): ?string
{
    $deliveryAt = normalizeDateForDb((string) ($order['delivery_date'] ?? ''));
    if ($deliveryAt !== null) {
        return $deliveryAt;
    }

    return $orderedAt;
}

function resolveLegacyInvoiceNumber(array $order, array $documents): string
{
    $invoiceNumber = trim((string) ($order['invoice_no'] ?? ''));
    if ($invoiceNumber !== '') {
        return $invoiceNumber;
    }

    foreach ($documents as $document) {
        $type = strtolower(trim((string) ($document['type'] ?? '')));
        if (!in_array($type, ['invoice', 'proforma'], true)) {
            continue;
        }

        $filename = trim((string) ($document['filename'] ?? ''));
        if ($filename === '') {
            continue;
        }

        return preg_replace('/\.[A-Za-z0-9]+$/', '', $filename) ?? $filename;
    }

    return '';
}

function resolveLegacyTransportCost(array $order, array $items, array $productsById): array
{
    $transportCost = max(0, (float) ($order['shipping_cost'] ?? 0));
    $filteredItems = [];

    foreach ($items as $item) {
        $product = $productsById[(int) ($item['products_id'] ?? 0)] ?? null;
        $model = strtolower(trim((string) ($product['model'] ?? '')));
        $name = strtolower(trim((string) ($product['name'] ?? '')));
        $namePl = strtolower(trim((string) ($product['name_pl'] ?? '')));
        $haystack = $model . ' ' . $name . ' ' . $namePl;
        $looksLikeTransport = strpos($haystack, 'shipping') !== false
            || strpos($haystack, 'transport') !== false
            || strpos($haystack, 'koszt transportu') !== false
            || $model === 'eur';

        if ($transportCost <= 0 && $looksLikeTransport) {
            $transportCost += (float) ($item['quantity'] ?? 0) * (float) ($item['price'] ?? 0);
            continue;
        }

        $filteredItems[] = $item;
    }

    return [
        'transport_cost' => max(0, $transportCost),
        'items' => $filteredItems,
    ];
}

function resolveLegacyCarrierName(string $carrierKey, array $carrierLabels): string
{
    $carrierKey = trim($carrierKey);
    if ($carrierKey === '') {
        return '';
    }

    return trim((string) ($carrierLabels[$carrierKey] ?? $carrierKey));
}

function ensureCarrierExists(PDO $pdo, string $prefix, string $carrierName): void
{
    $carrierName = trim($carrierName);
    if ($carrierName === '') {
        return;
    }

    $table = $prefix . 'prestashopinventory_carrier';
    $stmt = $pdo->prepare('SELECT id_psinv_carrier FROM `' . $table . '` WHERE name = :name LIMIT 1');
    $stmt->execute([':name' => $carrierName]);
    if ($stmt->fetchColumn()) {
        return;
    }

    $insert = $pdo->prepare('INSERT INTO `' . $table . '` (name, date_add) VALUES (:name, NOW())');
    $insert->execute([':name' => $carrierName]);
}

function resolveLegacyDeliveryAddress(string $rawValue, array $deliveryAddresses): string
{
    $rawValue = trim($rawValue);
    if ($rawValue === '') {
        return '';
    }

    return trim((string) ($deliveryAddresses[$rawValue] ?? $rawValue));
}

function resolveLegacyProductName(?array $product, int $productId): string
{
    if (is_array($product)) {
        $namePl = trim((string) ($product['name_pl'] ?? ''));
        if ($namePl !== '') {
            return $namePl;
        }

        $name = trim((string) ($product['name'] ?? ''));
        if ($name !== '') {
            return $name;
        }
    }

    return 'Produkt CRM #' . $productId;
}

function resolveLegacyProductModel(?array $product, int $productId): string
{
    if (is_array($product)) {
        $model = trim((string) ($product['model'] ?? ''));
        if ($model !== '') {
            return $model;
        }
    }

    return 'CRM-' . $productId;
}

function matchPrestashopProduct(PDO $pdo, string $prefix, string $ean, string $model): ?array
{
    static $cache = [];

    $cacheKey = trim($ean) . '|' . trim($model);
    if (array_key_exists($cacheKey, $cache)) {
        return $cache[$cacheKey];
    }

    $eanDigits = preg_replace('/\D+/', '', $ean);
    $model = trim($model);
    $queries = [];

    if (is_string($eanDigits) && $eanDigits !== '') {
        $queries[] = [
            'sql' => '
                SELECT pa.id_product, pa.id_product_attribute, COALESCE(NULLIF(pa.ean13, ""), p.ean13, "") AS ean13,
                       IFNULL(pa.weight, p.weight) AS weight, IFNULL(MIN(pai.id_image), IFNULL(i.id_image, 0)) AS image_id
                FROM `' . $prefix . 'product_attribute` pa
                INNER JOIN `' . $prefix . 'product` p ON p.id_product = pa.id_product
                LEFT JOIN `' . $prefix . 'product_attribute_image` pai ON pai.id_product_attribute = pa.id_product_attribute
                LEFT JOIN `' . $prefix . 'image` i ON i.id_product = p.id_product AND i.cover = 1
                WHERE REPLACE(REPLACE(TRIM(pa.ean13), " ", ""), "-", "") = :value
                GROUP BY pa.id_product, pa.id_product_attribute
                LIMIT 1
            ',
            'value' => $eanDigits,
        ];
        $queries[] = [
            'sql' => '
                SELECT p.id_product, 0 AS id_product_attribute, COALESCE(NULLIF(p.ean13, ""), "") AS ean13,
                       IFNULL(p.weight, 0) AS weight, IFNULL(i.id_image, 0) AS image_id
                FROM `' . $prefix . 'product` p
                LEFT JOIN `' . $prefix . 'image` i ON i.id_product = p.id_product AND i.cover = 1
                WHERE REPLACE(REPLACE(TRIM(p.ean13), " ", ""), "-", "") = :value
                LIMIT 1
            ',
            'value' => $eanDigits,
        ];
    }

    if ($model !== '') {
        $queries[] = [
            'sql' => '
                SELECT pa.id_product, pa.id_product_attribute, COALESCE(NULLIF(pa.ean13, ""), p.ean13, "") AS ean13,
                       IFNULL(pa.weight, p.weight) AS weight, IFNULL(MIN(pai.id_image), IFNULL(i.id_image, 0)) AS image_id
                FROM `' . $prefix . 'product_attribute` pa
                INNER JOIN `' . $prefix . 'product` p ON p.id_product = pa.id_product
                LEFT JOIN `' . $prefix . 'product_attribute_image` pai ON pai.id_product_attribute = pa.id_product_attribute
                LEFT JOIN `' . $prefix . 'image` i ON i.id_product = p.id_product AND i.cover = 1
                WHERE pa.reference = :value
                GROUP BY pa.id_product, pa.id_product_attribute
                LIMIT 1
            ',
            'value' => $model,
        ];
        $queries[] = [
            'sql' => '
                SELECT p.id_product, 0 AS id_product_attribute, COALESCE(NULLIF(p.ean13, ""), "") AS ean13,
                       IFNULL(p.weight, 0) AS weight, IFNULL(i.id_image, 0) AS image_id
                FROM `' . $prefix . 'product` p
                LEFT JOIN `' . $prefix . 'image` i ON i.id_product = p.id_product AND i.cover = 1
                WHERE p.reference = :value
                LIMIT 1
            ',
            'value' => $model,
        ];
        $queries[] = [
            'sql' => '
                SELECT psl.id_product, psl.id_product_attribute, COALESCE(NULLIF(pa.ean13, ""), p.ean13, "") AS ean13,
                       IFNULL(pa.weight, p.weight) AS weight, IFNULL(MIN(pai.id_image), IFNULL(i.id_image, 0)) AS image_id
                FROM `' . $prefix . 'prestashopinventory_product_logistics` psl
                INNER JOIN `' . $prefix . 'product` p ON p.id_product = psl.id_product
                LEFT JOIN `' . $prefix . 'product_attribute` pa ON pa.id_product_attribute = psl.id_product_attribute
                LEFT JOIN `' . $prefix . 'product_attribute_image` pai ON pai.id_product_attribute = psl.id_product_attribute
                LEFT JOIN `' . $prefix . 'image` i ON i.id_product = p.id_product AND i.cover = 1
                WHERE psl.module_model = :value
                GROUP BY psl.id_product, psl.id_product_attribute
                LIMIT 1
            ',
            'value' => $model,
        ];
    }

    foreach ($queries as $query) {
        $stmt = $pdo->prepare($query['sql']);
        $stmt->execute([':value' => $query['value']]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if (is_array($row) && (int) ($row['id_product'] ?? 0) > 0) {
            $cache[$cacheKey] = [
                'id_product' => (int) ($row['id_product'] ?? 0),
                'id_product_attribute' => (int) ($row['id_product_attribute'] ?? 0),
                'ean13' => trim((string) ($row['ean13'] ?? '')),
                'weight' => (float) ($row['weight'] ?? 0),
                'image_id' => (int) ($row['image_id'] ?? 0),
            ];

            return $cache[$cacheKey];
        }
    }

    $cache[$cacheKey] = null;

    return null;
}

function loadConfiguredPurchaseOrderStatuses(PDO $pdo, string $prefix): array
{
    $table = $prefix . 'configuration';
    $stmt = $pdo->prepare('SELECT value FROM `' . $table . '` WHERE name = :name LIMIT 1');
    $stmt->execute([':name' => 'PSINV_PURCHASE_ORDER_STATUSES']);
    $stored = $stmt->fetchColumn();

    $defaults = [
        ['key' => 'draft', 'label' => 'Szkic'],
        ['key' => 'ordered', 'label' => 'Zamówione'],
        ['key' => 'paid', 'label' => 'Opłacone'],
        ['key' => 'shipped', 'label' => 'Wysłane'],
        ['key' => 'delivered', 'label' => 'Dostarczone'],
        ['key' => 'ready_for_accounting', 'label' => 'Gotowe do księgowania'],
        ['key' => 'finished', 'label' => 'Zakończone'],
    ];

    if (!is_string($stored) || trim($stored) === '') {
        return $defaults;
    }

    $decoded = json_decode($stored, true);
    if (!is_array($decoded) || $decoded === []) {
        return $defaults;
    }

    $statuses = [];
    foreach ($decoded as $row) {
        if (!is_array($row)) {
            continue;
        }

        $key = trim((string) ($row['key'] ?? ''));
        $label = trim((string) ($row['label'] ?? ''));
        if ($key === '') {
            continue;
        }

        $statuses[] = [
            'key' => $key,
            'label' => $label,
        ];
    }

    return $statuses !== [] ? $statuses : $defaults;
}

function mapLegacyOrderStatus(string $legacyStatus, array $configuredStatuses): string
{
    $legacyStatus = strtolower(trim($legacyStatus));
    $preferredKeys = [
        'new' => 'draft',
        'nowy' => 'draft',
        'nowe' => 'draft',
        'ordered' => 'ordered',
        'zamowione' => 'ordered',
        'zamówione' => 'ordered',
        'zamowiony' => 'ordered',
        'zamówiony' => 'ordered',
        'paid' => 'paid',
        'oplacone' => 'paid',
        'opłacone' => 'paid',
        'zaplacone' => 'paid',
        'zapłacone' => 'paid',
        'shipped' => 'shipped',
        'wyslane' => 'shipped',
        'wysłane' => 'shipped',
        'wyslany' => 'shipped',
        'wysłany' => 'shipped',
        'delivered' => 'delivered',
        'dostarczone' => 'delivered',
        'ready_for_accounting' => 'ready_for_accounting',
        'zaksiegowane' => 'finished',
        'zaksięgowane' => 'finished',
        'zaksiegowany' => 'finished',
        'zaksięgowany' => 'finished',
        'finished' => 'finished',
        'completed' => 'finished',
        'zakonczone' => 'finished',
        'zakończone' => 'finished',
    ];

    $desiredKey = $preferredKeys[$legacyStatus] ?? 'draft';
    $availableKeys = [];
    foreach ($configuredStatuses as $status) {
        $key = trim((string) ($status['key'] ?? ''));
        if ($key !== '') {
            $availableKeys[$key] = true;
        }
    }

    if (isset($availableKeys[$desiredKey])) {
        return $desiredKey;
    }

    $labelSynonyms = [
        'draft' => ['szkic', 'robocze', 'nowe', 'nowy'],
        'ordered' => ['zamowione', 'zamówione', 'zamowiony', 'zamówiony', 'ordered'],
        'paid' => ['oplacone', 'opłacone', 'zaplacone', 'zapłacone', 'paid'],
        'shipped' => ['wyslane', 'wysłane', 'wyslany', 'wysłany', 'shipped'],
        'delivered' => ['dostarczone', 'dostarczony', 'delivered'],
        'ready_for_accounting' => ['gotowe do księgowania', 'ksiegowosc', 'księgowość'],
        'finished' => ['zaksiegowane', 'zaksięgowane', 'zaksiegowany', 'zaksięgowany', 'zakonczone', 'zakończone', 'zakonczony', 'zakończony', 'finished', 'completed'],
    ];

    $needles = $labelSynonyms[$desiredKey] ?? [];
    foreach ($configuredStatuses as $status) {
        $key = trim((string) ($status['key'] ?? ''));
        $label = strtolower(trim((string) ($status['label'] ?? '')));
        if ($key === '' || $label === '') {
            continue;
        }

        foreach ($needles as $needle) {
            $contains = function_exists('mb_strpos')
                ? mb_strpos($label, $needle) !== false
                : strpos($label, $needle) !== false;
            if ($needle !== '' && $contains) {
                return $key;
            }
        }
    }

    return (string) ($configuredStatuses[0]['key'] ?? 'draft');
}

function mapLegacyIncoterm(string $legacyCode): string
{
    $legacyCode = strtoupper(trim($legacyCode));
    $allowed = ['FCA', 'FOB', 'DAP', 'EXW', 'DDP', 'CIF', 'CIP', 'CPT', 'FAS', 'CFR'];
    if (in_array($legacyCode, $allowed, true)) {
        return $legacyCode;
    }

    if ($legacyCode === 'WNT') {
        return 'DAP';
    }

    return 'FOB';
}

function buildMappedIncotermLabel(string $legacyCode, string $targetCode): string
{
    $legacyCode = strtoupper(trim($legacyCode));
    if ($legacyCode === '') {
        return $targetCode;
    }

    if ($legacyCode === $targetCode) {
        return $targetCode;
    }

    return $legacyCode . ' -> ' . $targetCode;
}

function normalizeDateForDb(string $date): ?string
{
    $date = trim($date);
    if ($date === '') {
        return null;
    }

    if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
        return $date . ' 00:00:00';
    }

    return null;
}

function formatMoney(float $amount, string $currencyCode): string
{
    return number_format($amount, 2, ',', ' ') . ' ' . strtoupper(trim($currencyCode));
}

function formatDecimal(float $value): string
{
    $formatted = number_format($value, 3, '.', '');
    $formatted = rtrim(rtrim($formatted, '0'), '.');

    return $formatted !== '' ? $formatted : '0';
}

function truncateText(string $value, int $limit): string
{
    $value = trim($value);
    if ($value === '') {
        return '';
    }

    if (function_exists('mb_strlen') && function_exists('mb_substr')) {
        if (mb_strlen($value) <= $limit) {
            return $value;
        }

        return (string) mb_substr($value, 0, $limit - 1) . '…';
    }

    if (strlen($value) <= $limit) {
        return $value;
    }

    return substr($value, 0, $limit - 1) . '...';
}
