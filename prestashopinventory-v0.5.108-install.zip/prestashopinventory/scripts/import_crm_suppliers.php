<?php

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    fwrite(STDERR, "This script must be run from CLI.\n");
    exit(1);
}

$options = getopt('', [
    'dump:',
    'ps-config::',
    'dsn::',
    'host::',
    'port::',
    'db::',
    'user::',
    'pass::',
    'prefix::',
]);

$dumpPath = isset($options['dump']) ? trim((string) $options['dump']) : '';
if ($dumpPath === '' || !is_file($dumpPath)) {
    fwrite(STDERR, "Usage:\n");
    fwrite(STDERR, "  php scripts/import_crm_suppliers.php --dump=/path/to/crm.sql --ps-config=/path/to/prestashop/config/settings.inc.php\n");
    fwrite(STDERR, "  php scripts/import_crm_suppliers.php --dump=/path/to/crm.sql --host=127.0.0.1 --db=prestashop --user=root --pass=secret --prefix=ps_\n");
    exit(1);
}

$pdo = createPdo($options);
$prefix = resolvePrefix($options);

$suppliers = parseSuppliersFromDump($dumpPath);
if ($suppliers === []) {
    fwrite(STDERR, "No suppliers found in dump.\n");
    exit(1);
}

ensureModuleSupplierTable($pdo, $prefix);

$defaultCountryId = resolveDefaultCountryId($pdo, $prefix);
$countryMap = buildCountryMap($pdo, $prefix);
$targetTable = $prefix . 'prestashopinventory_supplier';

$sql = '
    INSERT INTO `' . $targetTable . '` (
        id_supplier,
        name,
        description,
        active,
        phone,
        email,
        address1,
        address2,
        postcode,
        city,
        id_country,
        date_add,
        date_upd
    ) VALUES (
        :id_supplier,
        :name,
        :description,
        :active,
        :phone,
        :email,
        :address1,
        :address2,
        :postcode,
        :city,
        :id_country,
        NOW(),
        NOW()
    )
    ON DUPLICATE KEY UPDATE
        name = VALUES(name),
        description = VALUES(description),
        active = VALUES(active),
        phone = VALUES(phone),
        email = VALUES(email),
        address1 = VALUES(address1),
        address2 = VALUES(address2),
        postcode = VALUES(postcode),
        city = VALUES(city),
        id_country = VALUES(id_country),
        date_upd = NOW()
';

$stmt = $pdo->prepare($sql);
$imported = 0;

foreach ($suppliers as $supplier) {
    $countryCode = strtoupper(trim((string) ($supplier['country_code'] ?? '')));
    $countryId = $countryCode !== '' && isset($countryMap[$countryCode])
        ? $countryMap[$countryCode]
        : $defaultCountryId;

    $stmt->execute([
        ':id_supplier' => (int) $supplier['id'],
        ':name' => trim((string) ($supplier['name'] ?? '')),
        ':description' => '',
        ':active' => 1,
        ':phone' => trim((string) ($supplier['phone'] ?? '')),
        ':email' => trim((string) ($supplier['email'] ?? '')),
        ':address1' => trim((string) ($supplier['street'] ?? '')),
        ':address2' => '',
        ':postcode' => trim((string) ($supplier['postcode'] ?? '')),
        ':city' => trim((string) ($supplier['city'] ?? '')),
        ':id_country' => $countryId,
    ]);

    $imported++;
}

$maxId = (int) $pdo->query('SELECT IFNULL(MAX(id_supplier), 0) FROM `' . $targetTable . '`')->fetchColumn();
$pdo->exec('ALTER TABLE `' . $targetTable . '` AUTO_INCREMENT = ' . max(1, $maxId + 1));

fwrite(STDOUT, "Imported {$imported} suppliers into {$targetTable}.\n");
fwrite(STDOUT, "Preserved CRM supplier IDs for future order migration.\n");

function createPdo(array $options): PDO
{
    if (!empty($options['ps-config'])) {
        $configPath = trim((string) $options['ps-config']);
        if (!is_file($configPath)) {
            throw new RuntimeException('PrestaShop config file not found: ' . $configPath);
        }

        require $configPath;

        $server = defined('_DB_SERVER_') ? (string) _DB_SERVER_ : '';
        $name = defined('_DB_NAME_') ? (string) _DB_NAME_ : '';
        $user = defined('_DB_USER_') ? (string) _DB_USER_ : '';
        $pass = defined('_DB_PASSWD_') ? (string) _DB_PASSWD_ : '';
        $port = 3306;

        if ($server === '' || $name === '' || $user === '') {
            throw new RuntimeException('Could not read DB credentials from PrestaShop config.');
        }

        if (strpos($server, ':') !== false) {
            [$server, $portValue] = explode(':', $server, 2);
            $port = (int) $portValue > 0 ? (int) $portValue : 3306;
        }

        $dsn = sprintf('mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4', $server, $port, $name);

        return new PDO($dsn, $user, $pass, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);
    }

    if (!empty($options['dsn'])) {
        return new PDO((string) $options['dsn'], (string) ($options['user'] ?? ''), (string) ($options['pass'] ?? ''), [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);
    }

    $host = trim((string) ($options['host'] ?? '127.0.0.1'));
    $port = (int) ($options['port'] ?? 3306);
    $db = trim((string) ($options['db'] ?? ''));
    $user = trim((string) ($options['user'] ?? ''));
    $pass = (string) ($options['pass'] ?? '');

    if ($db === '' || $user === '') {
        throw new RuntimeException('Missing DB connection options. Provide --ps-config or --host/--db/--user/--pass.');
    }

    $dsn = sprintf('mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4', $host, $port > 0 ? $port : 3306, $db);

    return new PDO($dsn, $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
}

function resolvePrefix(array $options): string
{
    if (!empty($options['prefix'])) {
        return (string) $options['prefix'];
    }

    if (defined('_DB_PREFIX_')) {
        return (string) _DB_PREFIX_;
    }

    return 'ps_';
}

function parseSuppliersFromDump(string $dumpPath): array
{
    $sql = (string) file_get_contents($dumpPath);
    if ($sql === '') {
        return [];
    }

    if (!preg_match('/INSERT INTO `suppliers` VALUES\s*(.+?);/s', $sql, $matches)) {
        return [];
    }

    $rowsSql = trim((string) $matches[1]);
    $tuples = splitSqlTuples($rowsSql);
    $suppliers = [];

    foreach ($tuples as $tuple) {
        $values = str_getcsv($tuple, ',', "'", "\\");
        if (count($values) < 8) {
            continue;
        }

        $suppliers[] = [
            'id' => normalizeSqlValue($values[0]),
            'name' => normalizeSqlValue($values[1]),
            'street' => normalizeSqlValue($values[2]),
            'city' => normalizeSqlValue($values[3]),
            'postcode' => normalizeSqlValue($values[4]),
            'country_code' => normalizeSqlValue($values[5]),
            'phone' => normalizeSqlValue($values[6]),
            'email' => normalizeSqlValue($values[7]),
        ];
    }

    return $suppliers;
}

function splitSqlTuples(string $rowsSql): array
{
    $rowsSql = trim($rowsSql);
    $length = strlen($rowsSql);
    $tuples = [];
    $buffer = '';
    $depth = 0;
    $inString = false;
    $prevChar = '';

    for ($i = 0; $i < $length; $i++) {
        $char = $rowsSql[$i];

        if ($char === "'" && $prevChar !== '\\') {
            $inString = !$inString;
        }

        if (!$inString) {
            if ($char === '(') {
                $depth++;
                if ($depth === 1) {
                    $buffer = '';
                    $prevChar = $char;
                    continue;
                }
            } elseif ($char === ')') {
                $depth--;
                if ($depth === 0) {
                    $tuples[] = $buffer;
                    $buffer = '';
                    $prevChar = $char;
                    continue;
                }
            }
        }

        if ($depth >= 1) {
            $buffer .= $char;
        }

        $prevChar = $char;
    }

    return $tuples;
}

function normalizeSqlValue(string $value)
{
    $trimmed = trim($value);
    if (strcasecmp($trimmed, 'NULL') === 0) {
        return null;
    }

    return str_replace("\\'", "'", $trimmed);
}

function ensureModuleSupplierTable(PDO $pdo, string $prefix): void
{
    $table = $prefix . 'prestashopinventory_supplier';
    $pdo->exec('
        CREATE TABLE IF NOT EXISTS `' . $table . '` (
            `id_supplier` INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `name` VARCHAR(191) NOT NULL DEFAULT "",
            `description` TEXT NULL,
            `active` TINYINT(1) NOT NULL DEFAULT 1,
            `phone` VARCHAR(64) NOT NULL DEFAULT "",
            `email` VARCHAR(191) NOT NULL DEFAULT "",
            `address1` VARCHAR(255) NOT NULL DEFAULT "",
            `address2` VARCHAR(255) NOT NULL DEFAULT "",
            `postcode` VARCHAR(32) NOT NULL DEFAULT "",
            `city` VARCHAR(191) NOT NULL DEFAULT "",
            `id_country` INT UNSIGNED NOT NULL DEFAULT 0,
            `date_add` DATETIME NOT NULL,
            `date_upd` DATETIME NOT NULL,
            PRIMARY KEY (`id_supplier`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ');
}

function resolveDefaultCountryId(PDO $pdo, string $prefix): int
{
    $configTable = $prefix . 'configuration';
    $stmt = $pdo->prepare('SELECT value FROM `' . $configTable . '` WHERE name = :name LIMIT 1');
    $stmt->execute([':name' => 'PS_COUNTRY_DEFAULT']);
    $value = $stmt->fetchColumn();

    return (int) $value > 0 ? (int) $value : 0;
}

function buildCountryMap(PDO $pdo, string $prefix): array
{
    $table = $prefix . 'country';
    $rows = $pdo->query('SELECT id_country, iso_code FROM `' . $table . '`')->fetchAll();
    $map = [];

    foreach ($rows as $row) {
        $iso = strtoupper(trim((string) ($row['iso_code'] ?? '')));
        $id = (int) ($row['id_country'] ?? 0);
        if ($iso !== '' && $id > 0) {
            $map[$iso] = $id;
        }
    }

    return $map;
}
