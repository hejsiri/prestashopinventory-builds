<?php

declare(strict_types=1);

session_start();

$flash = $_SESSION['crm_supplier_import_flash'] ?? null;
unset($_SESSION['crm_supplier_import_flash']);

$dumpPath = trim((string) ($_REQUEST['dump'] ?? ''));
$dbHost = trim((string) ($_REQUEST['db_host'] ?? 'localhost'));
$dbPort = trim((string) ($_REQUEST['db_port'] ?? ''));
$dbName = trim((string) ($_REQUEST['db_name'] ?? ''));
$dbUser = trim((string) ($_REQUEST['db_user'] ?? ''));
$dbPass = (string) ($_REQUEST['db_pass'] ?? '');
$dbPrefix = trim((string) ($_REQUEST['db_prefix'] ?? ''));
$errors = [];
$success = null;
$suppliers = [];
$existingSuppliers = [];
$countryMap = [];
$countryLabels = [];
$countryOptions = [];
$defaultCountryId = 0;
$prefix = '';
$configPath = null;

try {
    if ($dbName !== '' && $dbUser !== '') {
        $config = [
            'host' => $dbHost !== '' ? $dbHost : 'localhost',
            'port' => $dbPort !== '' ? (int) $dbPort : 3306,
            'db' => $dbName,
            'user' => $dbUser,
            'pass' => $dbPass,
            'prefix' => $dbPrefix !== '' ? $dbPrefix : 'ps_',
        ];
    } else {
        $configPath = detectPrestashopConfig();
        if ($configPath === null) {
            throw new RuntimeException('Nie udało się automatycznie odnaleźć konfiguracji PrestaShop. Wpisz ręcznie dane DB poniżej.');
        }

        $config = loadPrestashopConfig($configPath);
        $dbHost = (string) ($config['host'] ?? 'localhost');
        $dbPort = (string) ((int) ($config['port'] ?? 3306) ?: '');
        $dbName = (string) ($config['db'] ?? '');
        $dbUser = (string) ($config['user'] ?? '');
        $dbPass = (string) ($config['pass'] ?? '');
        $dbPrefix = (string) ($config['prefix'] ?? 'ps_');
    }

    $prefix = $config['prefix'];
    $pdo = createPdoFromConfig($config);
    ensureModuleSupplierTable($pdo, $prefix);
    ensureModuleSupplierTableColumns($pdo, $prefix);
    $countryMap = buildCountryMap($pdo, $prefix);
    $countryLabels = buildCountryLabels($pdo, $prefix);
    $countryOptions = buildCountryOptions($pdo, $prefix);
    $defaultCountryId = resolveDefaultCountryId($pdo, $prefix);

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $action = trim((string) ($_POST['action'] ?? ''));
        $dumpPath = trim((string) ($_POST['dump'] ?? ''));
        $dbHost = trim((string) ($_POST['db_host'] ?? $dbHost));
        $dbPort = trim((string) ($_POST['db_port'] ?? $dbPort));
        $dbName = trim((string) ($_POST['db_name'] ?? $dbName));
        $dbUser = trim((string) ($_POST['db_user'] ?? $dbUser));
        $dbPass = (string) ($_POST['db_pass'] ?? $dbPass);
        $dbPrefix = trim((string) ($_POST['db_prefix'] ?? $dbPrefix));

        $resolvedDumpPath = resolveDumpPath($dumpPath);
        if ($resolvedDumpPath === null) {
            throw new RuntimeException('Podaj poprawną ścieżkę do pliku SQL na serwerze.');
        }

        $parsedSuppliers = parseSuppliersFromDump($resolvedDumpPath);
        if ($parsedSuppliers === []) {
            throw new RuntimeException('Nie znaleziono tabeli `suppliers` w podanym dumpie.');
        }

        if ($action === 'import_one') {
            $supplierId = (int) ($_POST['supplier_id'] ?? 0);
            $targetCountryId = (int) ($_POST['target_country_id'] ?? 0);
            $supplier = null;
            foreach ($parsedSuppliers as $candidate) {
                if ((int) ($candidate['id'] ?? 0) === $supplierId) {
                    $supplier = $candidate;
                    break;
                }
            }

            if ($supplier === null) {
                throw new RuntimeException('Nie znaleziono wybranego dostawcy w dumpie.');
            }

            importSupplier($pdo, $prefix, $supplier, $countryMap, $defaultCountryId, $targetCountryId);
            $_SESSION['crm_supplier_import_flash'] = [
                'type' => 'success',
                'message' => 'Przeniesiono dostawcę ID ' . $supplierId . ': ' . (string) ($supplier['name'] ?? ''),
            ];

            header('Location: ' . buildSelfUrl([
                'dump' => $dumpPath,
                'db_host' => $dbHost,
                'db_port' => $dbPort,
                'db_name' => $dbName,
                'db_user' => $dbUser,
                'db_pass' => $dbPass,
                'db_prefix' => $dbPrefix,
            ]));
            exit;
        }
    }

    if ($dumpPath !== '') {
        $resolvedDumpPath = resolveDumpPath($dumpPath);
        if ($resolvedDumpPath === null) {
            $errors[] = 'Plik dumpa nie istnieje: ' . $dumpPath;
        } else {
            $suppliers = parseSuppliersFromDump($resolvedDumpPath);
            $existingSuppliers = loadExistingSuppliers($pdo, $prefix);
            if ($suppliers === []) {
                $errors[] = 'Nie znaleziono tabeli `suppliers` w podanym dumpie.';
            }
        }
    }
} catch (Throwable $e) {
    $errors[] = $e->getMessage();
}

if (is_array($flash)) {
    if (($flash['type'] ?? '') === 'success') {
        $success = (string) ($flash['message'] ?? '');
    } else {
        $errors[] = (string) ($flash['message'] ?? '');
    }
}

header('Content-Type: text/html; charset=utf-8');

?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="utf-8">
    <title>Import dostawców CRM</title>
    <style>
        body {
            margin: 0;
            padding: 24px;
            font-family: Arial, sans-serif;
            background: #f5f7fa;
            color: #1f2933;
        }
        .wrap {
            max-width: 1500px;
            margin: 0 auto;
        }
        .card {
            background: #fff;
            border: 1px solid #d9e2ec;
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(15, 23, 42, 0.06);
            padding: 20px;
            margin-bottom: 20px;
        }
        h1 {
            margin: 0 0 10px;
            font-size: 28px;
        }
        p.note {
            margin: 0;
            color: #52606d;
        }
        .note-strong {
            margin-top: 10px;
            color: #1f2933;
            font-size: 13px;
        }
        .form-row {
            display: grid;
            grid-template-columns: 1fr auto;
            gap: 12px;
            align-items: end;
        }
        .form-grid {
            display: grid;
            grid-template-columns: repeat(4, minmax(0, 1fr));
            gap: 12px;
            margin-top: 16px;
        }
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 700;
        }
        input[type="text"],
        input[type="password"] {
            width: 100%;
            height: 46px;
            box-sizing: border-box;
            border: 1px solid #bcccdc;
            border-radius: 8px;
            padding: 0 14px;
            font-size: 15px;
        }
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            height: 46px;
            border: 1px solid transparent;
            border-radius: 8px;
            padding: 0 18px;
            font-size: 15px;
            font-weight: 700;
            cursor: pointer;
            text-decoration: none;
            white-space: nowrap;
        }
        .btn-primary {
            background: #25b9d7;
            border-color: #25b9d7;
            color: #fff;
        }
        .btn-secondary {
            background: #fff;
            border-color: #bcccdc;
            color: #52606d;
        }
        .btn-row {
            display: flex;
            gap: 8px;
            align-items: center;
            justify-content: flex-end;
        }
        .alert {
            border-radius: 10px;
            padding: 14px 16px;
            margin-bottom: 16px;
        }
        .alert-success {
            background: #ecfdf3;
            color: #166534;
            border: 1px solid #86efac;
        }
        .alert-danger {
            background: #fef2f2;
            color: #991b1b;
            border: 1px solid #fca5a5;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 14px;
        }
        th, td {
            padding: 12px 10px;
            border-bottom: 1px solid #e5e7eb;
            vertical-align: top;
            text-align: left;
        }
        th {
            font-size: 13px;
            text-transform: uppercase;
            letter-spacing: 0.04em;
            color: #52606d;
            background: #f8fafc;
        }
        .status {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            border-radius: 999px;
            padding: 4px 10px;
            font-size: 12px;
            font-weight: 700;
        }
        .status-new {
            background: #eff6ff;
            color: #1d4ed8;
        }
        .status-update {
            background: #fff7ed;
            color: #c2410c;
        }
        .muted {
            color: #7b8794;
        }
        .mono {
            font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
            font-size: 12px;
        }
        .small {
            font-size: 12px;
        }
        .cell-lines div + div {
            margin-top: 4px;
        }
        .table-wrap {
            overflow-x: auto;
            overflow-y: visible;
        }
        @media (max-width: 960px) {
            body {
                padding: 12px;
            }
            .form-row {
                grid-template-columns: 1fr;
            }
            .form-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
<div class="wrap">
    <div class="card">
        <h1>Import dostawców CRM</h1>
        <p class="note">To narzędzie czyta tabelę <span class="mono">suppliers</span> ze starego dumpa CRM i przenosi dostawców pojedynczo do tabeli modułu <span class="mono"><?= h(($prefix !== '' ? $prefix : 'pr_') . 'prestashopinventory_supplier') ?></span>.</p>
        <?php if ($configPath !== null): ?>
            <div class="note-strong">Wykryta konfiguracja PrestaShop: <span class="mono"><?= h($configPath) ?></span></div>
        <?php else: ?>
            <div class="note-strong">Tryb ręczny DB: używane są dane wpisane w formularzu poniżej.</div>
        <?php endif; ?>
    </div>

    <?php if ($success !== null && $success !== ''): ?>
        <div class="alert alert-success"><?= h($success) ?></div>
    <?php endif; ?>

    <?php foreach ($errors as $error): ?>
        <div class="alert alert-danger"><?= h($error) ?></div>
    <?php endforeach; ?>

    <div class="card">
        <form method="get" action="">
            <div class="form-row">
                <div>
                    <label for="dump">Ścieżka do dumpa SQL na serwerze</label>
                    <input type="text" id="dump" name="dump" value="<?= h($dumpPath) ?>" placeholder="/ścieżka/do/pliku.sql albo sam plik z bieżącego katalogu">
                </div>
                <button type="submit" class="btn btn-primary">Wczytaj podgląd</button>
            </div>
            <div class="form-grid">
                <div>
                    <label for="db_host">DB host</label>
                    <input type="text" id="db_host" name="db_host" value="<?= h($dbHost) ?>" placeholder="localhost">
                </div>
                <div>
                    <label for="db_port">DB port</label>
                    <input type="text" id="db_port" name="db_port" value="<?= h($dbPort) ?>" placeholder="3306">
                </div>
                <div>
                    <label for="db_name">DB name</label>
                    <input type="text" id="db_name" name="db_name" value="<?= h($dbName) ?>">
                </div>
                <div>
                    <label for="db_prefix">DB prefix</label>
                    <input type="text" id="db_prefix" name="db_prefix" value="<?= h($dbPrefix) ?>" placeholder="pr_">
                </div>
                <div>
                    <label for="db_user">DB user</label>
                    <input type="text" id="db_user" name="db_user" value="<?= h($dbUser) ?>">
                </div>
                <div>
                    <label for="db_pass">DB password</label>
                    <input type="password" id="db_pass" name="db_pass" value="<?= h($dbPass) ?>">
                </div>
            </div>
        </form>
    </div>

    <?php if ($suppliers !== []): ?>
        <div class="card">
            <div style="display:flex;justify-content:space-between;align-items:center;gap:12px;margin-bottom:16px;">
                <div>
                    <strong>Znaleziono dostawców:</strong> <?= count($suppliers) ?>
                </div>
                <div class="small muted">Każdy rekord przenosisz osobno przyciskiem <strong>Przenieś</strong>.</div>
            </div>
            <div class="table-wrap">
                <table>
                    <thead>
                    <tr>
                        <th>ID CRM</th>
                        <th>Status</th>
                        <th>Nazwa</th>
                        <th>Telefon / Email</th>
                        <th>Adres</th>
                        <th>Kraj CRM</th>
                        <th>Kraj docelowy</th>
                        <th>Obecnie w module</th>
                        <th>Akcja</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($suppliers as $supplier): ?>
                        <?php
                        $supplierId = (int) ($supplier['id'] ?? 0);
                        $existing = $existingSuppliers[$supplierId] ?? null;
                        $countryCode = strtoupper(trim((string) ($supplier['country_code'] ?? '')));
                        $mappedCountryId = $countryCode !== '' && isset($countryMap[$countryCode]) ? $countryMap[$countryCode] : $defaultCountryId;
                        $mappedCountryLabel = $mappedCountryId > 0 ? ($countryLabels[$mappedCountryId] ?? ('ID ' . $mappedCountryId)) : 'Brak mapowania';
                        $statusClass = $existing === null ? 'status-new' : 'status-update';
                        $statusLabel = $existing === null ? 'Nowy' : 'Aktualizacja';
                        $formId = 'import-supplier-' . $supplierId;
                        ?>
                        <tr>
                            <td class="mono"><?= h((string) $supplierId) ?></td>
                            <td><span class="status <?= h($statusClass) ?>"><?= h($statusLabel) ?></span></td>
                            <td>
                                <div><strong><?= h((string) ($supplier['name'] ?? '')) ?></strong></div>
                            </td>
                            <td class="cell-lines">
                                <div><?= h((string) ($supplier['phone'] ?? '—')) ?></div>
                                <div class="muted"><?= h((string) ($supplier['email'] ?? '—')) ?></div>
                            </td>
                            <td class="cell-lines">
                                <div><?= h((string) ($supplier['street'] ?? '—')) ?></div>
                                <div><?= h(trim((string) (($supplier['postcode'] ?? '') . ' ' . ($supplier['city'] ?? ''))) ?: '—') ?></div>
                            </td>
                            <td class="cell-lines">
                                <div><?= h($countryCode !== '' ? $countryCode : '—') ?></div>
                                <div class="muted small"><?= h($mappedCountryLabel) ?></div>
                            </td>
                            <td>
                                <form method="post" action="" style="margin:0;display:none;" id="<?= h($formId) ?>">
                                    <input type="hidden" name="dump" value="<?= h($dumpPath) ?>">
                                    <input type="hidden" name="db_host" value="<?= h($dbHost) ?>">
                                    <input type="hidden" name="db_port" value="<?= h($dbPort) ?>">
                                    <input type="hidden" name="db_name" value="<?= h($dbName) ?>">
                                    <input type="hidden" name="db_user" value="<?= h($dbUser) ?>">
                                    <input type="hidden" name="db_pass" value="<?= h($dbPass) ?>">
                                    <input type="hidden" name="db_prefix" value="<?= h($dbPrefix) ?>">
                                    <input type="hidden" name="supplier_id" value="<?= h((string) $supplierId) ?>">
                                    <input type="hidden" name="action" value="import_one">
                                </form>
                                <select name="target_country_id" form="<?= h($formId) ?>" style="width:100%;min-width:180px;height:40px;border:1px solid #bcccdc;border-radius:8px;padding:0 10px;">
                                        <?php foreach ($countryOptions as $option): ?>
                                            <option value="<?= h((string) $option['id_country']) ?>" <?php if ((int) $option['id_country'] === $mappedCountryId) echo 'selected'; ?>>
                                                <?= h((string) $option['name']) ?>
                                            </option>
                                        <?php endforeach; ?>
                                </select>
                            </td>
                            <td class="cell-lines">
                                <?php if ($existing === null): ?>
                                    <div class="muted">Brak</div>
                                <?php else: ?>
                                    <div><strong><?= h((string) ($existing['name'] ?? '')) ?></strong></div>
                                    <div class="muted small"><?= h((string) ($existing['phone'] ?? '—')) ?> / <?= h((string) ($existing['email'] ?? '—')) ?></div>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="btn-row">
                                    <button type="submit" form="<?= h($formId) ?>" class="btn btn-primary">Przenieś</button>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php endif; ?>
</div>
</body>
</html>
<?php

function h(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}

function buildSelfUrl(array $params = []): string
{
    $path = strtok((string) ($_SERVER['REQUEST_URI'] ?? ''), '?') ?: '';
    $query = http_build_query($params);

    return $query !== '' ? $path . '?' . $query : $path;
}

function detectPrestashopConfig(): ?string
{
    $dir = __DIR__;
    for ($i = 0; $i < 8; $i++) {
        $candidates = [
            $dir . '/config/settings.inc.php',
            $dir . '/app/config/parameters.php',
            $dir . '/app/config/parameters.yml',
            $dir . '/app/config/parameters.yml.dist',
        ];
        foreach ($candidates as $candidate) {
            if (is_file($candidate)) {
                return $candidate;
            }
        }
        $parent = dirname($dir);
        if ($parent === $dir) {
            break;
        }
        $dir = $parent;
    }

    return null;
}

function loadPrestashopConfig(string $configPath): array
{
    $extension = strtolower(pathinfo($configPath, PATHINFO_EXTENSION));

    if ($extension === 'php') {
        require_once $configPath;

        if (defined('_DB_SERVER_') && defined('_DB_NAME_') && defined('_DB_USER_')) {
            $server = (string) _DB_SERVER_;
            $name = (string) _DB_NAME_;
            $user = (string) _DB_USER_;
            $pass = defined('_DB_PASSWD_') ? (string) _DB_PASSWD_ : '';
            $prefix = defined('_DB_PREFIX_') ? (string) _DB_PREFIX_ : 'ps_';
            $port = 3306;

            if (strpos($server, ':') !== false) {
                [$server, $portValue] = explode(':', $server, 2);
                $port = (int) $portValue > 0 ? (int) $portValue : 3306;
            }

            return [
                'host' => $server,
                'port' => $port,
                'db' => $name,
                'user' => $user,
                'pass' => $pass,
                'prefix' => $prefix,
            ];
        }

        $parameters = @include $configPath;
        if (is_array($parameters) && isset($parameters['parameters']) && is_array($parameters['parameters'])) {
            $parameters = $parameters['parameters'];
        }
        if (is_array($parameters)) {
            $server = (string) ($parameters['database_host'] ?? '');
            $name = (string) ($parameters['database_name'] ?? '');
            $user = (string) ($parameters['database_user'] ?? '');
            $pass = (string) ($parameters['database_password'] ?? '');
            $prefix = (string) ($parameters['database_prefix'] ?? 'ps_');
            $port = (int) ($parameters['database_port'] ?? 3306);

            if ($server !== '' && $name !== '' && $user !== '') {
                return [
                    'host' => $server,
                    'port' => $port > 0 ? $port : 3306,
                    'db' => $name,
                    'user' => $user,
                    'pass' => $pass,
                    'prefix' => $prefix !== '' ? $prefix : 'ps_',
                ];
            }
        }
    }

    if (in_array($extension, ['yml', 'yaml', 'dist'], true) || str_ends_with($configPath, '.yml.dist')) {
        $contents = (string) file_get_contents($configPath);
        if ($contents !== '') {
            $map = [];
            foreach ([
                'database_host',
                'database_port',
                'database_name',
                'database_user',
                'database_password',
                'database_prefix',
            ] as $key) {
                if (preg_match('/^\s*' . preg_quote($key, '/') . ':\s*["\']?(.*?)["\']?\s*$/m', $contents, $match)) {
                    $map[$key] = trim((string) $match[1]);
                }
            }

            if (($map['database_host'] ?? '') !== '' && ($map['database_name'] ?? '') !== '' && ($map['database_user'] ?? '') !== '') {
                return [
                    'host' => (string) $map['database_host'],
                    'port' => (int) (($map['database_port'] ?? '3306')) > 0 ? (int) $map['database_port'] : 3306,
                    'db' => (string) $map['database_name'],
                    'user' => (string) $map['database_user'],
                    'pass' => (string) ($map['database_password'] ?? ''),
                    'prefix' => (string) (($map['database_prefix'] ?? 'ps_') !== '' ? $map['database_prefix'] : 'ps_'),
                ];
            }
        }
    }

    throw new RuntimeException('Nie udało się odczytać danych DB z konfiguracji PrestaShop.');
}

function createPdoFromConfig(array $config): PDO
{
    $dsn = sprintf(
        'mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4',
        (string) $config['host'],
        (int) $config['port'],
        (string) $config['db']
    );

    return new PDO($dsn, (string) $config['user'], (string) $config['pass'], [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
}

function resolveDumpPath(string $dumpPath): ?string
{
    $dumpPath = trim($dumpPath);
    if ($dumpPath === '') {
        return null;
    }

    if (is_file($dumpPath)) {
        return $dumpPath;
    }

    $candidate = __DIR__ . '/' . ltrim($dumpPath, '/');
    if (is_file($candidate)) {
        return $candidate;
    }

    return null;
}

function parseSuppliersFromDump(string $dumpPath): array
{
    $sql = (string) file_get_contents($dumpPath);
    if ($sql === '') {
        return [];
    }

    if (!preg_match('/INSERT INTO `suppliers` VALUES\s*(.+?);/s', $sql, $matches)) {
        return [];
    }

    $rowsSql = trim((string) $matches[1]);
    $tuples = splitSqlTuples($rowsSql);
    $suppliers = [];

    foreach ($tuples as $tuple) {
        $values = str_getcsv($tuple, ',', "'", "\\");
        if (count($values) < 8) {
            continue;
        }

        $suppliers[] = [
            'id' => normalizeSqlValue($values[0]),
            'name' => normalizeSqlValue($values[1]),
            'street' => normalizeSqlValue($values[2]),
            'city' => normalizeSqlValue($values[3]),
            'postcode' => normalizeSqlValue($values[4]),
            'country_code' => normalizeSqlValue($values[5]),
            'phone' => normalizeSqlValue($values[6]),
            'email' => normalizeSqlValue($values[7]),
        ];
    }

    return $suppliers;
}

function splitSqlTuples(string $rowsSql): array
{
    $rowsSql = trim($rowsSql);
    $length = strlen($rowsSql);
    $tuples = [];
    $buffer = '';
    $depth = 0;
    $inString = false;
    $prevChar = '';

    for ($i = 0; $i < $length; $i++) {
        $char = $rowsSql[$i];

        if ($char === "'" && $prevChar !== '\\') {
            $inString = !$inString;
        }

        if (!$inString) {
            if ($char === '(') {
                $depth++;
                if ($depth === 1) {
                    $buffer = '';
                    $prevChar = $char;
                    continue;
                }
            } elseif ($char === ')') {
                $depth--;
                if ($depth === 0) {
                    $tuples[] = $buffer;
                    $buffer = '';
                    $prevChar = $char;
                    continue;
                }
            }
        }

        if ($depth >= 1) {
            $buffer .= $char;
        }

        $prevChar = $char;
    }

    return $tuples;
}

function normalizeSqlValue(string $value)
{
    $trimmed = trim($value);
    if (strcasecmp($trimmed, 'NULL') === 0) {
        return null;
    }

    return str_replace("\\'", "'", $trimmed);
}

function ensureModuleSupplierTable(PDO $pdo, string $prefix): void
{
    $table = $prefix . 'prestashopinventory_supplier';
    $pdo->exec('
        CREATE TABLE IF NOT EXISTS `' . $table . '` (
            `id_supplier` INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `name` VARCHAR(191) NOT NULL DEFAULT "",
            `description` TEXT NULL,
            `active` TINYINT(1) NOT NULL DEFAULT 1,
            `phone` VARCHAR(64) NOT NULL DEFAULT "",
            `email` VARCHAR(191) NOT NULL DEFAULT "",
            `address1` VARCHAR(255) NOT NULL DEFAULT "",
            `address2` VARCHAR(255) NOT NULL DEFAULT "",
            `postcode` VARCHAR(32) NOT NULL DEFAULT "",
            `city` VARCHAR(191) NOT NULL DEFAULT "",
            `id_country` INT UNSIGNED NOT NULL DEFAULT 0,
            `date_add` DATETIME NOT NULL,
            `date_upd` DATETIME NOT NULL,
            PRIMARY KEY (`id_supplier`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ');
}

function ensureModuleSupplierTableColumns(PDO $pdo, string $prefix): void
{
    $table = $prefix . 'prestashopinventory_supplier';
    $rows = $pdo->query('SHOW COLUMNS FROM `' . $table . '`')->fetchAll();
    $columns = [];
    foreach ($rows as $row) {
        $field = (string) ($row['Field'] ?? '');
        if ($field !== '') {
            $columns[$field] = true;
        }
    }

    if (!isset($columns['email'])) {
        $pdo->exec('ALTER TABLE `' . $table . '` ADD COLUMN `email` VARCHAR(191) NOT NULL DEFAULT "" AFTER `phone`');
    }
}

function resolveDefaultCountryId(PDO $pdo, string $prefix): int
{
    $table = $prefix . 'configuration';
    $stmt = $pdo->prepare('SELECT value FROM `' . $table . '` WHERE name = :name LIMIT 1');
    $stmt->execute([':name' => 'PS_COUNTRY_DEFAULT']);
    $value = $stmt->fetchColumn();

    return (int) $value > 0 ? (int) $value : 0;
}

function buildCountryMap(PDO $pdo, string $prefix): array
{
    $table = $prefix . 'country';
    $rows = $pdo->query('SELECT id_country, iso_code FROM `' . $table . '`')->fetchAll();
    $map = [];
    foreach ($rows as $row) {
        $iso = strtoupper(trim((string) ($row['iso_code'] ?? '')));
        $id = (int) ($row['id_country'] ?? 0);
        if ($iso !== '' && $id > 0) {
            $map[$iso] = $id;
        }
    }

    return $map;
}

function buildCountryLabels(PDO $pdo, string $prefix): array
{
    $countryTable = $prefix . 'country';
    $countryLangTable = $prefix . 'country_lang';
    $langId = resolveDefaultLanguageId($pdo, $prefix);
    $stmt = $pdo->prepare('
        SELECT c.id_country, cl.name
        FROM `' . $countryTable . '` c
        LEFT JOIN `' . $countryLangTable . '` cl ON cl.id_country = c.id_country AND cl.id_lang = :id_lang
    ');
    $stmt->execute([':id_lang' => $langId]);
    $rows = $stmt->fetchAll();
    $labels = [];

    foreach ($rows as $row) {
        $id = (int) ($row['id_country'] ?? 0);
        if ($id > 0) {
            $labels[$id] = trim((string) ($row['name'] ?? ''));
        }
    }

    return $labels;
}

function buildCountryOptions(PDO $pdo, string $prefix): array
{
    $countryTable = $prefix . 'country';
    $countryLangTable = $prefix . 'country_lang';
    $langId = resolveDefaultLanguageId($pdo, $prefix);
    $stmt = $pdo->prepare('
        SELECT c.id_country, cl.name
        FROM `' . $countryTable . '` c
        LEFT JOIN `' . $countryLangTable . '` cl ON cl.id_country = c.id_country AND cl.id_lang = :id_lang
        WHERE c.active = 1
        ORDER BY cl.name ASC
    ');
    $stmt->execute([':id_lang' => $langId]);

    return array_map(static function (array $row): array {
        return [
            'id_country' => (int) ($row['id_country'] ?? 0),
            'name' => trim((string) ($row['name'] ?? '')),
        ];
    }, $stmt->fetchAll());
}

function resolveDefaultLanguageId(PDO $pdo, string $prefix): int
{
    $table = $prefix . 'configuration';
    $stmt = $pdo->prepare('SELECT value FROM `' . $table . '` WHERE name = :name LIMIT 1');
    $stmt->execute([':name' => 'PS_LANG_DEFAULT']);
    $value = $stmt->fetchColumn();

    return (int) $value > 0 ? (int) $value : 1;
}

function loadExistingSuppliers(PDO $pdo, string $prefix): array
{
    $table = $prefix . 'prestashopinventory_supplier';
    $rows = $pdo->query('SELECT * FROM `' . $table . '`')->fetchAll();
    $indexed = [];
    foreach ($rows as $row) {
        $id = (int) ($row['id_supplier'] ?? 0);
        if ($id > 0) {
            $indexed[$id] = $row;
        }
    }

    return $indexed;
}

function importSupplier(PDO $pdo, string $prefix, array $supplier, array $countryMap, int $defaultCountryId, int $forcedCountryId = 0): void
{
    $table = $prefix . 'prestashopinventory_supplier';
    $countryCode = strtoupper(trim((string) ($supplier['country_code'] ?? '')));
    $countryId = $forcedCountryId > 0
        ? $forcedCountryId
        : ($countryCode !== '' && isset($countryMap[$countryCode]) ? $countryMap[$countryCode] : $defaultCountryId);

    $stmt = $pdo->prepare('
        INSERT INTO `' . $table . '` (
            id_supplier,
            name,
            description,
            active,
            phone,
            email,
            address1,
            address2,
            postcode,
            city,
            id_country,
            date_add,
            date_upd
        ) VALUES (
            :id_supplier,
            :name,
            :description,
            :active,
            :phone,
            :email,
            :address1,
            :address2,
            :postcode,
            :city,
            :id_country,
            NOW(),
            NOW()
        )
        ON DUPLICATE KEY UPDATE
            name = VALUES(name),
            description = VALUES(description),
            active = VALUES(active),
            phone = VALUES(phone),
            email = VALUES(email),
            address1 = VALUES(address1),
            address2 = VALUES(address2),
            postcode = VALUES(postcode),
            city = VALUES(city),
            id_country = VALUES(id_country),
            date_upd = NOW()
    ');

    $stmt->execute([
        ':id_supplier' => (int) ($supplier['id'] ?? 0),
        ':name' => trim((string) ($supplier['name'] ?? '')),
        ':description' => '',
        ':active' => 1,
        ':phone' => trim((string) ($supplier['phone'] ?? '')),
        ':email' => trim((string) ($supplier['email'] ?? '')),
        ':address1' => trim((string) ($supplier['street'] ?? '')),
        ':address2' => '',
        ':postcode' => trim((string) ($supplier['postcode'] ?? '')),
        ':city' => trim((string) ($supplier['city'] ?? '')),
        ':id_country' => $countryId,
    ]);

    $maxId = (int) $pdo->query('SELECT IFNULL(MAX(id_supplier), 0) FROM `' . $table . '`')->fetchColumn();
    $pdo->exec('ALTER TABLE `' . $table . '` AUTO_INCREMENT = ' . max(1, $maxId + 1));
}
