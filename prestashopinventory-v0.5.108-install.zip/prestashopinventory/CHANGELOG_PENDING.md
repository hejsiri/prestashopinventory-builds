# Wpisz tu zmiany do następnego release (jedna linia = jeden bullet)
# Przykład:
# Poprawa walidacji wymiarów w modalu produktu.
# Usunięcie znaku % z nagłówka kolumny Cło.
Nowe zamówienia zakupowe są tworzone bez przykładowych produktów.
Nawigacja w podglądzie zamówienia pozwala przechodzić do starszego i nowszego zamówienia przyciskami obok powrotu do listy.
Importer zamówień CRM poprawnie mapuje status zaksięgowane na status zakończone zgodnie z konfiguracją modułu.
