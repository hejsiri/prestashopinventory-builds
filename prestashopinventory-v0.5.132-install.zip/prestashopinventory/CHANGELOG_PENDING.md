# Wpisz tu zmiany do następnego release (jedna linia = jeden bullet)
# Przykład:
# Poprawa walidacji wymiarów w modalu produktu.
# Usunięcie znaku % z nagłówka kolumny Cło.
Zmiana kolejności ikon w akacjach listy zamówień tak, aby śledzenie było na drugim miejscu.
