<?php
declare(strict_types=1);

namespace PrestaShop\Module\PrestashopInventory\Controller\Admin;

use PrestaShopBundle\Security\Annotation\AdminSecurity;
use Symfony\Component\HttpFoundation\Response;

class WarehouseController extends AbstractInventoryController
{
    public const TAB_CLASS_NAME = 'AdminPrestashopInventory';

    /**
     * @AdminSecurity("is_granted('read', request.get('_legacy_controller'))")
     */
    public function indexAction(): Response
    {
        return $this->renderInventoryPage(
            '@Modules/prestashopinventory/views/templates/admin-modern/warehouse.html.twig',
            'prestashop_inventory_products',
            'products_tab',
            [
                'migrationNotice' => $this->translate('products_migration_notice'),
            ]
        );
    }
}
