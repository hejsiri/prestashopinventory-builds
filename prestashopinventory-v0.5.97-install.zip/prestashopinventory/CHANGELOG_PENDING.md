Poprawiono ikonę Edytuj na stronie Produkty: usunięto błąd renderScannerState is not defined blokujący otwieranie popupu.
Funkcje modala skanera (open/render) wystawione przez aliasy na window dla stabilnego działania w Safari.
