<?php

class PrestashopInventoryI18n
{
    private const DICTIONARY = [
        'en' => [
            'warehouse_tab' => 'Warehouse',
            'settings_tab' => 'Settings',
            'inventory_report' => 'Inventory report',
            'new_warehouse_view_scaffold' => 'New Warehouse view scaffold for the Inventory module.',
            'new_settings_view_scaffold' => 'New Settings view scaffold for the Inventory module.',
            'warehouse_migration_notice' => 'This tab will become the new place for the inventory table after the migration to the PrestaShop 8.2+ / 9.x compatible architecture is completed.',
            'settings_migration_notice' => 'This tab will become the new place for hidden products configuration and module settings after the migration is completed.',
            'no_image' => 'None',
            'no_data' => 'No data',
            'combination_id' => 'Combination ID: {{ id }}',
            'actions' => 'Actions',
            'hide_forever' => 'Hide permanently',
            'total_purchase_value_net' => 'Total net purchase value:',
            'total_retail_value_gross' => 'Total gross retail value:',
            'no_results' => 'No results.',
            'report_title' => 'Inventory status',
            'show_only_active_products' => 'Show only active products',
            'show_only_available_in_stock' => 'Show only available in stock',
            'show_only_missing_purchase_price' => 'Show only with missing purchase price',
            'show_retail_prices_gross' => 'Show retail gross prices',
            'row_number' => 'No.',
            'image' => 'Image',
            'name' => 'Name',
            'product_name' => 'Product name',
            'active' => 'Active',
            'purchase_price_net' => 'Purchase price (net)',
            'retail_price_gross' => 'Retail price (gross)',
            'quantity' => 'Quantity',
            'available_quantity' => 'Available quantity',
            'purchase_value_net' => 'Purchase value (net)',
            'retail_value_gross' => 'Retail value (gross)',
            'products_per_page' => 'Products per page:',
            'visible_range' => 'Showing {{ from }}-{{ to }} of {{ total }} (page {{ page }} / {{ total_pages }})',
            'current_page' => 'Current page',
            'previous' => 'Previous',
            'next' => 'Next',
            'id' => 'ID',
            'search_placeholder' => 'Search table...',
            'save' => 'Save',
            'cancel' => 'Cancel',
            'enter_qty' => 'e.g. 12',
            'enter_price' => 'e.g. 12.34',
            'enter_retail_price' => 'e.g. 99.99',
            'error_save' => 'Save error',
            'error_network' => 'Connection / server error while saving.',
            'error_qty_save' => 'Could not save quantity.',
            'error_hide' => 'Could not hide the product.',
            'type_qty' => 'Enter an integer quantity.',
            'type_price' => 'Enter a price.',
            'error_toggle' => 'Could not change product status.',
            'copied' => 'Copied',
            'copy_error' => 'Could not copy EAN13.',
            'load_error' => 'Loading error.',
            'product_restored' => 'Product restored to the list.',
            'product_restore_error' => 'Could not restore the product.',
            'restore' => 'Restore',
            'displayed' => 'Displayed',
            'hidden_products_empty' => 'No hidden products.',
            'module_parent_tab_error' => 'Could not resolve the parent Back Office tab for Inventory.',
            'module_tab_create_error' => 'Could not create the Inventory tab in Back Office.',
            'access_denied' => 'Access denied',
            'db_update_error' => 'Database update error',
            'stock_update_error' => 'Stock update error',
            'hide_product_error' => 'Hide product error',
            'missing_id_product' => 'Missing product ID',
            'invalid_price' => 'Invalid price',
            'price_must_be_greater_than_zero' => 'Price must be greater than 0',
            'invalid_quantity' => 'Invalid quantity',
            'stock_api_not_available' => 'Stock API is not available.',
            'product_not_found' => 'Product not found',
            'pdf_filename' => 'Inventory_status_{{ date }}',
        ],
        'pl' => [
            'warehouse_tab' => 'Magazyn',
            'settings_tab' => 'Ustawienia',
            'inventory_report' => 'Raport magazynowy',
            'new_warehouse_view_scaffold' => 'Szkielet nowego widoku Magazyn dla modułu Inventory.',
            'new_settings_view_scaffold' => 'Szkielet nowego widoku Ustawienia dla modułu Inventory.',
            'warehouse_migration_notice' => 'Ta zakładka będzie nowym miejscem na tabelę magazynową po zakończeniu migracji do architektury zgodnej z PrestaShop 8.2+ / 9.x.',
            'settings_migration_notice' => 'Ta zakładka będzie nowym miejscem na konfigurację ukrytych produktów i ustawienia modułu po zakończeniu migracji.',
            'no_image' => 'Brak',
            'no_data' => 'Brak danych',
            'combination_id' => 'ID kombinacji: {{ id }}',
            'actions' => 'Akcje',
            'hide_forever' => 'Ukryj na stałe',
            'total_purchase_value_net' => 'Suma wartości zakupu netto:',
            'total_retail_value_gross' => 'Suma wartości detalicznej brutto:',
            'no_results' => 'Brak wyników.',
            'report_title' => 'Stan magazynowy',
            'show_only_active_products' => 'Pokazuj tylko aktywne produkty',
            'show_only_available_in_stock' => 'Pokazuj tylko dostępne w magazynie',
            'show_only_missing_purchase_price' => 'Pokazuj tylko z brakującą ceną zakupu',
            'show_retail_prices_gross' => 'Pokazuj ceny detaliczne brutto',
            'row_number' => 'Lp.',
            'image' => 'Zdjęcie',
            'name' => 'Nazwa',
            'product_name' => 'Nazwa produktu',
            'active' => 'Aktywny',
            'purchase_price_net' => 'Cena zakupu (netto)',
            'retail_price_gross' => 'Cena detaliczna (brutto)',
            'quantity' => 'Ilość',
            'available_quantity' => 'Dostępna ilość',
            'purchase_value_net' => 'Wartość zakupu (netto)',
            'retail_value_gross' => 'Wartość detaliczna (brutto)',
            'products_per_page' => 'Produktów na stronie:',
            'visible_range' => 'Widoczne {{ from }}-{{ to }} z {{ total }} (strona {{ page }} / {{ total_pages }})',
            'current_page' => 'Aktualna strona',
            'previous' => 'Previous',
            'next' => 'Next',
            'id' => 'ID',
            'search_placeholder' => 'Szukaj w tabeli...',
            'save' => 'Zapisz',
            'cancel' => 'Anuluj',
            'enter_qty' => 'np. 12',
            'enter_price' => 'np. 12,34',
            'enter_retail_price' => 'np. 99,99',
            'error_save' => 'Błąd zapisu',
            'error_network' => 'Błąd połączenia / serwera przy zapisie.',
            'error_qty_save' => 'Nie udało się zapisać ilości.',
            'error_hide' => 'Nie udało się ukryć produktu.',
            'type_qty' => 'Wpisz ilość całkowitą.',
            'type_price' => 'Wpisz cenę.',
            'error_toggle' => 'Nie udało się zmienić statusu produktu.',
            'copied' => 'Skopiowano',
            'copy_error' => 'Nie udało się skopiować EAN13.',
            'load_error' => 'Błąd ładowania danych.',
            'product_restored' => 'Produkt przywrócony do listy.',
            'product_restore_error' => 'Nie udało się przywrócić produktu.',
            'restore' => 'Przywróć',
            'displayed' => 'Wyświetlany',
            'hidden_products_empty' => 'Brak ukrytych produktów.',
            'module_parent_tab_error' => 'Nie udało się ustalić nadrzędnej zakładki Back Office dla Inventory.',
            'module_tab_create_error' => 'Nie udało się utworzyć zakładki Inventory w Back Office.',
            'access_denied' => 'Brak dostępu',
            'db_update_error' => 'Błąd aktualizacji bazy danych',
            'stock_update_error' => 'Błąd aktualizacji stanu magazynowego',
            'hide_product_error' => 'Błąd ukrywania produktu',
            'missing_id_product' => 'Brak identyfikatora produktu',
            'invalid_price' => 'Nieprawidłowa cena',
            'price_must_be_greater_than_zero' => 'Cena musi być większa od 0',
            'invalid_quantity' => 'Nieprawidłowa ilość',
            'stock_api_not_available' => 'API stanów magazynowych jest niedostępne.',
            'product_not_found' => 'Nie znaleziono produktu',
            'pdf_filename' => 'Stan_magazynowy_{{ date }}',
        ],
    ];

    public static function locale(Context $context): string
    {
        $iso = strtolower((string) ($context->language->iso_code ?? 'en'));

        return $iso === 'pl' ? 'pl' : 'en';
    }

    public static function all(Context $context): array
    {
        return self::DICTIONARY[self::locale($context)];
    }

    public static function translate(Context $context, string $key, array $params = []): string
    {
        $messages = self::all($context);
        $message = $messages[$key] ?? $key;

        if ($params === []) {
            return $message;
        }

        $replace = [];
        foreach ($params as $name => $value) {
            $replace['{{ ' . $name . ' }}'] = (string) $value;
        }

        return strtr($message, $replace);
    }
}
