# Wpisz tu zmiany do następnego release (jedna linia = jeden bullet)
# Przykład:
# Poprawa walidacji wymiarów w modalu produktu.
# Usunięcie znaku % z nagłówka kolumny Cło.
Lista zamówień: w kolumnie akcji dodana ikona ostrzeżenia dla zamówień zawierających niepowiązane produkty.
