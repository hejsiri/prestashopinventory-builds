<?php

class PrestashopInventoryI18n
{
    public const DOMAIN = 'Modules.Prestashopinventory.Admin';

    public static function all($translator): array
    {
        return [
            'warehouse_tab' => self::trans($translator, 'Warehouse'),
            'settings_tab' => self::trans($translator, 'Settings'),
            'inventory_report' => self::trans($translator, 'Inventory report'),
            'new_warehouse_view_scaffold' => self::trans($translator, 'New Warehouse view scaffold for the Inventory module.'),
            'new_settings_view_scaffold' => self::trans($translator, 'New Settings view scaffold for the Inventory module.'),
            'warehouse_migration_notice' => self::trans($translator, 'This tab will become the new place for the inventory table after the migration to the PrestaShop 8.2+ / 9.x compatible architecture is completed.'),
            'settings_migration_notice' => self::trans($translator, 'This tab will become the new place for hidden products configuration and module settings after the migration is completed.'),
            'no_image' => self::trans($translator, 'None'),
            'no_data' => self::trans($translator, 'No data'),
            'combination_id' => self::trans($translator, 'Combination ID: %id%', ['%id%' => '{{ id }}']),
            'actions' => self::trans($translator, 'Actions'),
            'hide_forever' => self::trans($translator, 'Hide permanently'),
            'total_purchase_value_net' => self::trans($translator, 'Total net purchase value:'),
            'total_retail_value_gross' => self::trans($translator, 'Total gross retail value:'),
            'no_results' => self::trans($translator, 'No results.'),
            'report_title' => self::trans($translator, 'Inventory status'),
            'show_only_active_products' => self::trans($translator, 'Show only active products'),
            'show_only_available_in_stock' => self::trans($translator, 'Show only available in stock'),
            'show_only_missing_purchase_price' => self::trans($translator, 'Show only with missing purchase price'),
            'show_product_weight' => self::trans($translator, 'Show product weight'),
            'show_only_missing_weight' => self::trans($translator, 'Show products without weight'),
            'show_retail_prices_gross' => self::trans($translator, 'Show retail gross prices'),
            'row_number' => self::trans($translator, 'No.'),
            'image' => self::trans($translator, 'Image'),
            'name' => self::trans($translator, 'Name'),
            'product_name' => self::trans($translator, 'Product name'),
            'product_weight' => self::trans($translator, 'Product weight'),
            'active' => self::trans($translator, 'Active'),
            'purchase_price_net' => self::trans($translator, 'Purchase price (net)'),
            'retail_price_gross' => self::trans($translator, 'Retail price (gross)'),
            'quantity' => self::trans($translator, 'Quantity'),
            'available_quantity' => self::trans($translator, 'Available quantity'),
            'purchase_value_net' => self::trans($translator, 'Purchase value (net)'),
            'retail_value_gross' => self::trans($translator, 'Retail value (gross)'),
            'products_per_page' => self::trans($translator, 'Products per page:'),
            'visible_range' => self::trans($translator, 'Showing %from%-%to% of %total% (page %page% / %total_pages%)', [
                '%from%' => '{{ from }}',
                '%to%' => '{{ to }}',
                '%total%' => '{{ total }}',
                '%page%' => '{{ page }}',
                '%total_pages%' => '{{ total_pages }}',
            ]),
            'current_page' => self::trans($translator, 'Current page'),
            'previous' => self::trans($translator, 'Previous'),
            'next' => self::trans($translator, 'Next'),
            'id' => self::trans($translator, 'ID'),
            'ean13' => self::trans($translator, 'EAN13'),
            'module_navigation' => self::trans($translator, 'Module navigation'),
            'filters' => self::trans($translator, 'Filters'),
            'clear' => self::trans($translator, 'Clear'),
            'search_placeholder' => self::trans($translator, 'Search table...'),
            'save' => self::trans($translator, 'Save'),
            'cancel' => self::trans($translator, 'Cancel'),
            'enter_qty' => self::trans($translator, 'e.g. 12'),
            'enter_price' => self::trans($translator, 'e.g. 12.34'),
            'enter_retail_price' => self::trans($translator, 'e.g. 99.99'),
            'enter_weight' => self::trans($translator, 'e.g. 1.250'),
            'error_save' => self::trans($translator, 'Save error'),
            'error_network' => self::trans($translator, 'Connection / server error while saving.'),
            'error_qty_save' => self::trans($translator, 'Could not save quantity.'),
            'error_weight_save' => self::trans($translator, 'Could not save weight.'),
            'error_hide' => self::trans($translator, 'Could not hide the product.'),
            'type_qty' => self::trans($translator, 'Enter an integer quantity.'),
            'type_price' => self::trans($translator, 'Enter a price.'),
            'type_weight' => self::trans($translator, 'Enter a valid weight.'),
            'error_toggle' => self::trans($translator, 'Could not change product status.'),
            'copied' => self::trans($translator, 'Copied'),
            'copy_error' => self::trans($translator, 'Could not copy EAN13.'),
            'load_error' => self::trans($translator, 'Loading error.'),
            'product_restored' => self::trans($translator, 'Product restored to the list.'),
            'product_restore_error' => self::trans($translator, 'Could not restore the product.'),
            'restore' => self::trans($translator, 'Restore'),
            'displayed' => self::trans($translator, 'Displayed'),
            'hidden_products_empty' => self::trans($translator, 'No hidden products.'),
            'module_parent_tab_error' => self::trans($translator, 'Could not resolve the parent Back Office tab for Inventory.'),
            'module_tab_create_error' => self::trans($translator, 'Could not create the Inventory tab in Back Office.'),
            'access_denied' => self::trans($translator, 'Access denied'),
            'db_update_error' => self::trans($translator, 'Database update error'),
            'stock_update_error' => self::trans($translator, 'Stock update error'),
            'hide_product_error' => self::trans($translator, 'Hide product error'),
            'missing_id_product' => self::trans($translator, 'Missing product ID'),
            'invalid_price' => self::trans($translator, 'Invalid price'),
            'price_must_be_greater_than_zero' => self::trans($translator, 'Price must be greater than 0'),
            'invalid_quantity' => self::trans($translator, 'Invalid quantity'),
            'invalid_weight' => self::trans($translator, 'Invalid weight'),
            'stock_api_not_available' => self::trans($translator, 'Stock API is not available.'),
            'product_not_found' => self::trans($translator, 'Product not found'),
            'pdf_filename' => self::trans($translator, 'Inventory_status_%date%', ['%date%' => '{{ date }}']),
        ];
    }

    public static function translate($translator, string $key, array $params = []): string
    {
        switch ($key) {
            case 'combination_id':
                return self::trans($translator, 'Combination ID: %id%', ['%id%' => (string) ($params['id'] ?? '')]);
            case 'visible_range':
                return self::trans($translator, 'Showing %from%-%to% of %total% (page %page% / %total_pages%)', [
                    '%from%' => (string) ($params['from'] ?? ''),
                    '%to%' => (string) ($params['to'] ?? ''),
                    '%total%' => (string) ($params['total'] ?? ''),
                    '%page%' => (string) ($params['page'] ?? ''),
                    '%total_pages%' => (string) ($params['total_pages'] ?? ''),
                ]);
            case 'pdf_filename':
                return self::trans($translator, 'Inventory_status_%date%', ['%date%' => (string) ($params['date'] ?? '')]);
            default:
                $messages = self::all($translator);

                return $messages[$key] ?? $key;
        }
    }

    private static function trans($translator, string $message, array $params = []): string
    {
        if (is_object($translator) && method_exists($translator, 'transModule')) {
            return $translator->transModule($message, $params);
        }

        return $translator->trans($message, $params, self::DOMAIN);
    }
}
