<?php

require_once __DIR__ . '/classes/PrestashopInventoryI18n.php';
require_once __DIR__ . '/classes/PrestashopInventoryService.php';

if (!defined('_PS_VERSION_')) {
    exit;
}

class PrestashopInventory extends Module
{
    private const ADMIN_TAB_CLASS_NAME = 'AdminPrestashopInventory';

    public function __construct()
    {
        $this->name = 'prestashopinventory';
        $this->tab = 'administration';
        $this->version = '0.2.8';
        $this->author = 'hejsiri';
        $this->need_instance = 0;
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->trans('Inventory Report', [], 'Modules.Prestashopinventory.Admin');
        $this->description = $this->trans('Back Office inventory view with purchase price editing and PDF export.', [], 'Modules.Prestashopinventory.Admin');
        $this->ps_versions_compliancy = ['min' => '8.2.0', 'max' => _PS_VERSION_];
    }

    public function install(): bool
    {
        $defaultIgnoredIds = '';
        $ignoreFilePath = __DIR__ . '/ignore.txt';
        if (is_file($ignoreFilePath)) {
            $defaultIgnoredIds = trim((string) file_get_contents($ignoreFilePath));
        }

        if (!parent::install()) {
            return false;
        }

        if (!$this->installTab()) {
            parent::uninstall();

            return false;
        }

        if ($defaultIgnoredIds !== '') {
            Configuration::updateValue(PrestashopInventoryService::CONFIG_IGNORED_IDS, $defaultIgnoredIds);
        }

        return true;
    }

    public function uninstall(): bool
    {
        Configuration::deleteByName(PrestashopInventoryService::CONFIG_IGNORED_IDS);

        return $this->uninstallTab() && parent::uninstall();
    }

    public function getContent(): string
    {
        $output = '';
        $service = new PrestashopInventoryService($this->getLocalPath(), $this->context);

        if (Tools::isSubmit('submitPrestashopInventoryRestoreHidden')) {
            try {
                $service->unhideProduct((int) Tools::getValue('id_product'));
                $output .= $this->displayConfirmation(PrestashopInventoryI18n::translate($this->context, 'product_restored'));
            } catch (Throwable $e) {
                $output .= $this->displayError(PrestashopInventoryI18n::translate($this->context, 'product_restore_error'));
            }
        }

        $translations = $service->getTranslations();

        $this->context->smarty->assign([
            'prestashopInventoryConfigAction' => AdminController::$currentIndex . '&configure=' . $this->name . '&token=' . Tools::getAdminTokenLite('AdminModules'),
            'prestashopInventoryCatalogUrl' => $this->context->link->getAdminLink('AdminProducts', true),
            'prestashopInventoryBackUrl' => $this->context->link->getAdminLink('AdminPrestashopInventory', true),
            'prestashopInventoryIgnoredProducts' => $service->getIgnoredProducts(),
            'prestashopInventoryTranslations' => $translations,
        ]);

        $output .= $this->display(__FILE__, 'views/templates/admin/configure.tpl');

        return $output;
    }

    private function installTab(): bool
    {
        $tabId = (int) Tab::getIdFromClassName(self::ADMIN_TAB_CLASS_NAME);
        if ($tabId > 0) {
            return true;
        }

        $parentId = $this->resolveCatalogParentTabId();
        if ($parentId <= 0) {
            $this->_errors[] = PrestashopInventoryI18n::translate($this->context, 'module_parent_tab_error');

            return false;
        }

        $tab = new Tab();
        $tab->active = 1;
        $tab->class_name = self::ADMIN_TAB_CLASS_NAME;
        $tab->module = $this->name;
        $tab->id_parent = $parentId;

        foreach (Language::getLanguages(false) as $language) {
            $tab->name[(int) $language['id_lang']] = 'Inventory';
        }

        if (!$tab->add()) {
            $this->_errors[] = PrestashopInventoryI18n::translate($this->context, 'module_tab_create_error');

            return false;
        }

        return true;
    }

    private function uninstallTab(): bool
    {
        $tabId = (int) Tab::getIdFromClassName(self::ADMIN_TAB_CLASS_NAME);
        if ($tabId <= 0) {
            return true;
        }

        $tab = new Tab($tabId);

        return (bool) $tab->delete();
    }

    private function resolveCatalogParentTabId(): int
    {
        $candidates = [
            'AdminCatalog',
            'SELL',
            'AdminParentCatalog',
        ];

        foreach ($candidates as $className) {
            $tabId = (int) Tab::getIdFromClassName($className);
            if ($tabId > 0) {
                return $tabId;
            }
        }

        return 0;
    }
}
