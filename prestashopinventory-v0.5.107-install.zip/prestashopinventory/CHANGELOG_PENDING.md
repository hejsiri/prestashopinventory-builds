# Wpisz tu zmiany do następnego release (jedna linia = jeden bullet)
# Przykład:
# Poprawa walidacji wymiarów w modalu produktu.
# Usunięcie znaku % z nagłówka kolumny Cło.
Dodany webowy importer dostawców CRM z ręcznym zatwierdzaniem rekordów i mapowaniem kraju.
Dodany webowy importer zamówień CRM z importem pojedynczym i zbiorczym oraz kontrolą istnienia dostawcy.
Importer zamówień uzupełnia mapowanie statusów, produktów, zdjęć, przewoźników i pól nagłówka zamówienia.
Podgląd zamówienia otrzymał przyciski poprzednie/następne obok przycisku Powrót do listy.
