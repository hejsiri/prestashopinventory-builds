# Wpisz tu zmiany do następnego release (jedna linia = jeden bullet)
# Przykład:
# Poprawa walidacji wymiarów w modalu produktu.
# Usunięcie znaku % z nagłówka kolumny Cło.
Lista produktów: paginacja na dole ma spokojniejsze odstępy i cyfry w rozmiarze dopasowanym do tekstu statusu.
Dostawcy: usunięta funkcja Aktywny z widoku, formularza, zapisu i tabeli modułu.
