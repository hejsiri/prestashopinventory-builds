# Wpisz tu zmiany do następnego release (jedna linia = jeden bullet)
# Przykład:
# Poprawa walidacji wymiarów w modalu produktu.
# Usunięcie znaku % z nagłówka kolumny Cło.
Ukryta ikonka listy zamówień w produktach, gdy produkt nie występuje w żadnym zamówieniu.
Ujednolicony styl ikonek akcji w produktach, zamówieniach, dostawcach i ustawieniach do stylu BO PrestaShop.
Notatki w zamówieniach przeniesione do popupu i pokazane jako karteczki bez tła panelu.
