Poprawiono ikonę edycji produktu w Safari: usunięto błąd toInt is not defined blokujący otwarcie popupu.
Parsery wartości liczbowych dla danych przycisku edycji działają lokalnie w handlerze kliknięcia.
