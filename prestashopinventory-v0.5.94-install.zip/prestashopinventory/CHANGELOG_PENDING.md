Doprecyzowano wygląd strzałek paginacji (< >) na stronie Produkty, aby odpowiadał docelowemu wzorcowi UI.
Ujednolicono style przycisków paginacji (stan normalny, hover i disabled) pod tabelą produktów.
