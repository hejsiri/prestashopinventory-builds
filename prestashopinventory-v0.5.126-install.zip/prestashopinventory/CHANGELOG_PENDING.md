# Wpisz tu zmiany do następnego release (jedna linia = jeden bullet)
# Przykład:
# Poprawa walidacji wymiarów w modalu produktu.
# Usunięcie znaku % z nagłówka kolumny Cło.
Usunięcie ikon udostępniania i podglądu z listy zamówień oraz wyczyszczenie powiązanego kodu.
Dodanie potwierdzenia usuwania zamówień także w legacy widoku listy.
Poprawa zapisu jednostki objętości na m³ w tabelach.
