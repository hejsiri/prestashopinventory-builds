# Wpisz tu zmiany do następnego release (jedna linia = jeden bullet)
# Przykład:
# Poprawa walidacji wymiarów w modalu produktu.
# Usunięcie znaku % z nagłówka kolumny Cło.
Poprawione linki śledzenia przesyłek dla DHL i UPS oraz dodana obsługa FedEx.
Usunięte obramowanie strzałek w paginacji listy produktów.
