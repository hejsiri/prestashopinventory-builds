<?php
declare(strict_types=1);

namespace PrestaShop\Module\PrestashopInventory\Controller\Admin;

require_once dirname(__DIR__, 3) . '/classes/PrestashopInventoryService.php';

use PrestaShopBundle\Security\Annotation\AdminSecurity;
use Symfony\Component\HttpFoundation\BinaryFileResponse;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\ResponseHeaderBag;

class PurchaseOrdersController extends AbstractInventoryController
{
    /**
     * @AdminSecurity("is_granted('read', request.get('_legacy_controller'))")
     */
    public function indexAction(Request $request): Response
    {
        $this->assertModuleLicenseValid();

        $module = \Module::getInstanceByName('prestashopinventory');
        $context = \Context::getContext();
        $purchaseOrders = [];
        $purchaseOrdersPageData = [];
        $selectedOrder = null;
        $messages = [];
        $errors = [];
        $purchaseOrderQuery = trim((string) $request->query->get('query', ''));
        $purchaseOrderPage = max(1, (int) $request->query->get('page', 1));
        $purchaseOrderPerPage = (int) $request->query->get('per_page', 20);
        $purchaseOrderProductId = max(0, (int) $request->query->get('id_product', 0));
        $purchaseOrderProductAttributeId = max(0, (int) $request->query->get('id_product_attribute', 0));
        $purchaseOrderFilters = [
            'id_product' => $purchaseOrderProductId,
            'id_product_attribute' => $purchaseOrderProductAttributeId,
        ];

        if ($request->isMethod('GET') && $request->query->has('view')) {
            $redirectParams = [];
            $selectedOrderId = (int) $request->query->get('id_purchase_order', 0);
            if ($selectedOrderId > 0) {
                $redirectParams['id_purchase_order'] = $selectedOrderId;
            }

            $status = (string) $request->query->get('purchase_order_status', '');
            if ($status !== '') {
                $redirectParams['purchase_order_status'] = $status;
            }

            return $this->redirectToRoute('prestashop_inventory_purchase_orders', $redirectParams);
        }

        if ($module instanceof \Module) {
            if ($module instanceof \PrestashopInventory) {
                $module->ensureTabsAvailable();
            }

            $service = new \PrestashopInventoryService($module->getLocalPath(), $context, $module);
            $service->ensurePurchaseOrderInfrastructure();

            if ($request->isMethod('GET') && $request->query->has('exportOrderPdf')) {
                $orderId = (int) $request->query->get('id_purchase_order', 0);
                if ($orderId > 0) {
                    $service->outputPurchaseOrderPdf($orderId);
                }
                exit;
            }

            if ($request->isMethod('GET') && $request->query->has('downloadPurchaseOrderFile')) {
                $orderId = (int) $request->query->get('id_purchase_order', 0);
                $fileId = (int) $request->query->get('id_purchase_order_file', 0);
                $disposition = (string) $request->query->get('disposition', 'attachment');

                if ($orderId > 0 && $fileId > 0) {
                    $fileData = $service->getPurchaseOrderFileDownloadData($fileId, $orderId);
                    $response = new BinaryFileResponse($fileData['absolute_path']);
                    $response->headers->set('Content-Type', $fileData['mime_type'] !== '' ? $fileData['mime_type'] : 'application/octet-stream');
                    $response->setContentDisposition(
                        $disposition === 'inline' ? ResponseHeaderBag::DISPOSITION_INLINE : ResponseHeaderBag::DISPOSITION_ATTACHMENT,
                        $fileData['original_name'] !== '' ? $fileData['original_name'] : basename($fileData['absolute_path'])
                    );

                    return $response;
                }

                throw $this->createNotFoundException();
            }

            if ($request->isMethod('POST')) {
                try {
                    if (\Tools::isSubmit('submitPrestashopInventoryCreatePurchaseOrder')) {
                        $idPurchaseOrder = $service->createPurchaseOrder();

                        return $this->redirectToRoute('prestashop_inventory_purchase_orders', [
                            'id_purchase_order' => $idPurchaseOrder,
                            'purchase_order_status' => 'created',
                        ]);
                    }

                    if (\Tools::isSubmit('submitPrestashopInventorySavePurchaseOrder')) {
                        $idPurchaseOrder = (int) \Tools::getValue('id_purchase_order');
                        $service->savePurchaseOrder($idPurchaseOrder, $request->request->all());

                        return $this->redirectToRoute('prestashop_inventory_purchase_orders', [
                            'id_purchase_order' => $idPurchaseOrder,
                            'purchase_order_status' => 'saved',
                        ]);
                    }

                    if (\Tools::isSubmit('submitPrestashopInventoryChangePurchaseOrderStatus')) {
                        $idPurchaseOrder = (int) \Tools::getValue('id_purchase_order');
                        $service->updatePurchaseOrderStatus($idPurchaseOrder, (string) \Tools::getValue('status_key', 'draft'));

                        return $this->redirectToRoute('prestashop_inventory_purchase_orders', [
                            'id_purchase_order' => $idPurchaseOrder,
                            'purchase_order_status' => 'status_changed',
                        ]);
                    }

                    if (\Tools::isSubmit('submitPrestashopInventoryUpdatePurchaseOrderSupplierInline')) {
                        $idPurchaseOrder = (int) \Tools::getValue('id_purchase_order');
                        $payload = $service->updatePurchaseOrderSupplier(
                            $idPurchaseOrder,
                            (int) \Tools::getValue('id_supplier')
                        );

                        if ($request->isXmlHttpRequest()) {
                            return new JsonResponse([
                                'ok' => true,
                                'supplier' => $payload['supplier'] ?? [],
                                'id_supplier' => (int) ($payload['order']['id_supplier'] ?? 0),
                            ]);
                        }

                        return $this->redirectToRoute('prestashop_inventory_purchase_orders', [
                            'id_purchase_order' => $idPurchaseOrder,
                            'purchase_order_status' => 'saved',
                        ]);
                    }

                    if (\Tools::isSubmit('submitPrestashopInventoryUpdatePurchaseOrderFieldInline')) {
                        $idPurchaseOrder = (int) \Tools::getValue('id_purchase_order');
                        $payload = $service->updatePurchaseOrderFieldInline(
                            $idPurchaseOrder,
                            (string) \Tools::getValue('field'),
                            (string) \Tools::getValue('value')
                        );

                        if ($request->isXmlHttpRequest()) {
                            return new JsonResponse([
                                'ok' => true,
                                'order' => $payload['order'] ?? [],
                            ]);
                        }

                        return $this->redirectToRoute('prestashop_inventory_purchase_orders', [
                            'id_purchase_order' => $idPurchaseOrder,
                            'purchase_order_status' => 'saved',
                        ]);
                    }

                    if (\Tools::isSubmit('submitPrestashopInventoryUpdatePurchaseOrderItemInline')) {
                        $idPurchaseOrder = (int) \Tools::getValue('id_purchase_order');
                        $payload = $service->updatePurchaseOrderItemField(
                            $idPurchaseOrder,
                            (int) \Tools::getValue('id_purchase_order_item'),
                            (string) \Tools::getValue('field'),
                            (string) \Tools::getValue('value')
                        );

                        if ($request->isXmlHttpRequest()) {
                            return new JsonResponse([
                                'ok' => true,
                                'item' => $payload['item'] ?? [],
                                'items_total_formatted' => $payload['items_total_formatted'] ?? '',
                            ]);
                        }

                        return $this->redirectToRoute('prestashop_inventory_purchase_orders', [
                            'id_purchase_order' => $idPurchaseOrder,
                            'purchase_order_status' => 'item_saved',
                        ]);
                    }

                    if (\Tools::isSubmit('submitPrestashopInventoryUpdatePurchaseOrderProductModuleData')) {
                        $idPurchaseOrder = (int) \Tools::getValue('id_purchase_order');
                        $payload = $service->updatePurchaseOrderProductModuleData(
                            $idPurchaseOrder,
                            (int) \Tools::getValue('id_purchase_order_item'),
                            $request->request->all()
                        );

                        if ($request->isXmlHttpRequest()) {
                            return new JsonResponse([
                                'ok' => true,
                                'item' => $payload['item'] ?? [],
                            ]);
                        }

                        return $this->redirectToRoute('prestashop_inventory_purchase_orders', [
                            'id_purchase_order' => $idPurchaseOrder,
                            'purchase_order_status' => 'item_saved',
                        ]);
                    }

                    if (\Tools::isSubmit('submitPrestashopInventoryDeletePurchaseOrder')) {
                        $service->deletePurchaseOrder((int) \Tools::getValue('id_purchase_order'));

                        return $this->redirectToRoute('prestashop_inventory_purchase_orders', [
                            'purchase_order_status' => 'deleted',
                        ]);
                    }

                    if (\Tools::isSubmit('submitPrestashopInventoryDeletePurchaseOrderItem')) {
                        $idPurchaseOrder = (int) \Tools::getValue('id_purchase_order');
                        $service->deletePurchaseOrderItem(
                            (int) \Tools::getValue('id_purchase_order_item'),
                            $idPurchaseOrder
                        );

                        return $this->redirectToRoute('prestashop_inventory_purchase_orders', [
                            'id_purchase_order' => $idPurchaseOrder,
                            'purchase_order_status' => 'item_deleted',
                        ]);
                    }

                    if (\Tools::isSubmit('submitPrestashopInventoryAddPurchaseOrderItem')) {
                        $idPurchaseOrder = (int) \Tools::getValue('id_purchase_order');
                        $payload = $service->addPurchaseOrderItem(
                            $idPurchaseOrder,
                            (string) \Tools::getValue('purchase_order_product_selection', ''),
                            (string) \Tools::getValue('purchase_order_item_quantity', '1'),
                            (string) \Tools::getValue('purchase_order_item_price', '')
                        );

                        if ($request->isXmlHttpRequest()) {
                            return new JsonResponse([
                                'ok' => true,
                                'item' => $payload['item'] ?? [],
                                'items_total_formatted' => $payload['items_total_formatted'] ?? '',
                            ]);
                        }

                        return $this->redirectToRoute('prestashop_inventory_purchase_orders', [
                            'id_purchase_order' => $idPurchaseOrder,
                            'purchase_order_status' => 'item_added',
                        ]);
                    }

                    if (\Tools::isSubmit('submitPrestashopInventoryRelinkPurchaseOrderItem')) {
                        $idPurchaseOrder = (int) \Tools::getValue('id_purchase_order');
                        $payload = $service->relinkPurchaseOrderItem(
                            $idPurchaseOrder,
                            (int) \Tools::getValue('id_purchase_order_item'),
                            (string) \Tools::getValue('purchase_order_product_selection', '')
                        );

                        if ($request->isXmlHttpRequest()) {
                            return new JsonResponse([
                                'ok' => true,
                                'item' => $payload['item'] ?? [],
                                'items_total_formatted' => $payload['items_total_formatted'] ?? '',
                            ]);
                        }

                        return $this->redirectToRoute('prestashop_inventory_purchase_orders', [
                            'id_purchase_order' => $idPurchaseOrder,
                            'purchase_order_status' => 'item_saved',
                        ]);
                    }

                    if (\Tools::isSubmit('submitPrestashopInventoryUploadPurchaseOrderFile')) {
                        $idPurchaseOrder = (int) \Tools::getValue('id_purchase_order');
                        $fileData = $service->uploadPurchaseOrderFile(
                            $idPurchaseOrder,
                            $_FILES['purchase_order_file'] ?? [],
                            (string) \Tools::getValue('purchase_order_file_description', ''),
                            (int) \Tools::getValue('id_psinv_document_type', 0)
                        );

                        if ($request->isXmlHttpRequest()) {
                            $fileData['download_url'] = $this->buildPurchaseOrderFileUrl($idPurchaseOrder, (int) ($fileData['id_purchase_order_file'] ?? 0));
                            $fileData['preview_url'] = $this->buildPurchaseOrderFileUrl($idPurchaseOrder, (int) ($fileData['id_purchase_order_file'] ?? 0), 'inline');

                            return new JsonResponse(['ok' => true, 'file' => $fileData]);
                        }

                        return $this->redirectToRoute('prestashop_inventory_purchase_orders', [
                            'id_purchase_order' => $idPurchaseOrder,
                            'purchase_order_status' => 'file_uploaded',
                        ]);
                    }

                    if (\Tools::isSubmit('submitPrestashopInventoryDeletePurchaseOrderFile')) {
                        $idPurchaseOrder = (int) \Tools::getValue('id_purchase_order');
                        $service->deletePurchaseOrderFile(
                            (int) \Tools::getValue('id_purchase_order_file'),
                            $idPurchaseOrder
                        );

                        if ($request->isXmlHttpRequest()) {
                            return new JsonResponse(['ok' => true]);
                        }

                        return $this->redirectToRoute('prestashop_inventory_purchase_orders', [
                            'id_purchase_order' => $idPurchaseOrder,
                            'purchase_order_status' => 'file_deleted',
                        ]);
                    }

                    if (\Tools::isSubmit('submitPrestashopInventoryUpdatePurchaseOrderFileDescription')) {
                        $idPurchaseOrder = (int) \Tools::getValue('id_purchase_order');
                        $service->updatePurchaseOrderFileDescription(
                            (int) \Tools::getValue('id_purchase_order_file'),
                            $idPurchaseOrder,
                            (string) \Tools::getValue('description', '')
                        );

                        if ($request->isXmlHttpRequest()) {
                            return new JsonResponse(['ok' => true]);
                        }

                        return $this->redirectToRoute('prestashop_inventory_purchase_orders', [
                            'id_purchase_order' => $idPurchaseOrder,
                            'purchase_order_status' => 'file_saved',
                        ]);
                    }

                    if (\Tools::isSubmit('submitPrestashopInventoryUpdatePurchaseOrderFileDocType')) {
                        $idPurchaseOrder = (int) \Tools::getValue('id_purchase_order');
                        $payload = $service->updatePurchaseOrderFileDocType(
                            (int) \Tools::getValue('id_purchase_order_file'),
                            $idPurchaseOrder,
                            (int) \Tools::getValue('id_psinv_document_type', 0)
                        );

                        if ($request->isXmlHttpRequest()) {
                            return new JsonResponse(['ok' => true, 'file' => $payload]);
                        }

                        return $this->redirectToRoute('prestashop_inventory_purchase_orders', [
                            'id_purchase_order' => $idPurchaseOrder,
                            'purchase_order_status' => 'file_saved',
                        ]);
                    }
                } catch (\Throwable $e) {
                    if ($request->isXmlHttpRequest()) {
                        return new JsonResponse([
                            'ok' => false,
                            'error' => $e->getMessage() !== '' ? $e->getMessage() : 'Nie udało się zapisać zamówienia.',
                        ], 400);
                    }

                    $errors[] = $e->getMessage() !== '' ? $e->getMessage() : 'Nie udało się zapisać zamówienia.';
                }
            }

            $status = (string) $request->query->get('purchase_order_status', '');
            if ($status === 'created') {
                $messages[] = 'Nowe zamówienie zostało utworzone.';
            } elseif ($status === 'saved') {
                $messages[] = 'Zamówienie zostało zapisane.';
            } elseif ($status === 'deleted') {
                $messages[] = 'Zamówienie zostało usunięte.';
            } elseif ($status === 'item_deleted') {
                $messages[] = 'Pozycja zamówienia została usunięta.';
            } elseif ($status === 'item_added') {
                $messages[] = 'Produkt został dodany do zamówienia.';
            } elseif ($status === 'item_saved') {
                $messages[] = 'Pozycja zamówienia została zapisana.';
            } elseif ($status === 'file_uploaded') {
                $messages[] = 'Plik został dodany do zamówienia.';
            } elseif ($status === 'file_deleted') {
                $messages[] = 'Plik został usunięty z zamówienia.';
            } elseif ($status === 'status_changed') {
                $messages[] = 'Status zamówienia został zmieniony.';
            }

            $purchaseOrdersPageData = $service->getPurchaseOrdersPage($purchaseOrderQuery, $purchaseOrderPage, $purchaseOrderPerPage, $purchaseOrderFilters);
            $purchaseOrders = array_map(function (array $order) use ($purchaseOrderQuery, $purchaseOrderPage, $purchaseOrderPerPage, $purchaseOrderProductId, $purchaseOrderProductAttributeId): array {
                $previewUrl = $this->generateUrl('prestashop_inventory_purchase_orders', [
                    'id_purchase_order' => (int) ($order['id_purchase_order'] ?? 0),
                    'query' => $purchaseOrderQuery !== '' ? $purchaseOrderQuery : null,
                    'page' => $purchaseOrderPage > 1 ? $purchaseOrderPage : null,
                    'per_page' => $purchaseOrderPerPage !== 20 ? $purchaseOrderPerPage : null,
                    'id_product' => $purchaseOrderProductId > 0 ? $purchaseOrderProductId : null,
                    'id_product_attribute' => $purchaseOrderProductAttributeId > 0 ? $purchaseOrderProductAttributeId : null,
                ]);

                $order['detail_url'] = $previewUrl;
                $order['preview_url'] = $previewUrl;
                $order['share_url'] = 'mailto:?subject=' . rawurlencode('Zamówienie ' . (string) ($order['number'] ?? '')) . '&body=' . rawurlencode($previewUrl);

                return $order;
            }, $purchaseOrdersPageData['items'] ?? []);

            $selectedOrderId = (int) $request->query->get('id_purchase_order', (int) \Tools::getValue('id_purchase_order', 0));
            if ($selectedOrderId > 0) {
                try {
                    $selectedOrder = $service->getPurchaseOrder($selectedOrderId);
                    $selectedOrder['files'] = array_map(function (array $file) use ($selectedOrderId): array {
                        $fileId = (int) ($file['id_purchase_order_file'] ?? 0);
                        $file['download_url'] = $this->buildPurchaseOrderFileUrl($selectedOrderId, $fileId);
                        $file['preview_url'] = $this->buildPurchaseOrderFileUrl($selectedOrderId, $fileId, 'inline');

                        return $file;
                    }, $selectedOrder['files'] ?? []);
                    $statusValues = array_column($selectedOrder['status_options'], 'value');
                    $selectedOrder['timeline'] = [
                        'current_index' => max(0, (int) array_search($selectedOrder['order']['status_key'], $statusValues, true)),
                    ];
                    $selectedOrder['navigation'] = [
                        'older_url' => null,
                        'newer_url' => null,
                    ];

                    $olderId = 0;
                    $newerId = 0;
                    $orderUrlsById = [];
                    foreach ($service->getPurchaseOrders($purchaseOrderQuery, $purchaseOrderFilters) as $orderRow) {
                        $orderId = (int) ($orderRow['id_purchase_order'] ?? 0);
                        if ($orderId <= 0) {
                            continue;
                        }

                        $orderUrlsById[$orderId] = (string) $this->generateUrl('prestashop_inventory_purchase_orders', [
                            'id_purchase_order' => $orderId,
                            'query' => $purchaseOrderQuery !== '' ? $purchaseOrderQuery : null,
                            'page' => $purchaseOrderPage > 1 ? $purchaseOrderPage : null,
                            'per_page' => $purchaseOrderPerPage !== 20 ? $purchaseOrderPerPage : null,
                            'id_product' => $purchaseOrderProductId > 0 ? $purchaseOrderProductId : null,
                            'id_product_attribute' => $purchaseOrderProductAttributeId > 0 ? $purchaseOrderProductAttributeId : null,
                        ]);
                        if ($orderId < $selectedOrderId && $orderId > $olderId) {
                            $olderId = $orderId;
                        }
                        if ($orderId > $selectedOrderId && ($newerId === 0 || $orderId < $newerId)) {
                            $newerId = $orderId;
                        }
                    }

                    if ($olderId > 0 && isset($orderUrlsById[$olderId])) {
                        $selectedOrder['navigation']['older_url'] = $orderUrlsById[$olderId];
                    }
                    if ($newerId > 0 && isset($orderUrlsById[$newerId])) {
                        $selectedOrder['navigation']['newer_url'] = $orderUrlsById[$newerId];
                    }
                } catch (\Throwable $e) {
                    $errors[] = $e->getMessage() !== '' ? $e->getMessage() : 'Nie znaleziono zamówienia.';
                }
            }
        }

        return $this->renderInventoryPage(
            '@Modules/prestashopinventory/views/templates/admin-modern/purchase_orders.html.twig',
            'prestashop_inventory_purchase_orders',
            'purchase_orders_tab',
            [
                'purchaseOrders' => $purchaseOrders,
                'selectedOrder' => $selectedOrder,
                'purchaseOrderMessages' => $messages,
                'purchaseOrderErrors' => $errors,
                'purchaseOrdersUrl' => $this->generateUrl('prestashop_inventory_purchase_orders'),
                'purchaseOrdersListUrl' => $this->generateUrl('prestashop_inventory_purchase_orders', array_filter([
                    'query' => $purchaseOrderQuery !== '' ? $purchaseOrderQuery : null,
                    'page' => $purchaseOrderPage > 1 ? $purchaseOrderPage : null,
                    'per_page' => $purchaseOrderPerPage !== 20 ? $purchaseOrderPerPage : null,
                    'id_product' => $purchaseOrderProductId > 0 ? $purchaseOrderProductId : null,
                    'id_product_attribute' => $purchaseOrderProductAttributeId > 0 ? $purchaseOrderProductAttributeId : null,
                ], static function ($value) {
                    return $value !== null && $value !== '';
                })),
                'purchaseOrderQuery' => $purchaseOrderQuery,
                'purchaseOrdersPagination' => $purchaseOrdersPageData['pagination'] ?? '',
                'purchaseOrderPage' => $purchaseOrdersPageData['current_page'] ?? $purchaseOrderPage,
                'purchaseOrderPerPage' => $purchaseOrdersPageData['per_page'] ?? $purchaseOrderPerPage,
                'purchaseOrderProductId' => $purchaseOrderProductId,
                'purchaseOrderProductAttributeId' => $purchaseOrderProductAttributeId,
            ]
        );
    }

    private function buildPurchaseOrderFileUrl(int $idPurchaseOrder, int $idPurchaseOrderFile, string $disposition = 'attachment'): string
    {
        return $this->generateUrl('prestashop_inventory_purchase_orders', [
            'id_purchase_order' => $idPurchaseOrder,
            'id_purchase_order_file' => $idPurchaseOrderFile,
            'downloadPurchaseOrderFile' => 1,
            'disposition' => $disposition,
        ]);
    }
}
