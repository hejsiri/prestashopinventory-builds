# Wpisz tu zmiany do następnego release (jedna linia = jeden bullet)
# Przykład:
# Poprawa walidacji wymiarów w modalu produktu.
# Usunięcie znaku % z nagłówka kolumny Cło.
Dodana kolumna z ilością zamówień na liście dostawców.
Dodane skróty do listy zamówień z poziomu dostawców i produktów.
Usunięty efekt przyciemnienia tła i ramki w hoverze paginacji produktów i zamówień.
