<?php

require_once __DIR__ . '/PrestashopInventoryI18n.php';

class PrestashopInventoryService
{
    public const CONFIG_IGNORED_IDS = 'PSINV_IGNORED_PRODUCT_IDS';
    public const CONFIG_PURCHASE_DELIVERY_ADDRESS = 'PSINV_PURCHASE_DELIVERY_ADDRESS';
    public const CONFIG_PURCHASE_ORDER_STATUSES = 'PSINV_PURCHASE_ORDER_STATUSES';
    private const SORT_FIELD_MAP = [
        'id_product' => 'id_product',
        'product_name' => 'product_name',
        'active' => 'active',
        'weight' => 'product_weight',
        'purchase_price' => 'product_cost',
        'retail_price' => 'product_price_brutto',
        'quantity' => 'stock_quantity',
    ];
    private const PURCHASE_ORDER_UPLOAD_MAX_SIZE = 15728640;

    private string $modulePath;
    private Context $context;
    private Module $module;
    private ?PDO $pdo = null;
    private bool $purchaseOrderInfrastructureReady = false;
    private bool $productLogisticsInfrastructureReady = false;

    public function __construct(string $modulePath, Context $context, Module $module)
    {
        $this->modulePath = rtrim($modulePath, '/') . '/';
        $this->context = $context;
        $this->module = $module;
    }

    public function renderProductsTable(array $filters): array
    {
        $this->ensureProductLogisticsInfrastructure();

        $showBrutto = $this->toBool($filters['showBrutto'] ?? true, true);
        $showWeight = $this->toBool($filters['showWeight'] ?? true, true);
        $showUnitVolume = $this->toBool($filters['showUnitVolume'] ?? true, true);
        $showUnitsPerCarton = $this->toBool($filters['showUnitsPerCarton'] ?? true, true);
        $showCartonDimensions = $this->toBool($filters['showCartonDimensions'] ?? true, true);
        $visibleMetricColumns = ($showWeight ? 1 : 0)
            + ($showUnitVolume ? 1 : 0)
            + ($showUnitsPerCarton ? 1 : 0)
            + ($showCartonDimensions ? 1 : 0);
        $page = $this->normalizePage($filters['page'] ?? 1);
        $perPage = $this->normalizePerPage($filters['per_page'] ?? 20);
        $result = $this->fetchProductsPage($filters, $page, $perPage);
        $products = $result['items'];

        $output = '';

        if ($products) {
            foreach ($products as $product) {
                $idProduct = (int) $product['id_product'];
                $idAttr = (int) $product['id_product_attribute'];
                $isActive = (bool) $product['active'];
                $cost = (float) $product['product_cost'];
                $taxRate = (float) ($product['tax_rate'] ?? 0);
                $costBrutto = $cost * (1 + ($taxRate / 100));
                $priceNetto = (float) ($product['product_price_netto'] ?? 0);
                $priceBrutto = (float) $product['product_price_brutto'];
                $weight = (float) $product['product_weight'];
                $unitVolume = $this->resolveProductUnitVolume($product);
                $unitsPerCarton = max(0, (int) ($product['units_per_carton'] ?? 0));
                $cartonLength = (float) ($product['carton_length'] ?? 0);
                $cartonWidth = (float) ($product['carton_width'] ?? 0);
                $cartonHeight = (float) ($product['carton_height'] ?? 0);
                $qty = (float) $product['stock_quantity'];
                $valueNetto = ($cost > 0) ? ($cost * $qty) : 0.0;
                $valueBrutto = ($priceBrutto > 0) ? ($priceBrutto * $qty) : 0.0;

                $output .= '<tr>';
                $output .= '<td class="inventory-col-id">' . $idProduct . '</td>';
                $output .= '<td class="inventory-col-image">';

                $imgId = !empty($product['combination_image_id']) ? (int) $product['combination_image_id'] : (int) $product['product_image_id'];
                if ($imgId > 0) {
                    $thumbPath = htmlspecialchars($this->getImageThumbPath($imgId, 'small_default'), ENT_QUOTES, 'UTF-8');
                    $mediumPath = htmlspecialchars($this->getImageThumbPath($imgId, 'home_default'), ENT_QUOTES, 'UTF-8');
                    $output .= '<span class="product-preview" tabindex="0">';
                    $output .= '<img src="' . $thumbPath . '" alt="" class="img-thumbnail">';
                    $output .= '<span class="product-preview-card">';
                    if ($idAttr > 0) {
                        $output .= '<span class="product-preview-title">' . htmlspecialchars($this->t('combination_id', ['id' => $idAttr]), ENT_QUOTES, 'UTF-8') . '</span>';
                    }
                    $output .= '<img src="' . $mediumPath . '" alt="" class="product-preview-image">';
                    $output .= '</span>';
                    $output .= '</span>';
                } else {
                    $output .= '<span class="inventory-no-image">' . htmlspecialchars($this->t('no_image'), ENT_QUOTES, 'UTF-8') . '</span>';
                }
                $output .= '</td>';

                $ean = $product['combination_ean13'] ?: $product['product_ean13'];
                $productEditUrl = htmlspecialchars($this->getProductEditUrl($idProduct), ENT_QUOTES, 'UTF-8');

                $output .= '<td class="inventory-col-name">';
                $output .= '<div class="inventory-product-name"><a class="inventory-product-link" href="' . $productEditUrl . '">' . htmlspecialchars((string) $product['product_name'], ENT_QUOTES, 'UTF-8') . '</a></div>';
                if (!empty($ean)) {
                    $output .= '<button type="button" class="inventory-product-ean copy-ean-btn" data-ean="' . htmlspecialchars((string) $ean, ENT_QUOTES, 'UTF-8') . '">' . htmlspecialchars((string) $ean, ENT_QUOTES, 'UTF-8') . '</button>';
                }
                if (!empty($product['combination_name'])) {
                    $output .= '<div class="inventory-product-meta">' . htmlspecialchars((string) $product['combination_name'], ENT_QUOTES, 'UTF-8') . '</div>';
                }
                $output .= '</td>';

                $switchName = 'inventory_product_active_' . $idProduct . '_' . ($idAttr > 0 ? $idAttr : 0);
                $offId = $switchName . '_off';
                $onId = $switchName . '_on';
                $output .= '<td class="inventory-col-active text-center">';
                $output .= '<div class="ps-switch ps-switch-sm ps-switch-nolabel ps-switch-center inventory-product-status-switch">';
                $output .= '<input type="radio" class="toggle-product-active" data-id-product="' . $idProduct . '" name="' . htmlspecialchars($switchName, ENT_QUOTES, 'UTF-8') . '" id="' . htmlspecialchars($offId, ENT_QUOTES, 'UTF-8') . '" value="0"' . (!$isActive ? ' checked' : '') . '>';
                $output .= '<label for="' . htmlspecialchars($offId, ENT_QUOTES, 'UTF-8') . '">Off</label>';
                $output .= '<input type="radio" class="toggle-product-active" data-id-product="' . $idProduct . '" name="' . htmlspecialchars($switchName, ENT_QUOTES, 'UTF-8') . '" id="' . htmlspecialchars($onId, ENT_QUOTES, 'UTF-8') . '" value="1"' . ($isActive ? ' checked' : '') . '>';
                $output .= '<label for="' . htmlspecialchars($onId, ENT_QUOTES, 'UTF-8') . '">On</label>';
                $output .= '<span class="slide-button"></span>';
                $output .= '</div>';
                $output .= '</td>';

                if ($showWeight) {
                    $output .= '<td class="inventory-col-weight text-center">';
                    $weightLabel = htmlspecialchars($this->formatWeight($weight), ENT_QUOTES, 'UTF-8');
                    $weightData = htmlspecialchars(number_format($weight, 3, '.', ''), ENT_QUOTES, 'UTF-8');
                    $weightClass = $weight > 0 ? 'editable-weight' : 'editable-weight text-danger';
                    $output .= '<span class="' . $weightClass . '" style="cursor:pointer; text-decoration: underline dotted;" data-id-product="' . $idProduct . '" data-id-attr="' . $idAttr . '" data-current-weight="' . $weightData . '">' . $weightLabel . '</span>';
                    $output .= '</td>';
                }

                if ($showUnitVolume) {
                    $output .= '<td class="inventory-col-volume text-center">';
                    $unitVolumeLabel = htmlspecialchars($this->formatVolume($unitVolume), ENT_QUOTES, 'UTF-8');
                    $unitVolumeData = $unitVolume > 0 ? htmlspecialchars(number_format($unitVolume, 6, '.', ''), ENT_QUOTES, 'UTF-8') : '';
                    $unitVolumeClass = $unitVolume > 0 ? 'editable-unit-volume' : 'editable-unit-volume text-danger';
                    $output .= '<span class="' . $unitVolumeClass . '" style="cursor:pointer; text-decoration: underline dotted;" data-id-product="' . $idProduct . '" data-id-attr="' . $idAttr . '" data-current-volume="' . $unitVolumeData . '">' . $unitVolumeLabel . '</span>';
                    $output .= '</td>';
                }

                if ($showUnitsPerCarton) {
                    $output .= '<td class="inventory-col-carton-qty text-center">';
                    $unitsPerCartonLabel = $unitsPerCarton > 0 ? (string) $unitsPerCarton : htmlspecialchars($this->t('no_data'), ENT_QUOTES, 'UTF-8');
                    $unitsPerCartonClass = $unitsPerCarton > 0 ? 'editable-units-per-carton' : 'editable-units-per-carton text-danger';
                    $output .= '<span class="' . $unitsPerCartonClass . '" style="cursor:pointer; text-decoration: underline dotted;" data-id-product="' . $idProduct . '" data-id-attr="' . $idAttr . '" data-current-units-per-carton="' . htmlspecialchars((string) $unitsPerCarton, ENT_QUOTES, 'UTF-8') . '">' . $unitsPerCartonLabel . '</span>';
                    $output .= '</td>';
                }

                if ($showCartonDimensions) {
                    $output .= '<td class="inventory-col-carton-dimensions text-center">';
                    $cartonDimensionsLabel = htmlspecialchars($this->formatCartonDimensions($cartonLength, $cartonWidth, $cartonHeight), ENT_QUOTES, 'UTF-8');
                    $cartonDimensionsClass = ($cartonLength > 0 && $cartonWidth > 0 && $cartonHeight > 0) ? 'editable-carton-dimensions' : 'editable-carton-dimensions text-danger';
                    $output .= '<span class="' . $cartonDimensionsClass . '" style="cursor:pointer; text-decoration: underline dotted;" data-id-product="' . $idProduct . '" data-id-attr="' . $idAttr . '" data-current-carton-dimensions="' . htmlspecialchars($this->formatCartonDimensionsInput($cartonLength, $cartonWidth, $cartonHeight), ENT_QUOTES, 'UTF-8') . '">' . $cartonDimensionsLabel . '</span>';
                    $output .= '</td>';
                }

                $output .= '<td class="inventory-col-price text-center">';
                if ($cost > 0) {
                    $label = $this->formatMoney($cost);
                    $class = 'editable-price';
                    $dataPrice = number_format($cost, 2, '.', '');
                } else {
                    $label = $this->t('no_data');
                    $class = 'editable-price text-danger';
                    $dataPrice = '';
                }

                $output .= '<span class="' . $class . '" style="cursor:pointer; text-decoration: underline dotted;" data-id-product="' . $idProduct . '" data-id-attr="' . $idAttr . '" data-current-price="' . htmlspecialchars($dataPrice, ENT_QUOTES, 'UTF-8') . '">' . htmlspecialchars($label, ENT_QUOTES, 'UTF-8') . '</span>';
                $output .= '</td>';

                if ($showBrutto) {
                    $output .= '<td class="inventory-col-price text-center">';
                    if ($priceBrutto > 0) {
                        $grossLabel = $this->formatMoney($priceBrutto);
                        $grossClass = 'editable-retail-price';
                        $grossDataPrice = number_format($priceBrutto, 2, '.', '');
                    } else {
                        $grossLabel = $this->t('no_data');
                        $grossClass = 'editable-retail-price text-danger';
                        $grossDataPrice = '';
                    }

                    $output .= '<span class="' . $grossClass . '" style="cursor:pointer; text-decoration: underline dotted;" data-id-product="' . $idProduct . '" data-id-attr="' . $idAttr . '" data-current-price="' . htmlspecialchars($grossDataPrice, ENT_QUOTES, 'UTF-8') . '">' . htmlspecialchars($grossLabel, ENT_QUOTES, 'UTF-8') . '</span>';
                    $output .= '</td>';
                }

                $output .= '<td class="inventory-col-qty text-center">';
                $output .= '<span class="editable-quantity" style="cursor:pointer; text-decoration: underline dotted;" data-id-product="' . $idProduct . '" data-id-attr="' . $idAttr . '" data-current-qty="' . (int) $qty . '">' . (int) $qty . '</span>';
                $output .= '</td>';
                $output .= '<td class="inventory-col-value text-center">' . $this->formatMoney($valueNetto > 0 ? $valueNetto : 0.0) . '</td>';

                if ($showBrutto) {
                    $output .= '<td class="inventory-col-value text-center">' . $this->formatMoney($valueBrutto > 0 ? $valueBrutto : 0.0) . '</td>';
                }

                $salesProductName = (string) $product['product_name'];
                $salesCombinationName = (string) ($product['combination_name'] ?? '');
                $output .= '<td class="inventory-col-actions text-center">';
                $output .= '<div class="inventory-row-actions">';
                $output .= '<button type="button" class="inventory-sales-trigger" data-id-product="' . $idProduct . '" data-id-attr="' . $idAttr . '" data-product-name="' . htmlspecialchars($salesProductName, ENT_QUOTES, 'UTF-8') . '" data-combination-name="' . htmlspecialchars($salesCombinationName, ENT_QUOTES, 'UTF-8') . '" data-image-src="' . ($imgId > 0 ? htmlspecialchars($this->getImagePath($imgId), ENT_QUOTES, 'UTF-8') : '') . '" data-cost="' . htmlspecialchars(number_format($cost, 2, '.', ''), ENT_QUOTES, 'UTF-8') . '" data-cost-gross="' . htmlspecialchars(number_format($costBrutto, 2, '.', ''), ENT_QUOTES, 'UTF-8') . '" data-retail-net="' . htmlspecialchars(number_format($priceNetto, 2, '.', ''), ENT_QUOTES, 'UTF-8') . '" data-retail="' . htmlspecialchars(number_format($priceBrutto, 2, '.', ''), ENT_QUOTES, 'UTF-8') . '" aria-label="' . htmlspecialchars($this->t('sales_chart'), ENT_QUOTES, 'UTF-8') . '" title="' . htmlspecialchars($this->t('sales_chart'), ENT_QUOTES, 'UTF-8') . '"><i class="icon-bar-chart"></i></button>';
                $output .= '<button type="button" class="inventory-profit-trigger" data-product-name="' . htmlspecialchars($salesProductName, ENT_QUOTES, 'UTF-8') . '" data-combination-name="' . htmlspecialchars($salesCombinationName, ENT_QUOTES, 'UTF-8') . '" data-image-src="' . ($imgId > 0 ? htmlspecialchars($this->getImagePath($imgId), ENT_QUOTES, 'UTF-8') : '') . '" data-cost="' . htmlspecialchars(number_format($cost, 2, '.', ''), ENT_QUOTES, 'UTF-8') . '" data-cost-gross="' . htmlspecialchars(number_format($costBrutto, 2, '.', ''), ENT_QUOTES, 'UTF-8') . '" data-retail-net="' . htmlspecialchars(number_format($priceNetto, 2, '.', ''), ENT_QUOTES, 'UTF-8') . '" data-retail="' . htmlspecialchars(number_format($priceBrutto, 2, '.', ''), ENT_QUOTES, 'UTF-8') . '" aria-label="' . htmlspecialchars($this->t('profitability'), ENT_QUOTES, 'UTF-8') . '" title="' . htmlspecialchars($this->t('profitability'), ENT_QUOTES, 'UTF-8') . '"><span aria-hidden="true">%</span></button>';
                $output .= '<button type="button" class="inventory-hide-product inventory-hide-product-icon" data-id-product="' . $idProduct . '" aria-label="' . htmlspecialchars($this->t('hide_forever'), ENT_QUOTES, 'UTF-8') . '" title="' . htmlspecialchars($this->t('hide_forever'), ENT_QUOTES, 'UTF-8') . '"><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M3 3l18 18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/><path d="M10.58 10.58a2 2 0 0 0 2.84 2.84" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/><path d="M9.88 5.09A10.94 10.94 0 0 1 12 4.91c5.05 0 8.27 4.34 9.18 5.72a1.26 1.26 0 0 1 0 1.37 15.91 15.91 0 0 1-3.04 3.49" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/><path d="M6.61 6.61A15.91 15.91 0 0 0 2.82 10.63a1.26 1.26 0 0 0 0 1.37c.91 1.38 4.13 5.72 9.18 5.72a10.7 10.7 0 0 0 4.24-.86" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg></button>';
                $output .= '</div>';
                $output .= '</td>';

                $output .= '</tr>';
            }

            $colspanNetto = 6 + $visibleMetricColumns + ($showBrutto ? 1 : 0);
            $output .= '<tr class="inventory-summary-row" id="summaryNetto">';
            $output .= '<td colspan="' . $colspanNetto . '" class="text-end"><strong>' . htmlspecialchars($this->t('total_purchase_value_net'), ENT_QUOTES, 'UTF-8') . '</strong></td>';
            $output .= '<td class="text-center text-nowrap"><strong>' . $this->formatMoney((float) $result['total_value_netto']) . '</strong></td>';
            if ($showBrutto) {
                $output .= '<td></td>';
            }
            $output .= '<td></td>';
            $output .= '</tr>';

            if ($showBrutto) {
                $output .= '<tr class="inventory-summary-row" id="summaryBrutto">';
                $output .= '<td colspan="' . (8 + $visibleMetricColumns) . '" class="text-end"><strong>' . htmlspecialchars($this->t('total_retail_value_gross'), ENT_QUOTES, 'UTF-8') . '</strong></td>';
                $output .= '<td class="text-center text-nowrap"><strong>' . $this->formatMoney((float) $result['total_value_brutto']) . '</strong></td>';
                $output .= '<td></td>';
                $output .= '</tr>';
            }
        } else {
            $colspanEmpty = 8 + $visibleMetricColumns + ($showBrutto ? 2 : 0);
            $output = '<tr><td colspan="' . $colspanEmpty . '" class="text-center">' . htmlspecialchars($this->t('no_results'), ENT_QUOTES, 'UTF-8') . '</td></tr>';
        }

        return [
            'tbody' => $output,
            'pagination' => $this->renderPagination($result),
            'meta' => [
                'current_page' => $result['current_page'],
                'per_page' => $result['per_page'],
                'total_pages' => $result['total_pages'],
                'total_rows' => $result['total_rows'],
            ],
        ];
    }

    public function getMonthlySalesStats(int $idProduct, int $idAttr, int $months = 12, int $offsetMonths = 0): array
    {
        if ($idProduct <= 0) {
            throw new InvalidArgumentException($this->t('missing_id_product'));
        }

        $months = 12;
        $offsetMonths = max(0, min(120, $offsetMonths));
        $offsetYears = (int) floor($offsetMonths / 12);
        $selectedYear = (int) date('Y') - $offsetYears;
        $previousYear = $selectedYear - 1;
        $earliestYear = $selectedYear - 2;

        $monthLabels = [];
        $currentSeries = [];
        $previousSeries = [];
        $earliestSeries = [];
        $currentRevenueSeries = [];
        $previousRevenueSeries = [];
        $earliestRevenueSeries = [];
        $currentRevenueNetSeries = [];
        $previousRevenueNetSeries = [];
        $earliestRevenueNetSeries = [];

        for ($month = 1; $month <= 12; $month++) {
            $monthKey = sprintf('%02d', $month);
            $monthLabels[$monthKey] = sprintf('%s-%s-01', $selectedYear, $monthKey);
            $currentSeries[$monthKey] = 0;
            $previousSeries[$monthKey] = 0;
            $earliestSeries[$monthKey] = 0;
            $currentRevenueSeries[$monthKey] = 0.0;
            $previousRevenueSeries[$monthKey] = 0.0;
            $earliestRevenueSeries[$monthKey] = 0.0;
            $currentRevenueNetSeries[$monthKey] = 0.0;
            $previousRevenueNetSeries[$monthKey] = 0.0;
            $earliestRevenueNetSeries[$monthKey] = 0.0;
        }

        $dateFrom = sprintf('%d-01-01 00:00:00', $earliestYear);
        $dateTo = sprintf('%d-12-31 23:59:59', $selectedYear);

        $sql = '
            SELECT DATE_FORMAT(o.date_add, "%Y") AS sale_year, DATE_FORMAT(o.date_add, "%m") AS sale_month, SUM(od.product_quantity) AS sold_qty, SUM(od.total_price_tax_incl / NULLIF(o.conversion_rate, 0)) AS sold_value, SUM(od.total_price_tax_excl / NULLIF(o.conversion_rate, 0)) AS sold_value_net
            FROM `' . _DB_PREFIX_ . 'orders` o
            INNER JOIN `' . _DB_PREFIX_ . 'order_detail` od ON od.id_order = o.id_order
            WHERE o.valid = 1
              AND od.product_id = :id_product
              AND od.product_attribute_id = :id_attr
              AND o.date_add >= :date_from
              AND o.date_add <= :date_to
            GROUP BY sale_year, sale_month
            ORDER BY sale_year ASC, sale_month ASC
        ';

        $stmt = $this->getPdo()->prepare($sql);
        $stmt->execute([
            ':id_product' => $idProduct,
            ':id_attr' => max(0, $idAttr),
            ':date_from' => $dateFrom,
            ':date_to' => $dateTo,
        ]);

        foreach ($stmt->fetchAll() as $row) {
            $saleYear = (int) ($row['sale_year'] ?? 0);
            $monthKey = (string) ($row['sale_month'] ?? '');
            if (!array_key_exists($monthKey, $currentSeries)) {
                continue;
            }

            $soldQty = (int) round((float) ($row['sold_qty'] ?? 0));
            $soldValue = (float) ($row['sold_value'] ?? 0);
            $soldValueNet = (float) ($row['sold_value_net'] ?? 0);

            if ($saleYear === $selectedYear) {
                $currentSeries[$monthKey] = $soldQty;
                $currentRevenueSeries[$monthKey] = $soldValue;
                $currentRevenueNetSeries[$monthKey] = $soldValueNet;
            } elseif ($saleYear === $previousYear) {
                $previousSeries[$monthKey] = $soldQty;
                $previousRevenueSeries[$monthKey] = $soldValue;
                $previousRevenueNetSeries[$monthKey] = $soldValueNet;
            } elseif ($saleYear === $earliestYear) {
                $earliestSeries[$monthKey] = $soldQty;
                $earliestRevenueSeries[$monthKey] = $soldValue;
                $earliestRevenueNetSeries[$monthKey] = $soldValueNet;
            }
        }

        $items = [];
        $currentYearTotal = 0;
        $previousYearTotal = 0;
        $earliestYearTotal = 0;
        $currentYearRevenue = 0.0;
        $previousYearRevenue = 0.0;
        $earliestYearRevenue = 0.0;
        $currentYearRevenueNet = 0.0;
        $previousYearRevenueNet = 0.0;
        $earliestYearRevenueNet = 0.0;
        $bestMonth = null;
        $bestMonthQty = -1;

        foreach (array_keys($monthLabels) as $monthKey) {
            $currentQty = $currentSeries[$monthKey];
            $previousQty = $previousSeries[$monthKey];
            $earliestQty = $earliestSeries[$monthKey];
            $currentRevenue = $currentRevenueSeries[$monthKey];
            $previousRevenue = $previousRevenueSeries[$monthKey];
            $earliestRevenue = $earliestRevenueSeries[$monthKey];
            $currentRevenueNet = $currentRevenueNetSeries[$monthKey];
            $previousRevenueNet = $previousRevenueNetSeries[$monthKey];
            $earliestRevenueNet = $earliestRevenueNetSeries[$monthKey];
            $currentYearTotal += $currentQty;
            $previousYearTotal += $previousQty;
            $earliestYearTotal += $earliestQty;
            $currentYearRevenue += $currentRevenue;
            $previousYearRevenue += $previousRevenue;
            $earliestYearRevenue += $earliestRevenue;
            $currentYearRevenueNet += $currentRevenueNet;
            $previousYearRevenueNet += $previousRevenueNet;
            $earliestYearRevenueNet += $earliestRevenueNet;

            if ($currentQty > $bestMonthQty) {
                $bestMonthQty = $currentQty;
                $bestMonth = sprintf('%d-%s', $selectedYear, $monthKey);
            }

            $items[] = [
                'month' => $monthKey,
                'month_date' => $monthLabels[$monthKey],
                'quantity' => $currentQty,
                'previous_quantity' => $previousQty,
                'earliest_quantity' => $earliestQty,
                'value' => round($currentRevenue, 2),
                'previous_value' => round($previousRevenue, 2),
                'earliest_value' => round($earliestRevenue, 2),
                'value_net' => round($currentRevenueNet, 2),
                'previous_value_net' => round($previousRevenueNet, 2),
                'earliest_value_net' => round($earliestRevenueNet, 2),
            ];
        }

        if ($currentYearTotal <= 0) {
            $bestMonth = null;
            $bestMonthQty = 0;
        }

        return [
            'months' => $items,
            'comparison' => [
                'current_year' => $selectedYear,
                'previous_year' => $previousYear,
                'earliest_year' => $earliestYear,
            ],
            'summary' => [
                'months_count' => $months,
                'offset_months' => $offsetMonths,
                'total_sold' => $currentYearTotal,
                'previous_total_sold' => $previousYearTotal,
                'earliest_total_sold' => $earliestYearTotal,
                'total_value' => round($currentYearRevenue, 2),
                'previous_total_value' => round($previousYearRevenue, 2),
                'earliest_total_value' => round($earliestYearRevenue, 2),
                'total_value_net' => round($currentYearRevenueNet, 2),
                'previous_total_value_net' => round($previousYearRevenueNet, 2),
                'earliest_total_value_net' => round($earliestYearRevenueNet, 2),
                'best_month' => $bestMonth,
                'best_month_quantity' => max(0, $bestMonthQty),
            ],
        ];
    }

    public function saveWholesalePrice(int $idProduct, int $idAttr, string $priceRaw): float
    {
        $priceRaw = str_replace([' ', ','], ['', '.'], trim($priceRaw));

        if ($idProduct <= 0) {
            throw new InvalidArgumentException($this->t('missing_id_product'));
        }

        if ($priceRaw === '' || !is_numeric($priceRaw)) {
            throw new InvalidArgumentException($this->t('invalid_price'));
        }

        $price = (float) $priceRaw;
        if ($price <= 0) {
            throw new InvalidArgumentException($this->t('price_must_be_greater_than_zero'));
        }

        if ($idAttr > 0) {
            $stmt = $this->getPdo()->prepare('
                UPDATE `' . _DB_PREFIX_ . 'product_attribute`
                SET wholesale_price = :price
                WHERE id_product = :id_product
                  AND id_product_attribute = :id_attr
                LIMIT 1
            ');
            $stmt->execute([
                ':price' => $price,
                ':id_product' => $idProduct,
                ':id_attr' => $idAttr,
            ]);
        } else {
            $stmt = $this->getPdo()->prepare('
                UPDATE `' . _DB_PREFIX_ . 'product`
                SET wholesale_price = :price
                WHERE id_product = :id_product
                LIMIT 1
            ');
            $stmt->execute([
                ':price' => $price,
                ':id_product' => $idProduct,
            ]);
        }

        return $price;
    }

    public function saveRetailGrossPrice(int $idProduct, int $idAttr, string $priceRaw): float
    {
        $priceRaw = str_replace([' ', ','], ['', '.'], trim($priceRaw));

        if ($idProduct <= 0) {
            throw new InvalidArgumentException($this->t('missing_id_product'));
        }

        if ($priceRaw === '' || !is_numeric($priceRaw)) {
            throw new InvalidArgumentException($this->t('invalid_price'));
        }

        $grossPrice = (float) $priceRaw;
        if ($grossPrice <= 0) {
            throw new InvalidArgumentException($this->t('price_must_be_greater_than_zero'));
        }

        $pricingContext = $this->getRetailPricingContext($idProduct, $idAttr);
        $taxMultiplier = 1 + ((float) $pricingContext['tax_rate'] / 100);
        $netPrice = $grossPrice / ($taxMultiplier > 0 ? $taxMultiplier : 1);

        if ($idAttr > 0) {
            $attributeNetImpact = $netPrice - (float) $pricingContext['base_net_price'];

            $stmt = $this->getPdo()->prepare('
                UPDATE `' . _DB_PREFIX_ . 'product_attribute`
                SET price = :price
                WHERE id_product = :id_product
                  AND id_product_attribute = :id_attr
                LIMIT 1
            ');
            $stmt->execute([
                ':price' => $attributeNetImpact,
                ':id_product' => $idProduct,
                ':id_attr' => $idAttr,
            ]);
        } else {
            $stmtProduct = $this->getPdo()->prepare('
                UPDATE `' . _DB_PREFIX_ . 'product`
                SET price = :price
                WHERE id_product = :id_product
                LIMIT 1
            ');
            $stmtProduct->execute([
                ':price' => $netPrice,
                ':id_product' => $idProduct,
            ]);

            $stmtShop = $this->getPdo()->prepare('
                UPDATE `' . _DB_PREFIX_ . 'product_shop`
                SET price = :price
                WHERE id_product = :id_product
            ');
            $stmtShop->execute([
                ':price' => $netPrice,
                ':id_product' => $idProduct,
            ]);
        }

        return round($grossPrice, 2);
    }

    public function saveQuantity(int $idProduct, int $idAttr, string $quantityRaw): int
    {
        $quantityRaw = trim($quantityRaw);

        if ($idProduct <= 0) {
            throw new InvalidArgumentException($this->t('missing_id_product'));
        }

        if ($quantityRaw === '' || !preg_match('/^-?\d+$/', $quantityRaw)) {
            throw new InvalidArgumentException($this->t('invalid_quantity'));
        }

        $quantity = (int) $quantityRaw;

        if (!class_exists('StockAvailable') || !method_exists('StockAvailable', 'setQuantity')) {
            throw new RuntimeException($this->t('stock_api_not_available'));
        }

        StockAvailable::setQuantity(
            $idProduct,
            $idAttr,
            $quantity,
            (int) $this->context->shop->id
        );

        return $quantity;
    }

    public function saveWeight(int $idProduct, int $idAttr, string $weightRaw): float
    {
        $weightRaw = str_replace([' ', ','], ['', '.'], trim($weightRaw));

        if ($idProduct <= 0) {
            throw new InvalidArgumentException($this->t('missing_id_product'));
        }

        if ($weightRaw === '' || !is_numeric($weightRaw)) {
            throw new InvalidArgumentException($this->t('invalid_weight'));
        }

        $weight = round((float) $weightRaw, 6);
        $weightForDb = number_format($weight, 6, '.', '');
        if ($weight < 0) {
            throw new InvalidArgumentException($this->t('invalid_weight'));
        }

        if ($idAttr > 0) {
            $baseWeight = $this->getBaseProductWeight($idProduct);
            $attributeWeight = $weight - $baseWeight;
            $attributeWeightForDb = number_format($attributeWeight, 6, '.', '');

            $stmt = $this->getPdo()->prepare('
                UPDATE `' . _DB_PREFIX_ . 'product_attribute`
                SET weight = :weight
                WHERE id_product = :id_product
                  AND id_product_attribute = :id_attr
                LIMIT 1
            ');
            $stmt->execute([
                ':weight' => $attributeWeightForDb,
                ':id_product' => $idProduct,
                ':id_attr' => $idAttr,
            ]);
        } else {
            $stmtProduct = $this->getPdo()->prepare('
                UPDATE `' . _DB_PREFIX_ . 'product`
                SET weight = :weight
                WHERE id_product = :id_product
                LIMIT 1
            ');
            $stmtProduct->execute([
                ':weight' => $weightForDb,
                ':id_product' => $idProduct,
            ]);
        }

        return round($weight, 3);
    }

    public function saveUnitVolume(int $idProduct, int $idAttr, string $volumeRaw): float
    {
        $volumeRaw = str_replace([' ', ','], ['', '.'], trim($volumeRaw));

        if ($idProduct <= 0) {
            throw new InvalidArgumentException($this->t('missing_id_product'));
        }

        if ($volumeRaw === '' || !is_numeric($volumeRaw)) {
            throw new InvalidArgumentException($this->t('invalid_unit_volume'));
        }

        $volume = round((float) $volumeRaw, 6);
        if ($volume < 0) {
            throw new InvalidArgumentException($this->t('invalid_unit_volume'));
        }

        $this->ensureProductLogisticsInfrastructure();
        $this->upsertProductLogisticsData($idProduct, $idAttr, [
            'unit_volume' => number_format($volume, 6, '.', ''),
        ]);

        return $volume;
    }

    public function saveUnitsPerCarton(int $idProduct, int $idAttr, string $unitsRaw): int
    {
        $unitsRaw = trim($unitsRaw);

        if ($idProduct <= 0) {
            throw new InvalidArgumentException($this->t('missing_id_product'));
        }

        if ($unitsRaw === '' || !preg_match('/^\d+$/', $unitsRaw)) {
            throw new InvalidArgumentException($this->t('invalid_units_per_carton'));
        }

        $units = (int) $unitsRaw;
        $this->ensureProductLogisticsInfrastructure();
        $this->upsertProductLogisticsData($idProduct, $idAttr, [
            'units_per_carton' => $units,
        ]);

        return $units;
    }

    public function saveCartonDimensions(int $idProduct, int $idAttr, string $dimensionsRaw): array
    {
        if ($idProduct <= 0) {
            throw new InvalidArgumentException($this->t('missing_id_product'));
        }

        $dimensionsRaw = trim($dimensionsRaw);
        $dimensions = $dimensionsRaw === ''
            ? ['length' => 0.0, 'width' => 0.0, 'height' => 0.0]
            : $this->parseCartonDimensions($dimensionsRaw);
        $this->ensureProductLogisticsInfrastructure();
        $this->upsertProductLogisticsData($idProduct, $idAttr, [
            'carton_length' => number_format($dimensions['length'], 3, '.', ''),
            'carton_width' => number_format($dimensions['width'], 3, '.', ''),
            'carton_height' => number_format($dimensions['height'], 3, '.', ''),
        ]);

        return $dimensions;
    }

    public function saveCartonGrossWeight(int $idProduct, int $idAttr, string $weightRaw): float
    {
        $weightRaw = str_replace([' ', ','], ['', '.'], trim($weightRaw));

        if ($idProduct <= 0) {
            throw new InvalidArgumentException($this->t('missing_id_product'));
        }

        if ($weightRaw === '' || !is_numeric($weightRaw)) {
            throw new InvalidArgumentException($this->t('invalid_carton_gross_weight'));
        }

        $weight = round((float) $weightRaw, 6);
        if ($weight < 0) {
            throw new InvalidArgumentException($this->t('invalid_carton_gross_weight'));
        }

        $this->ensureProductLogisticsInfrastructure();
        $this->upsertProductLogisticsData($idProduct, $idAttr, [
            'carton_gross_weight' => number_format($weight, 6, '.', ''),
        ]);

        return $weight;
    }

    public function getIgnoredProducts(): array
    {
        $ignoredIds = $this->getIgnoredIds();
        if ($ignoredIds === []) {
            return [];
        }

        $prefix = _DB_PREFIX_;
        $idLang = (int) $this->context->language->id;
        $idShop = (int) $this->context->shop->id;

        $params = [
            ':id_lang' => $idLang,
            ':id_shop' => $idShop,
        ];
        $placeholders = [];
        foreach ($ignoredIds as $index => $id) {
            $placeholder = ':ignored_' . $index;
            $placeholders[] = $placeholder;
            $params[$placeholder] = (int) $id;
        }

        $sql = "
            SELECT
                p.id_product,
                IFNULL(ps.active, p.active) AS active,
                p.ean13,
                pl.name AS product_name,
                i.id_image AS product_image_id
            FROM `{$prefix}product` p
            LEFT JOIN `{$prefix}product_shop` ps
                ON p.id_product = ps.id_product
               AND ps.id_shop = :id_shop
            LEFT JOIN `{$prefix}product_lang` pl
                ON p.id_product = pl.id_product
               AND pl.id_lang = :id_lang
               AND pl.id_shop = :id_shop
            LEFT JOIN `{$prefix}image` i
                ON p.id_product = i.id_product
               AND i.cover = 1
            WHERE p.id_product IN (" . implode(',', $placeholders) . ")
            ORDER BY pl.name ASC
        ";

        $stmt = $this->getPdo()->prepare($sql);
        foreach ($params as $key => $value) {
            $stmt->bindValue($key, $value, is_int($value) ? PDO::PARAM_INT : PDO::PARAM_STR);
        }
        $stmt->execute();

        $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($products as &$product) {
            $product['image_url'] = !empty($product['product_image_id'])
                ? $this->getImagePath((int) $product['product_image_id'])
                : null;
        }
        unset($product);

        return $products;
    }

    public function getSuppliers(): array
    {
        $sql = '
            SELECT
                s.id_supplier,
                s.name,
                s.active,
                s.date_add,
                s.date_upd,
                COUNT(DISTINCT ps.id_product) AS products_count
            FROM `' . _DB_PREFIX_ . 'supplier` s
            LEFT JOIN `' . _DB_PREFIX_ . 'product_supplier` ps ON ps.id_supplier = s.id_supplier
            GROUP BY s.id_supplier, s.name, s.active, s.date_add, s.date_upd
            ORDER BY s.name ASC
        ';

        $rows = $this->getPdo()->query($sql)->fetchAll(PDO::FETCH_ASSOC);
        if (!is_array($rows)) {
            return [];
        }

        $suppliers = [];
        foreach ($rows as $row) {
            $idSupplier = (int) ($row['id_supplier'] ?? 0);
            if ($idSupplier <= 0) {
                continue;
            }

            $suppliers[] = [
                'id_supplier' => $idSupplier,
                'name' => (string) ($row['name'] ?? ''),
                'active' => (bool) ($row['active'] ?? false),
                'date_add' => (string) ($row['date_add'] ?? ''),
                'date_upd' => (string) ($row['date_upd'] ?? ''),
                'products_count' => (int) ($row['products_count'] ?? 0),
                'edit_url' => $this->getSupplierModuleEditUrl($idSupplier),
            ];
        }

        return $suppliers;
    }

    public function ensurePurchaseOrderInfrastructure(): void
    {
        if ($this->purchaseOrderInfrastructureReady) {
            return;
        }

        $this->ensureProductLogisticsInfrastructure();
        $this->createPurchaseOrderTables();
        $this->ensurePurchaseOrderFileTableColumns();
        $this->migratePurchaseOrderStatuses();
        $this->ensurePurchaseOrderUploadDirectory();
        $this->seedPurchaseOrdersIfEmpty();
        $this->purchaseOrderInfrastructureReady = true;
    }

    public function ensureProductLogisticsInfrastructure(): void
    {
        if ($this->productLogisticsInfrastructureReady) {
            return;
        }

        $this->createProductLogisticsTable();
        $this->ensureProductLogisticsTableColumns();
        $this->productLogisticsInfrastructureReady = true;
    }

    public function getConfiguredDeliveryAddress(): string
    {
        return trim((string) Configuration::get(self::CONFIG_PURCHASE_DELIVERY_ADDRESS));
    }

    public function saveConfiguredDeliveryAddress(string $address): void
    {
        Configuration::updateValue(self::CONFIG_PURCHASE_DELIVERY_ADDRESS, trim($address));
    }

    public function getConfiguredPurchaseOrderStatuses(): array
    {
        $stored = Configuration::get(self::CONFIG_PURCHASE_ORDER_STATUSES);
        if (!is_string($stored) || trim($stored) === '') {
            return $this->getDefaultPurchaseOrderStatuses();
        }

        $decoded = json_decode($stored, true);
        if (!is_array($decoded)) {
            return $this->getDefaultPurchaseOrderStatuses();
        }

        $statuses = $this->normalizePurchaseOrderStatusesForStorage($decoded);
        if ($statuses === []) {
            return $this->getDefaultPurchaseOrderStatuses();
        }

        return array_map(function (array $status): array {
            $status['badge_style'] = $this->buildPurchaseOrderBadgeStyle((string) ($status['color'] ?? ''));

            return $status;
        }, $statuses);
    }

    public function savePurchaseOrderSettings(string $deliveryAddress, array $statuses): void
    {
        Configuration::updateValue(self::CONFIG_PURCHASE_DELIVERY_ADDRESS, trim($deliveryAddress));
        Configuration::updateValue(
            self::CONFIG_PURCHASE_ORDER_STATUSES,
            json_encode($this->normalizePurchaseOrderStatusesForStorage($statuses), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
        );
    }

    public function addOrderStatusEntry(string $label, string $color): array
    {
        $statuses = array_map(static function (array $s): array {
            return ['key' => $s['key'], 'label' => $s['label'], 'color' => $s['color']];
        }, $this->getConfiguredPurchaseOrderStatuses());

        $usedKeys = array_column($statuses, 'key');
        $key = $this->buildUniquePurchaseOrderStatusKey($label, $usedKeys);
        $normalizedColor = $this->normalizePurchaseOrderStatusColor($color);
        $label = $this->truncatePurchaseOrderStatusLabel($label);

        $statuses[] = ['key' => $key, 'label' => $label, 'color' => $normalizedColor];
        Configuration::updateValue(
            self::CONFIG_PURCHASE_ORDER_STATUSES,
            json_encode($statuses, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
        );

        return [
            'key' => $key,
            'label' => $label,
            'color' => $normalizedColor,
            'badge_style' => $this->buildPurchaseOrderBadgeStyle($normalizedColor),
        ];
    }

    public function saveOrderStatusEntry(string $key, string $label, string $color): array
    {
        $statuses = array_map(static function (array $s): array {
            return ['key' => $s['key'], 'label' => $s['label'], 'color' => $s['color']];
        }, $this->getConfiguredPurchaseOrderStatuses());

        $normalizedColor = $this->normalizePurchaseOrderStatusColor($color);
        $label = $this->truncatePurchaseOrderStatusLabel($label);
        $found = false;
        foreach ($statuses as &$status) {
            if ($status['key'] === $key) {
                $status['label'] = $label;
                $status['color'] = $normalizedColor;
                $found = true;
                break;
            }
        }
        unset($status);

        if (!$found) {
            throw new \InvalidArgumentException('Status nie istnieje: ' . $key);
        }

        Configuration::updateValue(
            self::CONFIG_PURCHASE_ORDER_STATUSES,
            json_encode($statuses, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
        );

        return [
            'key' => $key,
            'label' => $label,
            'color' => $normalizedColor,
            'badge_style' => $this->buildPurchaseOrderBadgeStyle($normalizedColor),
        ];
    }

    public function deleteOrderStatusEntry(string $key): void
    {
        $statuses = array_map(static function (array $s): array {
            return ['key' => $s['key'], 'label' => $s['label'], 'color' => $s['color']];
        }, $this->getConfiguredPurchaseOrderStatuses());

        $statuses = array_values(array_filter($statuses, static function (array $s) use ($key): bool {
            return $s['key'] !== $key;
        }));

        if (count($statuses) < 1) {
            throw new \InvalidArgumentException('Nie można usunąć ostatniego statusu.');
        }

        Configuration::updateValue(
            self::CONFIG_PURCHASE_ORDER_STATUSES,
            json_encode($statuses, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
        );
    }

    public function createPurchaseOrder(): int
    {
        $this->createPurchaseOrderTables();
        $this->ensurePurchaseOrderUploadDirectory();

        $suppliers = $this->getSuppliers();
        $defaultSupplier = $suppliers[0] ?? [];
        $idSupplier = (int) ($defaultSupplier['id_supplier'] ?? 0);
        $supplierName = trim((string) ($defaultSupplier['name'] ?? ''));
        $reference = $this->buildNextPurchaseOrderReference();
        $now = new DateTimeImmutable('now');
        $orderedAt = $now->format('Y-m-d H:i:s');
        $deliveryAt = $now->modify('+21 days')->format('Y-m-d H:i:s');
        $currencyCode = trim((string) ($this->context->currency->iso_code ?? 'PLN'));
        if ($currencyCode === '') {
            $currencyCode = 'PLN';
        }
        $defaultStatusKey = $this->getDefaultPurchaseOrderStatusKey();

        $stmt = $this->getPdo()->prepare('
            INSERT INTO `' . $this->purchaseOrderTable('purchase_order') . '` (
                reference,
                id_supplier,
                supplier_name,
                delivery_address,
                ordered_at,
                delivery_at,
                shipment_number,
                invoice_number,
                currency_code,
                currency_rate,
                status_key,
                incoterm_code,
                transport_cost,
                carrier_name,
                date_add,
                date_upd
            ) VALUES (
                :reference,
                :id_supplier,
                :supplier_name,
                :delivery_address,
                :ordered_at,
                :delivery_at,
                "",
                "",
                :currency_code,
                1.000000,
                :status_key,
                "FOB",
                0.000000,
                "",
                NOW(),
                NOW()
            )
        ');
        $stmt->execute([
            ':reference' => $reference,
            ':id_supplier' => $idSupplier > 0 ? $idSupplier : null,
            ':supplier_name' => $supplierName,
            ':delivery_address' => $this->getConfiguredDeliveryAddress(),
            ':ordered_at' => $orderedAt,
            ':delivery_at' => $deliveryAt,
            ':currency_code' => $currencyCode,
            ':status_key' => $defaultStatusKey,
        ]);

        $idPurchaseOrder = (int) $this->getPdo()->lastInsertId();
        $this->seedPurchaseOrderItems($idPurchaseOrder, max(0, $idPurchaseOrder - 1));

        return $idPurchaseOrder;
    }

    public function getPurchaseOrders(): array
    {
        $this->ensurePurchaseOrderInfrastructure();

        $stmt = $this->getPdo()->query('
            SELECT
                po.id_purchase_order,
                po.reference,
                po.id_supplier,
                po.supplier_name,
                po.ordered_at,
                po.currency_code,
                po.status_key,
                po.transport_cost,
                COALESCE(NULLIF(s.name, ""), NULLIF(po.supplier_name, ""), "") AS resolved_supplier_name,
                COALESCE(SUM(poi.quantity * poi.purchase_price), 0) AS items_value
            FROM `' . $this->purchaseOrderTable('purchase_order') . '` po
            LEFT JOIN `' . _DB_PREFIX_ . 'supplier` s ON s.id_supplier = po.id_supplier
            LEFT JOIN `' . $this->purchaseOrderTable('purchase_order_item') . '` poi ON poi.id_purchase_order = po.id_purchase_order
            GROUP BY
                po.id_purchase_order,
                po.reference,
                po.id_supplier,
                po.supplier_name,
                po.ordered_at,
                po.currency_code,
                po.status_key,
                po.transport_cost,
                s.name
            ORDER BY po.ordered_at DESC, po.id_purchase_order DESC
        ');

        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $orders = [];
        foreach ($rows as $row) {
            $normalizedStatusKey = $this->normalizePurchaseOrderStatusKey((string) ($row['status_key'] ?? 'draft'));
            $statusMeta = $this->getPurchaseOrderStatusMeta($normalizedStatusKey);
            $currencyCode = trim((string) ($row['currency_code'] ?? 'PLN'));
            if ($currencyCode === '') {
                $currencyCode = 'PLN';
            }

            $totalValue = (float) ($row['items_value'] ?? 0) + (float) ($row['transport_cost'] ?? 0);
            $orders[] = [
                'id_purchase_order' => (int) ($row['id_purchase_order'] ?? 0),
                'number' => (string) ($row['reference'] ?? ''),
                'supplier_name' => (string) ($row['resolved_supplier_name'] ?? ''),
                'ordered_at' => $this->formatDateTimeLabel($row['ordered_at'] ?? null),
                'status_key' => $normalizedStatusKey,
                'status_label' => $statusMeta['label'],
                'status_badge_class' => $statusMeta['class'],
                'status_badge_style' => $statusMeta['badge_style'],
                'value_formatted' => $this->formatMoneyByCurrency($totalValue, $currencyCode),
            ];
        }

        return $orders;
    }

    public function getPurchaseOrder(int $idPurchaseOrder): array
    {
        $this->ensurePurchaseOrderInfrastructure();

        $stmt = $this->getPdo()->prepare('
            SELECT *
            FROM `' . $this->purchaseOrderTable('purchase_order') . '`
            WHERE id_purchase_order = :id_purchase_order
            LIMIT 1
        ');
        $stmt->execute([
            ':id_purchase_order' => $idPurchaseOrder,
        ]);

        $order = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!is_array($order)) {
            throw new InvalidArgumentException('Nie znaleziono zamówienia.');
        }

        $normalizedStatusKey = $this->normalizePurchaseOrderStatusKey((string) ($order['status_key'] ?? 'draft'));
        $statusMeta = $this->getPurchaseOrderStatusMeta($normalizedStatusKey);
        $currencyCode = trim((string) ($order['currency_code'] ?? 'PLN'));
        if ($currencyCode === '') {
            $currencyCode = 'PLN';
        }

        $supplierSummary = $this->getPurchaseOrderSupplierSummary(
            (int) ($order['id_supplier'] ?? 0),
            (string) ($order['supplier_name'] ?? '')
        );
        $items = $this->getPurchaseOrderItems($idPurchaseOrder, $currencyCode);
        $files = $this->getPurchaseOrderFiles($idPurchaseOrder);
        $itemsValue = 0.0;
        foreach ($items as $item) {
            $itemsValue += (float) ($item['line_value_raw'] ?? 0);
        }
        $transportCost = (float) ($order['transport_cost'] ?? 0);

        return [
            'order' => [
                'id_purchase_order' => (int) ($order['id_purchase_order'] ?? 0),
                'reference' => (string) ($order['reference'] ?? ''),
                'id_supplier' => (int) ($order['id_supplier'] ?? 0),
                'delivery_address' => (string) ($order['delivery_address'] ?? ''),
                'ordered_at_input' => $this->formatDateTimeInput($order['ordered_at'] ?? null),
                'ordered_at_date' => $this->formatDateInput($order['ordered_at'] ?? null),
                'ordered_at_label' => $this->formatDateLabel($order['ordered_at'] ?? null),
                'delivery_at_input' => $this->formatDateTimeInput($order['delivery_at'] ?? null),
                'delivery_at_date' => $this->formatDateInput($order['delivery_at'] ?? null),
                'delivery_at_label' => $this->formatDateLabel($order['delivery_at'] ?? null),
                'shipment_number' => (string) ($order['shipment_number'] ?? ''),
                'invoice_number' => (string) ($order['invoice_number'] ?? ''),
                'currency_code' => $currencyCode,
                'currency_rate' => number_format((float) ($order['currency_rate'] ?? 1), 6, '.', ''),
                'status_key' => $normalizedStatusKey,
                'status_label' => $statusMeta['label'],
                'status_badge_class' => $statusMeta['class'],
                'status_badge_style' => $statusMeta['badge_style'],
                'status_color' => $statusMeta['color'],
                'incoterm_code' => (string) ($order['incoterm_code'] ?? 'FOB'),
                'transport_cost' => number_format((float) ($order['transport_cost'] ?? 0), 2, '.', ''),
                'transport_cost_label' => $transportCost > 0 ? $this->formatMoneyByCurrency($transportCost, $currencyCode) : '---',
                'transport_cost_formatted' => $this->formatMoneyByCurrency($transportCost, $currencyCode),
                'carrier_name' => (string) ($order['carrier_name'] ?? ''),
                'items_total_formatted' => $this->formatMoneyByCurrency($itemsValue, $currencyCode),
                'total_value_formatted' => $this->formatMoneyByCurrency($itemsValue + $transportCost, $currencyCode),
            ],
            'supplier' => $supplierSummary,
            'recipient' => [
                'address' => trim((string) ($order['delivery_address'] ?? '')),
            ],
            'items' => $items,
            'files' => $files,
            'product_options' => $this->getPurchaseOrderCatalogProducts(),
            'supplier_options' => array_map(static function (array $supplier): array {
                return [
                    'id_supplier' => (int) ($supplier['id_supplier'] ?? 0),
                    'name' => (string) ($supplier['name'] ?? ''),
                ];
            }, $this->getSuppliers()),
            'status_options' => $this->getPurchaseOrderStatusOptions(),
            'incoterm_options' => $this->getPurchaseOrderIncotermOptions(),
            'currency_options' => $this->getPurchaseOrderCurrencyOptions(),
            'carrier_options' => array_map(static function (array $c): array {
                return ['value' => $c['name'], 'label' => $c['name']];
            }, $this->getCarriers()),
            'document_type_options' => $this->getDocumentTypes(),
        ];
    }

    public function savePurchaseOrder(int $idPurchaseOrder, array $data): void
    {
        $this->ensurePurchaseOrderInfrastructure();

        $existing = $this->getPurchaseOrder($idPurchaseOrder);
        $reference = trim((string) ($data['purchase_order_reference'] ?? $existing['order']['reference']));
        if ($reference === '') {
            $reference = $existing['order']['reference'] !== '' ? $existing['order']['reference'] : $this->buildNextPurchaseOrderReference();
        }

        $idSupplier = (int) ($data['id_supplier'] ?? $existing['order']['id_supplier']);
        $supplierName = $this->findSupplierNameById($idSupplier);
        $deliveryAddress = trim((string) ($data['delivery_address'] ?? $existing['order']['delivery_address'] ?? ''));
        if ($deliveryAddress === '') {
            $deliveryAddress = $this->getConfiguredDeliveryAddress();
        }

        $currencyCode = strtoupper(trim((string) ($data['currency_code'] ?? $existing['order']['currency_code'])));
        if ($currencyCode === '') {
            $currencyCode = 'PLN';
        }

        $currencyRate = (float) ($data['currency_rate'] ?? $existing['order']['currency_rate']);
        if ($currencyRate <= 0) {
            $currencyRate = 1.0;
        }

        $statusKey = $this->normalizePurchaseOrderStatusKey((string) ($data['status_key'] ?? $existing['order']['status_key']));
        if (!isset($this->getPurchaseOrderStatusMap()[$statusKey])) {
            $statusKey = $this->getDefaultPurchaseOrderStatusKey();
        }

        $incotermCode = strtoupper(trim((string) ($data['incoterm_code'] ?? $existing['order']['incoterm_code'])));
        if (!in_array($incotermCode, array_column($this->getPurchaseOrderIncotermOptions(), 'value'), true)) {
            $incotermCode = 'FOB';
        }

        $stmt = $this->getPdo()->prepare('
            UPDATE `' . $this->purchaseOrderTable('purchase_order') . '`
            SET
                reference = :reference,
                id_supplier = :id_supplier,
                supplier_name = :supplier_name,
                delivery_address = :delivery_address,
                ordered_at = :ordered_at,
                delivery_at = :delivery_at,
                shipment_number = :shipment_number,
                invoice_number = :invoice_number,
                currency_code = :currency_code,
                currency_rate = :currency_rate,
                status_key = :status_key,
                incoterm_code = :incoterm_code,
                transport_cost = :transport_cost,
                carrier_name = :carrier_name,
                date_upd = NOW()
            WHERE id_purchase_order = :id_purchase_order
            LIMIT 1
        ');
        $stmt->execute([
            ':reference' => $reference,
            ':id_supplier' => $idSupplier > 0 ? $idSupplier : null,
            ':supplier_name' => $supplierName,
            ':delivery_address' => $deliveryAddress,
            ':ordered_at' => $this->normalizeDateTimeValue((string) ($data['ordered_at'] ?? $existing['order']['ordered_at_input'] ?? '')),
            ':delivery_at' => $this->normalizeDateTimeValue((string) ($data['delivery_at'] ?? $existing['order']['delivery_at_input'] ?? '')),
            ':shipment_number' => trim((string) ($data['shipment_number'] ?? ($existing['order']['shipment_number'] ?? ''))),
            ':invoice_number' => trim((string) ($data['invoice_number'] ?? ($existing['order']['invoice_number'] ?? ''))),
            ':currency_code' => $currencyCode,
            ':currency_rate' => number_format($currencyRate, 6, '.', ''),
            ':status_key' => $statusKey,
            ':incoterm_code' => $incotermCode,
            ':transport_cost' => number_format(max(0, (float) ($data['transport_cost'] ?? ($existing['order']['transport_cost'] ?? 0))), 6, '.', ''),
            ':carrier_name' => trim((string) ($data['carrier_name'] ?? ($existing['order']['carrier_name'] ?? ''))),
            ':id_purchase_order' => $idPurchaseOrder,
        ]);
    }

    public function updatePurchaseOrderSupplier(int $idPurchaseOrder, int $idSupplier): array
    {
        $this->savePurchaseOrder($idPurchaseOrder, [
            'id_supplier' => $idSupplier,
        ]);

        $purchaseOrder = $this->getPurchaseOrder($idPurchaseOrder);

        return [
            'supplier' => is_array($purchaseOrder['supplier'] ?? null) ? $purchaseOrder['supplier'] : [],
            'order' => [
                'id_supplier' => (int) ($purchaseOrder['order']['id_supplier'] ?? 0),
            ],
        ];
    }

    public function updatePurchaseOrderFieldInline(int $idPurchaseOrder, string $field, string $value): array
    {
        $allowedFields = ['incoterm_code', 'ordered_at', 'delivery_at', 'carrier_name', 'invoice_number', 'transport_cost', 'shipment_number', 'currency_code', 'currency_rate'];
        $field = trim($field);
        if (!in_array($field, $allowedFields, true)) {
            throw new InvalidArgumentException('Nieprawidłowe pole zamówienia.');
        }

        $value = trim($value);
        if (in_array($field, ['ordered_at', 'delivery_at'], true)) {
            if ($value !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $value)) {
                throw new InvalidArgumentException('Data ma nieprawidłowy format.');
            }

            $value = $value !== '' ? $value . ' 00:00:00' : '';
        }

        if ($field === 'transport_cost') {
            if ($value !== '') {
                $normalizedPrice = str_replace([' ', ','], ['', '.'], $value);
                if (!is_numeric($normalizedPrice) || (float) $normalizedPrice < 0) {
                    throw new InvalidArgumentException('Koszt transportu ma nieprawidłowy format.');
                }

                $value = number_format((float) $normalizedPrice, 2, '.', '');
            }
        }

        if ($field === 'currency_code') {
            $value = strtoupper(preg_replace('/[^A-Za-z]/', '', $value));
            if ($value === '' || strlen($value) > 8) {
                throw new InvalidArgumentException('Nieprawidłowy kod waluty.');
            }
        }

        if ($field === 'currency_rate') {
            $normalizedRate = str_replace([' ', ','], ['', '.'], $value);
            if ($normalizedRate === '' || !is_numeric($normalizedRate) || (float) $normalizedRate <= 0) {
                throw new InvalidArgumentException('Kurs waluty ma nieprawidłowy format.');
            }
            $value = number_format((float) $normalizedRate, 6, '.', '');
        }

        $this->savePurchaseOrder($idPurchaseOrder, [
            $field => $value,
        ]);

        $purchaseOrder = $this->getPurchaseOrder($idPurchaseOrder);

        return [
            'order' => $this->buildPurchaseOrderInlineOrderPayload($purchaseOrder),
        ];
    }

    public function updatePurchaseOrderStatus(int $idPurchaseOrder, string $statusKey): void
    {
        $this->ensurePurchaseOrderInfrastructure();

        $statusKey = $this->normalizePurchaseOrderStatusKey($statusKey);
        if (!isset($this->getPurchaseOrderStatusMap()[$statusKey])) {
            throw new InvalidArgumentException('Nieprawidłowy status zamówienia.');
        }

        $stmt = $this->getPdo()->prepare('
            UPDATE `' . $this->purchaseOrderTable('purchase_order') . '`
            SET status_key = :status_key, date_upd = NOW()
            WHERE id_purchase_order = :id_purchase_order
            LIMIT 1
        ');
        $stmt->execute([
            ':status_key' => $statusKey,
            ':id_purchase_order' => $idPurchaseOrder,
        ]);
    }

    public function updatePurchaseOrderItemField(int $idPurchaseOrder, int $idPurchaseOrderItem, string $field, string $value): array
    {
        $this->ensurePurchaseOrderInfrastructure();

        $field = trim($field);
        if (!in_array($field, ['quantity', 'purchase_price'], true)) {
            throw new InvalidArgumentException('Nieprawidłowe pole pozycji zamówienia.');
        }

        $stmt = $this->getPdo()->prepare('
            SELECT id_purchase_order_item
            FROM `' . $this->purchaseOrderTable('purchase_order_item') . '`
            WHERE id_purchase_order_item = :id_purchase_order_item
              AND id_purchase_order = :id_purchase_order
            LIMIT 1
        ');
        $stmt->execute([
            ':id_purchase_order_item' => $idPurchaseOrderItem,
            ':id_purchase_order' => $idPurchaseOrder,
        ]);

        if (!$stmt->fetch(PDO::FETCH_ASSOC)) {
            throw new InvalidArgumentException('Nie znaleziono pozycji zamówienia.');
        }

        if ($field === 'quantity') {
            $normalizedValue = preg_replace('/\s+/u', '', trim($value));
            if ($normalizedValue === '' || !preg_match('/^\d+$/', $normalizedValue)) {
                throw new InvalidArgumentException('Ilość musi być liczbą całkowitą.');
            }

            $storedValue = number_format((float) ((int) $normalizedValue), 3, '.', '');
        } else {
            $normalizedValue = str_replace([' ', ','], ['', '.'], trim($value));
            if ($normalizedValue === '' || !is_numeric($normalizedValue)) {
                throw new InvalidArgumentException('Cena ma nieprawidłowy format.');
            }

            $price = round((float) $normalizedValue, 6);
            if ($price < 0) {
                throw new InvalidArgumentException('Cena nie może być ujemna.');
            }

            $storedValue = number_format($price, 6, '.', '');
        }

        $updateStmt = $this->getPdo()->prepare('
            UPDATE `' . $this->purchaseOrderTable('purchase_order_item') . '`
            SET `' . $field . '` = :value, date_upd = NOW()
            WHERE id_purchase_order_item = :id_purchase_order_item
              AND id_purchase_order = :id_purchase_order
            LIMIT 1
        ');
        $updateStmt->execute([
            ':value' => $storedValue,
            ':id_purchase_order_item' => $idPurchaseOrderItem,
            ':id_purchase_order' => $idPurchaseOrder,
        ]);

        $order = $this->getPurchaseOrder($idPurchaseOrder);
        foreach ($order['items'] as $item) {
            if ((int) ($item['id_purchase_order_item'] ?? 0) === $idPurchaseOrderItem) {
                return [
                    'item' => $item,
                    'items_total_formatted' => (string) ($order['order']['items_total_formatted'] ?? ''),
                ];
            }
        }

        throw new RuntimeException('Nie udało się odświeżyć pozycji zamówienia.');
    }

    public function updatePurchaseOrderProductModuleData(int $idPurchaseOrder, int $idPurchaseOrderItem, array $data): array
    {
        $this->ensurePurchaseOrderInfrastructure();

        $stmt = $this->getPdo()->prepare('
            SELECT id_product, id_product_attribute, model
            FROM `' . $this->purchaseOrderTable('purchase_order_item') . '`
            WHERE id_purchase_order_item = :id_purchase_order_item
              AND id_purchase_order = :id_purchase_order
            LIMIT 1
        ');
        $stmt->execute([
            ':id_purchase_order_item' => $idPurchaseOrderItem,
            ':id_purchase_order' => $idPurchaseOrder,
        ]);

        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!is_array($row)) {
            throw new InvalidArgumentException('Nie znaleziono pozycji zamówienia.');
        }

        $idProduct = (int) ($row['id_product'] ?? 0);
        $idProductAttribute = (int) ($row['id_product_attribute'] ?? 0);
        if ($idProduct <= 0) {
            throw new InvalidArgumentException('Nie można edytować danych modułowych dla tej pozycji.');
        }

        $normalizedData = $this->normalizeProductModuleData($data, (string) ($row['model'] ?? ''));
        $this->ensureProductLogisticsInfrastructure();
        $this->upsertProductLogisticsData($idProduct, $idProductAttribute, $normalizedData);

        $order = $this->getPurchaseOrder($idPurchaseOrder);
        foreach ($order['items'] as $item) {
            if ((int) ($item['id_purchase_order_item'] ?? 0) === $idPurchaseOrderItem) {
                return [
                    'item' => $item,
                ];
            }
        }

        throw new RuntimeException('Nie udało się odświeżyć produktu.');
    }

    public function addPurchaseOrderItem(int $idPurchaseOrder, string $productSelection, string $quantityRaw, string $priceRaw = ''): array
    {
        $this->ensurePurchaseOrderInfrastructure();

        if ($idPurchaseOrder <= 0) {
            throw new InvalidArgumentException('Nie znaleziono zamówienia.');
        }

        [$idProduct, $idProductAttribute] = $this->parsePurchaseOrderProductSelection($productSelection);
        $product = $this->getPurchaseOrderCatalogProduct($idProduct, $idProductAttribute);

        $normalizedQuantity = preg_replace('/\s+/u', '', trim($quantityRaw));
        if ($normalizedQuantity === '' || !preg_match('/^\d+$/', $normalizedQuantity)) {
            throw new InvalidArgumentException('Ilość musi być liczbą całkowitą.');
        }

        $quantity = max(1, (int) $normalizedQuantity);
        $purchasePrice = (float) ($product['purchase_price'] ?? 0);
        $priceRaw = trim($priceRaw);
        if ($priceRaw !== '') {
            $normalizedPrice = str_replace([' ', ','], ['', '.'], $priceRaw);
            if (!is_numeric($normalizedPrice)) {
                throw new InvalidArgumentException('Cena ma nieprawidłowy format.');
            }

            $purchasePrice = round((float) $normalizedPrice, 6);
            if ($purchasePrice < 0) {
                throw new InvalidArgumentException('Cena nie może być ujemna.');
            }
        }

        $displayName = trim((string) ($product['product_name'] ?? ''));
        $combinationName = trim((string) ($product['combination_name'] ?? ''));
        if ($combinationName !== '') {
            $displayName .= ' / ' . $combinationName;
        }

        $stmt = $this->getPdo()->prepare('
            INSERT INTO `' . $this->purchaseOrderTable('purchase_order_item') . '` (
                id_purchase_order,
                position,
                id_product,
                id_product_attribute,
                model,
                product_name,
                ean13,
                quantity,
                purchase_price,
                weight,
                image_id,
                date_add,
                date_upd
            ) VALUES (
                :id_purchase_order,
                :position,
                :id_product,
                :id_product_attribute,
                :model,
                :product_name,
                :ean13,
                :quantity,
                :purchase_price,
                :weight,
                :image_id,
                NOW(),
                NOW()
            )
        ');
        $stmt->execute([
            ':id_purchase_order' => $idPurchaseOrder,
            ':position' => $this->getNextPurchaseOrderItemPosition($idPurchaseOrder),
            ':id_product' => $idProduct,
            ':id_product_attribute' => $idProductAttribute,
            ':model' => (string) ($product['model'] ?? ''),
            ':product_name' => $displayName !== '' ? $displayName : ('Produkt #' . $idProduct),
            ':ean13' => (string) ($product['ean13'] ?? ''),
            ':quantity' => number_format((float) $quantity, 3, '.', ''),
            ':purchase_price' => number_format($purchasePrice, 6, '.', ''),
            ':weight' => number_format((float) ($product['weight'] ?? 0), 6, '.', ''),
            ':image_id' => (int) ($product['image_id'] ?? 0),
        ]);

        $idPurchaseOrderItem = (int) $this->getPdo()->lastInsertId();
        $order = $this->getPurchaseOrder($idPurchaseOrder);
        foreach ($order['items'] as $item) {
            if ((int) ($item['id_purchase_order_item'] ?? 0) === $idPurchaseOrderItem) {
                return [
                    'item' => $item,
                    'items_total_formatted' => (string) ($order['order']['items_total_formatted'] ?? ''),
                ];
            }
        }

        throw new RuntimeException('Nie udało się odświeżyć dodanej pozycji zamówienia.');
    }

    public function deletePurchaseOrder(int $idPurchaseOrder): void
    {
        $this->ensurePurchaseOrderInfrastructure();

        $files = $this->getPurchaseOrderFiles($idPurchaseOrder);
        foreach ($files as $file) {
            $path = (string) ($file['absolute_path'] ?? '');
            if ($path !== '' && is_file($path)) {
                @unlink($path);
            }
        }

        $stmtFiles = $this->getPdo()->prepare('DELETE FROM `' . $this->purchaseOrderTable('purchase_order_file') . '` WHERE id_purchase_order = :id_purchase_order');
        $stmtFiles->execute([
            ':id_purchase_order' => $idPurchaseOrder,
        ]);

        $stmtItems = $this->getPdo()->prepare('DELETE FROM `' . $this->purchaseOrderTable('purchase_order_item') . '` WHERE id_purchase_order = :id_purchase_order');
        $stmtItems->execute([
            ':id_purchase_order' => $idPurchaseOrder,
        ]);

        $stmtOrder = $this->getPdo()->prepare('DELETE FROM `' . $this->purchaseOrderTable('purchase_order') . '` WHERE id_purchase_order = :id_purchase_order LIMIT 1');
        $stmtOrder->execute([
            ':id_purchase_order' => $idPurchaseOrder,
        ]);
    }

    public function deletePurchaseOrderItem(int $idPurchaseOrderItem, int $idPurchaseOrder): void
    {
        $stmt = $this->getPdo()->prepare('
            DELETE FROM `' . $this->purchaseOrderTable('purchase_order_item') . '`
            WHERE id_purchase_order_item = :id_purchase_order_item
              AND id_purchase_order = :id_purchase_order
            LIMIT 1
        ');
        $stmt->execute([
            ':id_purchase_order_item' => $idPurchaseOrderItem,
            ':id_purchase_order' => $idPurchaseOrder,
        ]);
    }

    public function uploadPurchaseOrderFile(int $idPurchaseOrder, array $file, string $description = '', int $idDocumentType = 0): array
    {
        $this->ensurePurchaseOrderInfrastructure();

        $errorCode = (int) ($file['error'] ?? UPLOAD_ERR_NO_FILE);
        if ($errorCode !== UPLOAD_ERR_OK) {
            throw new RuntimeException('Nie udało się dodać pliku.');
        }

        $tmpName = (string) ($file['tmp_name'] ?? '');
        $originalName = trim((string) ($file['name'] ?? ''));
        if ($tmpName === '' || !is_uploaded_file($tmpName) || $originalName === '') {
            throw new RuntimeException('Nie udało się dodać pliku.');
        }

        $size = (int) ($file['size'] ?? 0);
        if ($size <= 0 || $size > self::PURCHASE_ORDER_UPLOAD_MAX_SIZE) {
            throw new RuntimeException('Nie udało się dodać pliku.');
        }

        $extension = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));
        $allowedExtensions = ['pdf', 'xls', 'xlsx', 'csv', 'doc', 'docx', 'xml', 'txt', 'jpg', 'jpeg', 'png', 'gif', 'webp', 'zip'];
        if ($extension === '' || !in_array($extension, $allowedExtensions, true)) {
            throw new RuntimeException('Niedozwolony typ pliku.');
        }

        $dirName = $this->getPurchaseOrderDirName($idPurchaseOrder);
        $perOrderDir = $this->getPurchaseOrderUploadDirectory($dirName);
        if (!is_dir($perOrderDir) && !mkdir($perOrderDir, 0775, true) && !is_dir($perOrderDir)) {
            throw new RuntimeException('Nie udało się dodać pliku.');
        }

        $storedName = bin2hex(random_bytes(12)) . '.' . $extension;
        $filePath = 'modules/prestashopinventory/uploads/purchase_orders/' . $dirName . '/' . $storedName;
        $destination = $perOrderDir . $storedName;

        if (!move_uploaded_file($tmpName, $destination)) {
            throw new RuntimeException('Nie udało się dodać pliku.');
        }

        $mimeType = (string) ($file['type'] ?? '');
        if ($mimeType === '' && function_exists('mime_content_type')) {
            $mimeType = (string) mime_content_type($destination);
        }

        $docTypeName = '';
        if ($idDocumentType > 0) {
            $dtStmt = $this->getPdo()->prepare('SELECT name FROM `' . $this->purchaseOrderTable('document_type') . '` WHERE id_psinv_document_type = :id LIMIT 1');
            $dtStmt->execute([':id' => $idDocumentType]);
            $dtRow = $dtStmt->fetch(\PDO::FETCH_ASSOC);
            $docTypeName = is_array($dtRow) ? (string) ($dtRow['name'] ?? '') : '';
        }

        $stmt = $this->getPdo()->prepare('
            INSERT INTO `' . $this->purchaseOrderTable('purchase_order_file') . '` (
                id_purchase_order,
                id_psinv_document_type,
                original_name,
                stored_name,
                file_path,
                mime_type,
                size_bytes,
                description,
                date_add
            ) VALUES (
                :id_purchase_order,
                :id_psinv_document_type,
                :original_name,
                :stored_name,
                :file_path,
                :mime_type,
                :size_bytes,
                :description,
                NOW()
            )
        ');
        $stmt->execute([
            ':id_purchase_order' => $idPurchaseOrder,
            ':id_psinv_document_type' => $idDocumentType > 0 ? $idDocumentType : null,
            ':original_name' => $originalName,
            ':stored_name' => $storedName,
            ':file_path' => $filePath,
            ':mime_type' => $mimeType,
            ':size_bytes' => $size,
            ':description' => trim($description),
        ]);

        $newId = (int) $this->getPdo()->lastInsertId();
        $imageExts = ['jpg', 'jpeg', 'png', 'gif', 'webp'];

        return [
            'id_purchase_order_file' => $newId,
            'original_name' => $originalName,
            'description' => trim($description),
            'document_type_name' => $docTypeName,
            'id_psinv_document_type' => $idDocumentType > 0 ? $idDocumentType : null,
            'mime_type' => $mimeType,
            'size_label' => $this->formatFileSize($size),
            'date_add' => (new \DateTimeImmutable('now'))->format('d.m.Y H:i'),
            'download_url' => $this->getPurchaseOrderFileUrl($filePath, $storedName),
            'is_image' => in_array($extension, $imageExts, true),
            'is_pdf' => $extension === 'pdf',
        ];
    }

    public function updatePurchaseOrderFileDescription(int $idPurchaseOrderFile, int $idPurchaseOrder, string $description): void
    {
        $this->ensurePurchaseOrderInfrastructure();
        $stmt = $this->getPdo()->prepare('
            UPDATE `' . $this->purchaseOrderTable('purchase_order_file') . '`
            SET description = :description
            WHERE id_purchase_order_file = :id_purchase_order_file
              AND id_purchase_order = :id_purchase_order
            LIMIT 1
        ');
        $stmt->execute([
            ':description' => trim($description),
            ':id_purchase_order_file' => $idPurchaseOrderFile,
            ':id_purchase_order' => $idPurchaseOrder,
        ]);
    }

    public function updatePurchaseOrderFileDocType(int $idPurchaseOrderFile, int $idPurchaseOrder, int $idDocType): array
    {
        $this->ensurePurchaseOrderInfrastructure();

        $stmt = $this->getPdo()->prepare('
            UPDATE `' . $this->purchaseOrderTable('purchase_order_file') . '`
            SET id_psinv_document_type = :id_psinv_document_type
            WHERE id_purchase_order_file = :id_purchase_order_file
              AND id_purchase_order = :id_purchase_order
            LIMIT 1
        ');
        $stmt->execute([
            ':id_psinv_document_type' => $idDocType > 0 ? $idDocType : null,
            ':id_purchase_order_file' => $idPurchaseOrderFile,
            ':id_purchase_order' => $idPurchaseOrder,
        ]);

        $docTypeName = '';
        if ($idDocType > 0) {
            $dtStmt = $this->getPdo()->prepare('SELECT name FROM `' . $this->purchaseOrderTable('document_type') . '` WHERE id_psinv_document_type = :id LIMIT 1');
            $dtStmt->execute([':id' => $idDocType]);
            $dtRow = $dtStmt->fetch(\PDO::FETCH_ASSOC);
            $docTypeName = is_array($dtRow) ? (string) ($dtRow['name'] ?? '') : '';
        }

        return ['id_psinv_document_type' => $idDocType > 0 ? $idDocType : null, 'document_type_name' => $docTypeName];
    }

    public function deletePurchaseOrderFile(int $idPurchaseOrderFile, int $idPurchaseOrder): void
    {
        $stmt = $this->getPdo()->prepare('
            SELECT stored_name, file_path
            FROM `' . $this->purchaseOrderTable('purchase_order_file') . '`
            WHERE id_purchase_order_file = :id_purchase_order_file
              AND id_purchase_order = :id_purchase_order
            LIMIT 1
        ');
        $stmt->execute([
            ':id_purchase_order_file' => $idPurchaseOrderFile,
            ':id_purchase_order' => $idPurchaseOrder,
        ]);

        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if (is_array($row)) {
            $absPath = $this->getPurchaseOrderFileAbsolutePath(
                (string) ($row['file_path'] ?? ''),
                (string) ($row['stored_name'] ?? '')
            );
            if ($absPath !== '' && is_file($absPath)) {
                @unlink($absPath);
            }
        }

        $deleteStmt = $this->getPdo()->prepare('
            DELETE FROM `' . $this->purchaseOrderTable('purchase_order_file') . '`
            WHERE id_purchase_order_file = :id_purchase_order_file
              AND id_purchase_order = :id_purchase_order
            LIMIT 1
        ');
        $deleteStmt->execute([
            ':id_purchase_order_file' => $idPurchaseOrderFile,
            ':id_purchase_order' => $idPurchaseOrder,
        ]);
    }

    public function getSupplierFormData(int $idSupplier): array
    {
        if ($idSupplier <= 0) {
            throw new InvalidArgumentException($this->t('supplier_not_found'));
        }

        $supplier = new Supplier($idSupplier);
        if (!Validate::isLoadedObject($supplier)) {
            throw new InvalidArgumentException($this->t('supplier_not_found'));
        }

        $description = '';
        if (isset($supplier->description)) {
            if (is_array($supplier->description)) {
                $description = (string) ($supplier->description[(int) $this->context->language->id] ?? reset($supplier->description) ?: '');
            } else {
                $description = (string) $supplier->description;
            }
        }

        return array_merge([
            'id_supplier' => (int) $supplier->id,
            'name' => (string) ($supplier->name ?? ''),
            'description' => $description,
            'active' => (bool) ($supplier->active ?? true),
        ], $this->getSupplierAddressData($idSupplier));
    }

    public function getSupplierCountries(): array
    {
        $sql = '
            SELECT c.id_country, cl.name
            FROM `' . _DB_PREFIX_ . 'country` c
            INNER JOIN `' . _DB_PREFIX_ . 'country_lang` cl ON cl.id_country = c.id_country AND cl.id_lang = :id_lang
            WHERE c.active = 1
            ORDER BY cl.name ASC
        ';

        $stmt = $this->getPdo()->prepare($sql);
        $stmt->execute([
            ':id_lang' => (int) $this->context->language->id,
        ]);

        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        if (!is_array($rows)) {
            return [];
        }

        return array_map(static function (array $row): array {
            return [
                'id_country' => (int) ($row['id_country'] ?? 0),
                'name' => (string) ($row['name'] ?? ''),
            ];
        }, $rows);
    }

    public function saveSupplier(array $data): int
    {
        $idSupplier = (int) ($data['id_supplier'] ?? 0);
        $name = trim((string) ($data['name'] ?? ''));
        $description = trim((string) ($data['description'] ?? ''));
        $active = $this->toBool($data['active'] ?? false, false);
        $phone = trim((string) ($data['phone'] ?? ''));
        $address1 = trim((string) ($data['address1'] ?? ''));
        $address2 = trim((string) ($data['address2'] ?? ''));
        $postcode = trim((string) ($data['postcode'] ?? ''));
        $city = trim((string) ($data['city'] ?? ''));
        $idCountry = (int) ($data['id_country'] ?? 0);

        if ($name === '' || $address1 === '' || $city === '' || $idCountry <= 0) {
            throw new InvalidArgumentException($this->t('supplier_save_error'));
        }

        $supplier = $idSupplier > 0 ? new Supplier($idSupplier) : new Supplier();
        if ($idSupplier > 0 && !Validate::isLoadedObject($supplier)) {
            throw new InvalidArgumentException($this->t('supplier_not_found'));
        }

        $supplier->name = $name;
        $supplier->active = $active ? 1 : 0;

        $descriptionByLang = [];
        $metaTitleByLang = [];
        $metaDescriptionByLang = [];
        $metaKeywordsByLang = [];
        foreach (Language::getLanguages(false) as $language) {
            $languageId = (int) ($language['id_lang'] ?? 0);
            if ($languageId <= 0) {
                continue;
            }

            $descriptionByLang[$languageId] = $description;
            $metaTitleByLang[$languageId] = $name;
            $metaDescriptionByLang[$languageId] = '';
            $metaKeywordsByLang[$languageId] = '';
        }

        if (property_exists($supplier, 'description')) {
            $supplier->description = $descriptionByLang;
        }
        if (property_exists($supplier, 'meta_title')) {
            $supplier->meta_title = $metaTitleByLang;
        }
        if (property_exists($supplier, 'meta_description')) {
            $supplier->meta_description = $metaDescriptionByLang;
        }
        if (property_exists($supplier, 'meta_keywords')) {
            $supplier->meta_keywords = $metaKeywordsByLang;
        }

        $saved = $idSupplier > 0 ? $supplier->update() : $supplier->add();
        if (!$saved || !Validate::isLoadedObject($supplier)) {
            throw new RuntimeException($this->t('supplier_save_error'));
        }

        $this->saveSupplierAddress((int) $supplier->id, [
            'phone' => $phone,
            'address1' => $address1,
            'address2' => $address2,
            'postcode' => $postcode,
            'city' => $city,
            'id_country' => $idCountry,
            'company' => $name,
        ]);

        return (int) $supplier->id;
    }

    public function hideProduct(int $idProduct): array
    {
        if ($idProduct <= 0) {
            throw new InvalidArgumentException($this->t('missing_id_product'));
        }

        $ids = $this->getIgnoredIds();
        if (!in_array($idProduct, $ids, true)) {
            $ids[] = $idProduct;
            sort($ids, SORT_NUMERIC);
            Configuration::updateValue(self::CONFIG_IGNORED_IDS, implode(PHP_EOL, $ids));
        }

        return [
            'id_product' => $idProduct,
            'ignored_ids' => $ids,
        ];
    }

    public function unhideProduct(int $idProduct): array
    {
        if ($idProduct <= 0) {
            throw new InvalidArgumentException($this->t('missing_id_product'));
        }

        $ids = array_values(array_filter($this->getIgnoredIds(), static function ($value) use ($idProduct) {
            return (int) $value !== $idProduct;
        }));

        Configuration::updateValue(self::CONFIG_IGNORED_IDS, implode(PHP_EOL, $ids));

        return [
            'id_product' => $idProduct,
            'ignored_ids' => $ids,
        ];
    }

    public function setProductActive(int $idProduct, $active): bool
    {
        if ($idProduct <= 0) {
            throw new InvalidArgumentException($this->t('missing_id_product'));
        }

        $isActive = $this->toBool($active);

        $stmt = $this->getPdo()->prepare('
            UPDATE `' . _DB_PREFIX_ . 'product`
            SET active = :active
            WHERE id_product = :id_product
            LIMIT 1
        ');
        $stmt->execute([
            ':active' => $isActive ? 1 : 0,
            ':id_product' => $idProduct,
        ]);

        $stmtShop = $this->getPdo()->prepare('
            UPDATE `' . _DB_PREFIX_ . 'product_shop`
            SET active = :active
            WHERE id_product = :id_product
        ');
        $stmtShop->execute([
            ':active' => $isActive ? 1 : 0,
            ':id_product' => $idProduct,
        ]);

        return $isActive;
    }

    private function getRetailPricingContext(int $idProduct, int $idAttr): array
    {
        $idShop = (int) $this->context->shop->id;
        $idCountry = (int) Configuration::get('PS_COUNTRY_DEFAULT');

        $sql = '
            SELECT
                IFNULL(ps.price, 0) AS base_net_price,
                IFNULL(pa.price, 0) AS attribute_net_impact,
                IFNULL(t.rate, 0) AS tax_rate
            FROM `' . _DB_PREFIX_ . 'product` p
            LEFT JOIN `' . _DB_PREFIX_ . 'product_shop` ps
                ON p.id_product = ps.id_product
               AND ps.id_shop = :id_shop
            LEFT JOIN `' . _DB_PREFIX_ . 'tax_rule` tr
                ON ps.id_tax_rules_group = tr.id_tax_rules_group
               AND tr.id_country = :id_country
               AND (tr.id_state = 0 OR tr.id_state IS NULL)
            LEFT JOIN `' . _DB_PREFIX_ . 'tax` t
                ON tr.id_tax = t.id_tax
            LEFT JOIN `' . _DB_PREFIX_ . 'product_attribute` pa
                ON p.id_product = pa.id_product
               AND pa.id_product_attribute = :id_attr
            WHERE p.id_product = :id_product
            LIMIT 1
        ';

        $stmt = $this->getPdo()->prepare($sql);
        $stmt->execute([
            ':id_shop' => $idShop,
            ':id_country' => $idCountry,
            ':id_attr' => $idAttr,
            ':id_product' => $idProduct,
        ]);

        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$result) {
            throw new InvalidArgumentException($this->t('product_not_found'));
        }

        return $result;
    }

    private function getBaseProductWeight(int $idProduct): float
    {
        $stmt = $this->getPdo()->prepare('
            SELECT IFNULL(weight, 0) AS weight
            FROM `' . _DB_PREFIX_ . 'product`
            WHERE id_product = :id_product
            LIMIT 1
        ');
        $stmt->execute([
            ':id_product' => $idProduct,
        ]);

        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$result) {
            throw new InvalidArgumentException($this->t('product_not_found'));
        }

        return (float) ($result['weight'] ?? 0);
    }

    public function outputPdfReport(array $filters): void
    {
        $this->loadPdfLibrary();

        $products = $this->fetchProducts($filters);
        $activeOnly = $this->toBool($filters['activeOnly'] ?? false);
        $onlyAvailable = $this->toBool($filters['onlyAvailable'] ?? false);
        $missingPurchasePriceOnly = $this->toBool($filters['missingPurchasePriceOnly'] ?? false);
        $missingWeightOnly = $this->toBool($filters['missingWeightOnly'] ?? false);
        $showWeight = $this->toBool($filters['showWeight'] ?? true, true);
        $showUnitVolume = $this->toBool($filters['showUnitVolume'] ?? true, true);
        $showUnitsPerCarton = $this->toBool($filters['showUnitsPerCarton'] ?? true, true);
        $showCartonDimensions = $this->toBool($filters['showCartonDimensions'] ?? true, true);
        $showBrutto = $this->toBool($filters['showBrutto'] ?? true, true);
        $visibleMetricColumns = ($showWeight ? 1 : 0)
            + ($showUnitVolume ? 1 : 0)
            + ($showUnitsPerCarton ? 1 : 0)
            + ($showCartonDimensions ? 1 : 0);
        $totalValueNetto = 0.0;
        $totalValueBrutto = 0.0;
        $rowsHtml = '';
        $lp = 1;

        foreach ($products as $product) {
            $ean = $product['combination_ean13'] ?: $product['product_ean13'];
            $name = (string) ($product['product_name'] ?? '');
            $comb = (string) ($product['combination_name'] ?? '');
            $cost = (float) ($product['product_cost'] ?? 0);
            $priceBrutto = (float) ($product['product_price_brutto'] ?? 0);
            $weight = (float) ($product['product_weight'] ?? 0);
            $unitVolume = $this->resolveProductUnitVolume($product);
            $unitsPerCarton = max(0, (int) ($product['units_per_carton'] ?? 0));
            $cartonLength = (float) ($product['carton_length'] ?? 0);
            $cartonWidth = (float) ($product['carton_width'] ?? 0);
            $cartonHeight = (float) ($product['carton_height'] ?? 0);
            $qty = (int) ($product['stock_quantity'] ?? 0);
            $value = ($cost > 0) ? ($cost * $qty) : 0.0;
            $valueBrutto = ($priceBrutto > 0) ? ($priceBrutto * $qty) : 0.0;
            $totalValueNetto += $value;
            $totalValueBrutto += $valueBrutto;

            $priceTxt = ($cost > 0) ? $this->formatMoney($cost) : '—';
            $priceBruttoTxt = ($priceBrutto > 0) ? $this->formatMoney($priceBrutto) : '—';
            $weightTxt = htmlspecialchars($this->formatWeight($weight), ENT_QUOTES, 'UTF-8');
            $unitVolumeTxt = htmlspecialchars($this->formatVolume($unitVolume), ENT_QUOTES, 'UTF-8');
            $unitsPerCartonTxt = $unitsPerCarton > 0 ? (string) $unitsPerCarton : '—';
            $cartonDimensionsTxt = htmlspecialchars($this->formatCartonDimensions($cartonLength, $cartonWidth, $cartonHeight), ENT_QUOTES, 'UTF-8');
            $valueTxt = $this->formatMoney($value);
            $valueBruttoTxt = $this->formatMoney($valueBrutto);

            $imgId = !empty($product['combination_image_id']) ? (int) $product['combination_image_id'] : (int) $product['product_image_id'];
            $imgSrc = $imgId > 0 ? $this->getAbsoluteImagePath($imgId) : null;
            $imgTag = $imgSrc ? '<img class="thumb" src="' . htmlspecialchars($imgSrc, ENT_QUOTES, 'UTF-8') . '">' : '—';

            $rowsHtml .= '
                <tr>
                    <td class="c lp">' . $lp++ . '</td>
                    <td class="c img">' . $imgTag . '</td>
                    <td class="ean">' . htmlspecialchars((string) $ean, ENT_QUOTES, 'UTF-8') . '</td>
                    <td class="name">
                        <div class="n">' . htmlspecialchars($name, ENT_QUOTES, 'UTF-8') . '</div>'
                        . ($comb !== '' ? '<div class="m">' . htmlspecialchars($comb, ENT_QUOTES, 'UTF-8') . '</div>' : '') . '
                    </td>
                    ' . ($showWeight ? '<td class="c weight">' . $weightTxt . '</td>' : '') . '
                    ' . ($showUnitVolume ? '<td class="c weight">' . $unitVolumeTxt . '</td>' : '') . '
                    ' . ($showUnitsPerCarton ? '<td class="c weight">' . htmlspecialchars($unitsPerCartonTxt, ENT_QUOTES, 'UTF-8') . '</td>' : '') . '
                    ' . ($showCartonDimensions ? '<td class="c weight">' . $cartonDimensionsTxt . '</td>' : '') . '
                    <td class="r price">' . $priceTxt . '</td>
                    ' . ($showBrutto ? '<td class="r price">' . $priceBruttoTxt . '</td>' : '') . '
                    <td class="c qty">' . $qty . '</td>
                    <td class="r val">' . $valueTxt . '</td>
                    ' . ($showBrutto ? '<td class="r val">' . $valueBruttoTxt . '</td>' : '') . '
                </tr>
            ';
        }

        $switchActiveUri = $this->switchSvgDataUri($activeOnly);
        $switchAvailableUri = $this->switchSvgDataUri($onlyAvailable);
        $switchMissingPurchaseUri = $this->switchSvgDataUri($missingPurchasePriceOnly);
        $switchWeightUri = $this->switchSvgDataUri($showWeight);
        $switchUnitVolumeUri = $this->switchSvgDataUri($showUnitVolume);
        $switchUnitsPerCartonUri = $this->switchSvgDataUri($showUnitsPerCarton);
        $switchCartonDimensionsUri = $this->switchSvgDataUri($showCartonDimensions);
        $switchMissingWeightUri = $this->switchSvgDataUri($missingWeightOnly);
        $switchBruttoUri = $this->switchSvgDataUri($showBrutto);
        $colspan = 6 + $visibleMetricColumns + ($showBrutto ? 2 : 0);

        $html = '
        <!DOCTYPE html>
        <html>
        <head>
        <meta charset="utf-8">
        <style>
            body { font-family: dejavusans, sans-serif; font-size: 9pt; color:#111; }
            h1 { font-size: 13pt; margin: 0 0 4pt 0; }
            .filters{ width: 100%; margin: 0 0 6pt 0; border-collapse: collapse; table-layout: fixed; }
            .filters td{ border: 0; padding: 0 4pt 2pt 0; vertical-align: middle; }
            .filters .filter-item{ width: 33.33%; }
            .filters .filter-icon-cell{ width: 28px; padding-right: 3pt; }
            .switch-img{ width: 22px; height: 11px; display:block; }
            .filter-label{ font-size: 7.2pt; color:#111; line-height: 1; margin: 0; }
            table { width: 100%; border-collapse: collapse; table-layout: fixed; }
            th { background:#f2f4f7; font-weight:600; font-size: 8.5pt; padding: 6pt; border: 1px solid #d9dee5; }
            td { padding: 6pt; border: 1px solid #e2e6ec; vertical-align: top; }
            .c { text-align:center; white-space:nowrap; }
            .r { text-align:right; white-space:nowrap; }
            .lp { width: 5%; }
            .img { width: 7%; }
            .ean { width: 20%; font-size: 8.6pt; }
            .name { width: 36%; }
            .weight { width: 8%; }
            .price { width: 10%; }
            .qty { width: 6%; }
            .val { width: 12%; }
            .n { font-size: 9.2pt; font-weight:600; word-wrap: break-word; }
            .m { font-size: 8.1pt; color:#666; margin-top: 2pt; word-wrap: break-word; }
            .thumb { width: 34px; height: 34px; object-fit: cover; border-radius: 7px; }
            tfoot td { font-weight:700; background:#fafbfc; }
        </style>
        </head>
        <body>
            <h1>' . htmlspecialchars($this->t('report_title'), ENT_QUOTES, 'UTF-8') . '</h1>
            <table class="filters">
                <tr>
                    <td class="filter-item">
                        <table>
                            <tr>
                                <td class="filter-icon-cell"><img class="switch-img" src="' . $switchActiveUri . '" alt="' . ($activeOnly ? 'ON' : 'OFF') . '"></td>
                                <td><div class="filter-label">' . htmlspecialchars($this->t('show_only_active_products'), ENT_QUOTES, 'UTF-8') . '</div></td>
                            </tr>
                        </table>
                    </td>
                    <td class="filter-item">
                        <table>
                            <tr>
                                <td class="filter-icon-cell"><img class="switch-img" src="' . $switchAvailableUri . '" alt="' . ($onlyAvailable ? 'ON' : 'OFF') . '"></td>
                                <td><div class="filter-label">' . htmlspecialchars($this->t('show_only_available_in_stock'), ENT_QUOTES, 'UTF-8') . '</div></td>
                            </tr>
                        </table>
                    </td>
                    <td class="filter-item">
                        <table>
                            <tr>
                                <td class="filter-icon-cell"><img class="switch-img" src="' . $switchMissingPurchaseUri . '" alt="' . ($missingPurchasePriceOnly ? 'ON' : 'OFF') . '"></td>
                                <td><div class="filter-label">' . htmlspecialchars($this->t('show_only_missing_purchase_price'), ENT_QUOTES, 'UTF-8') . '</div></td>
                            </tr>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td class="filter-item">
                        <table>
                            <tr>
                                <td class="filter-icon-cell"><img class="switch-img" src="' . $switchWeightUri . '" alt="' . ($showWeight ? 'ON' : 'OFF') . '"></td>
                                <td><div class="filter-label">' . htmlspecialchars($this->t('show_product_weight'), ENT_QUOTES, 'UTF-8') . '</div></td>
                            </tr>
                        </table>
                    </td>
                    <td class="filter-item">
                        <table>
                            <tr>
                                <td class="filter-icon-cell"><img class="switch-img" src="' . $switchUnitVolumeUri . '" alt="' . ($showUnitVolume ? 'ON' : 'OFF') . '"></td>
                                <td><div class="filter-label">' . htmlspecialchars($this->t('show_unit_volume'), ENT_QUOTES, 'UTF-8') . '</div></td>
                            </tr>
                        </table>
                    </td>
                    <td class="filter-item">
                        <table>
                            <tr>
                                <td class="filter-icon-cell"><img class="switch-img" src="' . $switchMissingWeightUri . '" alt="' . ($missingWeightOnly ? 'ON' : 'OFF') . '"></td>
                                <td><div class="filter-label">' . htmlspecialchars($this->t('show_only_missing_weight'), ENT_QUOTES, 'UTF-8') . '</div></td>
                            </tr>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td class="filter-item">
                        <table>
                            <tr>
                                <td class="filter-icon-cell"><img class="switch-img" src="' . $switchUnitsPerCartonUri . '" alt="' . ($showUnitsPerCarton ? 'ON' : 'OFF') . '"></td>
                                <td><div class="filter-label">' . htmlspecialchars($this->t('show_units_per_carton'), ENT_QUOTES, 'UTF-8') . '</div></td>
                            </tr>
                        </table>
                    </td>
                    <td class="filter-item">
                        <table>
                            <tr>
                                <td class="filter-icon-cell"><img class="switch-img" src="' . $switchCartonDimensionsUri . '" alt="' . ($showCartonDimensions ? 'ON' : 'OFF') . '"></td>
                                <td><div class="filter-label">' . htmlspecialchars($this->t('show_carton_dimensions'), ENT_QUOTES, 'UTF-8') . '</div></td>
                            </tr>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td class="filter-item">
                        <table>
                            <tr>
                                <td class="filter-icon-cell"><img class="switch-img" src="' . $switchBruttoUri . '" alt="' . ($showBrutto ? 'ON' : 'OFF') . '"></td>
                                <td><div class="filter-label">' . htmlspecialchars($this->t('show_retail_prices_gross'), ENT_QUOTES, 'UTF-8') . '</div></td>
                            </tr>
                        </table>
                    </td>
                    <td class="filter-item"></td>
                    <td class="filter-item"></td>
                </tr>
            </table>
            <table>
                <thead>
                    <tr>
                        <th class="c lp">' . htmlspecialchars($this->t('row_number'), ENT_QUOTES, 'UTF-8') . '</th>
                        <th class="c img">' . htmlspecialchars($this->t('image'), ENT_QUOTES, 'UTF-8') . '</th>
                        <th class="ean">' . htmlspecialchars($this->t('ean13'), ENT_QUOTES, 'UTF-8') . '</th>
                        <th class="name">' . htmlspecialchars($this->t('name'), ENT_QUOTES, 'UTF-8') . '</th>
                        ' . ($showWeight ? '<th class="c weight">' . htmlspecialchars($this->t('product_weight'), ENT_QUOTES, 'UTF-8') . '</th>' : '') . '
                        ' . ($showUnitVolume ? '<th class="c weight">' . htmlspecialchars($this->t('unit_volume'), ENT_QUOTES, 'UTF-8') . '</th>' : '') . '
                        ' . ($showUnitsPerCarton ? '<th class="c weight">' . htmlspecialchars($this->t('units_per_carton'), ENT_QUOTES, 'UTF-8') . '</th>' : '') . '
                        ' . ($showCartonDimensions ? '<th class="c weight">' . htmlspecialchars($this->t('carton_dimensions'), ENT_QUOTES, 'UTF-8') . '</th>' : '') . '
                        <th class="r price">' . htmlspecialchars($this->t('purchase_price_net'), ENT_QUOTES, 'UTF-8') . '</th>
                        ' . ($showBrutto ? '<th class="r price">' . htmlspecialchars($this->t('retail_price_gross'), ENT_QUOTES, 'UTF-8') . '</th>' : '') . '
                        <th class="c qty">' . htmlspecialchars($this->t('quantity'), ENT_QUOTES, 'UTF-8') . '</th>
                        <th class="r val">' . htmlspecialchars($this->t('purchase_value_net'), ENT_QUOTES, 'UTF-8') . '</th>
                        ' . ($showBrutto ? '<th class="r val">' . htmlspecialchars($this->t('retail_value_gross'), ENT_QUOTES, 'UTF-8') . '</th>' : '') . '
                    </tr>
                </thead>
                <tbody>
                    ' . ($rowsHtml !== '' ? $rowsHtml : '<tr><td colspan="' . $colspan . '" class="c">' . htmlspecialchars($this->t('no_results'), ENT_QUOTES, 'UTF-8') . '</td></tr>') . '
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="' . (6 + $visibleMetricColumns + ($showBrutto ? 1 : 0)) . '" class="r">' . htmlspecialchars($this->t('total_purchase_value_net'), ENT_QUOTES, 'UTF-8') . '</td>
                        <td class="r">' . $this->formatMoney($totalValueNetto) . '</td>
                        ' . ($showBrutto ? '<td></td>' : '') . '
                    </tr>
                    ' . ($showBrutto ? '
                    <tr>
                        <td colspan="' . (8 + $visibleMetricColumns) . '" class="r">' . htmlspecialchars($this->t('total_retail_value_gross'), ENT_QUOTES, 'UTF-8') . '</td>
                        <td class="r">' . $this->formatMoney($totalValueBrutto) . '</td>
                    </tr>
                    ' : '') . '
                </tfoot>
            </table>
        </body>
        </html>';

        $mpdf = new \Mpdf\Mpdf([
            'mode' => 'utf-8',
            'format' => 'A4',
            'margin_left' => 10,
            'margin_right' => 10,
            'margin_top' => 10,
            'margin_bottom' => 10,
            'default_font' => 'dejavusans',
            'backupSubsFont' => ['dejavusans'],
        ]);

        $mpdf->SetTitle($this->t('report_title'));
        $mpdf->WriteHTML($html);
        $mpdf->Output($this->t('pdf_filename', ['date' => date('Y-m-d_H-i')]) . '.pdf', \Mpdf\Output\Destination::DOWNLOAD);
        exit;
    }

    public function outputPurchaseOrderPdf(int $idPurchaseOrder): void
    {
        $this->loadPdfLibrary();
        $data = $this->getPurchaseOrder($idPurchaseOrder);
        $order = $data['order'];
        $supplier = $data['supplier'];
        $recipient = $data['recipient'];
        $items = $data['items'];
        $currency = htmlspecialchars($order['currency_code'], ENT_QUOTES, 'UTF-8');
        $reference = htmlspecialchars($order['reference'], ENT_QUOTES, 'UTF-8');

        $itemsValue = 0.0;
        $rowsHtml = '';
        $lp = 1;
        foreach ($items as $item) {
            $itemsValue += (float) ($item['line_value_raw'] ?? 0);
            $imgSrc = null;
            foreach (['image_thumb_url', 'image_url'] as $imgKey) {
                if (!empty($item[$imgKey])) {
                    $relPath = ltrim(str_replace(__PS_BASE_URI__, '/', (string) $item[$imgKey]), '/');
                    $absPath = rtrim(_PS_ROOT_DIR_, '/\\') . '/' . $relPath;
                    if (is_file($absPath)) {
                        $imgSrc = $absPath;
                        break;
                    }
                }
            }
            $imgTag = $imgSrc ? '<img class="thumb" src="' . htmlspecialchars($imgSrc, ENT_QUOTES, 'UTF-8') . '">' : '—';
            $name = htmlspecialchars((string) ($item['product_name'] ?? ''), ENT_QUOTES, 'UTF-8');
            $model = htmlspecialchars((string) ($item['model'] ?? ''), ENT_QUOTES, 'UTF-8');
            $ean = htmlspecialchars((string) ($item['ean13'] ?? ''), ENT_QUOTES, 'UTF-8');
            $qty = htmlspecialchars((string) ($item['quantity'] ?? '0'), ENT_QUOTES, 'UTF-8');
            $price = htmlspecialchars((string) ($item['purchase_price_formatted'] ?? '—'), ENT_QUOTES, 'UTF-8');
            $value = htmlspecialchars((string) ($item['value_formatted'] ?? '—'), ENT_QUOTES, 'UTF-8');
            $rowsHtml .= '<tr>'
                . '<td class="c lp">' . $lp++ . '</td>'
                . '<td class="c img">' . $imgTag . '</td>'
                . '<td class="name"><div class="n">' . $name . '</div>' . ($model !== '' ? '<div class="m">' . $model . '</div>' : '') . '</td>'
                . '<td class="ean">' . $ean . '</td>'
                . '<td class="c qty">' . $qty . '</td>'
                . '<td class="r price">' . $price . '</td>'
                . '<td class="r val">' . $value . '</td>'
                . '</tr>';
        }

        $totalFormatted = htmlspecialchars($this->formatMoneyByCurrency($itemsValue, $order['currency_code']), ENT_QUOTES, 'UTF-8');
        $supplierName = htmlspecialchars(trim((string) ($supplier['name'] ?? '')), ENT_QUOTES, 'UTF-8');
        $supplierAddr = htmlspecialchars(trim((string) ($supplier['address'] ?? '')), ENT_QUOTES, 'UTF-8');
        $supplierPhone = htmlspecialchars(trim((string) ($supplier['phone'] ?? '')), ENT_QUOTES, 'UTF-8');
        $recipientAddr = htmlspecialchars(trim((string) ($recipient['address'] ?? '')), ENT_QUOTES, 'UTF-8');

        $metaRows = '';
        $metaFields = [
            'Data zamówienia'   => $order['ordered_at_label'],
            'Przewoźnik'        => $order['carrier_name'],
            'Warunki dostawy'   => $order['incoterm_code'],
            'Nr faktury'        => $order['invoice_number'],
            'Koszt transportu'  => $order['transport_cost_label'],
        ];
        foreach ($metaFields as $label => $value) {
            if ((string) $value === '' || $value === '---') {
                continue;
            }
            $metaRows .= '<tr><td class="mlabel">' . htmlspecialchars($label, ENT_QUOTES, 'UTF-8') . '</td><td class="mval">' . htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8') . '</td></tr>';
        }

        $html = '<!DOCTYPE html><html><head><meta charset="utf-8"><style>
            body{font-family:dejavusans,sans-serif;font-size:8pt;color:#111;line-height:1.45;}
            h1{font-size:14pt;margin:0 0 10pt 0;font-weight:700;}
            .sections{width:100%;border-collapse:collapse;margin-bottom:0;table-layout:fixed;}
            .sections > tbody > tr > td{vertical-align:top;padding:0 6pt 0 0;width:33.33%;}
            .sections > tbody > tr > td:last-child{padding-right:0;}
            .sec-title{font-size:7.5pt;font-weight:700;text-transform:uppercase;color:#fff;background:#2c2c2c;letter-spacing:0.06em;padding:4pt 8pt;margin-bottom:6pt;}
            .sec-body{font-size:8pt;color:#111;line-height:1.5;padding:0 4pt;}
            .meta{border-collapse:collapse;width:100%;}
            .meta td{padding:1.5pt 8pt 1.5pt 0;font-size:8pt;vertical-align:top;}
            .mlabel{color:#111;white-space:nowrap;width:42%;}
            .mval{font-weight:600;color:#111;}
            .divider{border:0;border-top:1px solid #ddd;margin:10pt 0;}
            table.items{width:100%;border-collapse:collapse;table-layout:fixed;}
            table.items th{background:#f2f4f7;font-weight:700;font-size:8pt;padding:4pt 5pt;border:1px solid #d0d5de;text-align:left;}
            table.items td{padding:4pt 5pt;border:1px solid #e2e6ec;vertical-align:top;font-size:8pt;}
            .c{text-align:center;white-space:nowrap;}
            .r{text-align:right;white-space:nowrap;}
            .lp{width:5%;}
            .img{width:7%;}
            .name{width:35%;}
            .ean{width:18%;}
            .qty{width:8%;}
            .price{width:14%;}
            .val{width:13%;}
            .n{font-size:8pt;font-weight:600;word-wrap:break-word;}
            .m{font-size:7pt;color:#666;margin-top:1pt;word-wrap:break-word;}
            .thumb{width:28px;height:28px;object-fit:cover;border-radius:3px;}
            tfoot td{font-weight:700;background:#f2f4f7;font-size:8pt;}
        </style></head><body>
        <h1>Zamówienie ' . $reference . '</h1>
        <table class="sections">
            <tr>
                <td><div class="sec-title">Sprzedawca</div><div class="sec-body">'
                    . $supplierName
                    . ($supplierAddr !== '' ? '<br>' . nl2br($supplierAddr) : '')
                    . ($supplierPhone !== '' ? '<br>' . $supplierPhone : '')
                . '</div></td>
                <td><div class="sec-title">Nabywca</div><div class="sec-body">' . ($recipientAddr !== '' ? nl2br($recipientAddr) : '—') . '</div></td>
                <td><div class="sec-title">Szczegóły</div>
                    <table class="meta"><tbody>' . $metaRows . '</tbody></table>
                </td>
            </tr>
        </table>
        <div class="divider"></div>
        <table class="items">
            <thead><tr>
                <th class="c lp">Lp</th>
                <th class="c img">Zdjęcie</th>
                <th class="name">Nazwa</th>
                <th class="ean">EAN</th>
                <th class="c qty">Ilość</th>
                <th class="r price">Cena jedn.</th>
                <th class="r val">Wartość</th>
            </tr></thead>
            <tbody>' . ($rowsHtml !== '' ? $rowsHtml : '<tr><td colspan="7" class="c">Brak produktów</td></tr>') . '</tbody>
            <tfoot><tr>
                <td colspan="6" class="r">Razem</td>
                <td class="r">' . $totalFormatted . '</td>
            </tr></tfoot>
        </table>
        </body></html>';

        $filename = 'zamowienie_' . preg_replace('/[^a-zA-Z0-9_\-]/', '_', $order['reference']) . '_' . date('Y-m-d') . '.pdf';

        $mpdf = new \Mpdf\Mpdf([
            'mode'          => 'utf-8',
            'format'        => 'A4',
            'margin_left'   => 12,
            'margin_right'  => 12,
            'margin_top'    => 14,
            'margin_bottom' => 12,
            'default_font'  => 'dejavusans',
            'backupSubsFont' => ['dejavusans'],
        ]);
        $mpdf->SetTitle('Zamówienie ' . $order['reference']);
        $mpdf->WriteHTML($html);
        $mpdf->Output($filename, \Mpdf\Output\Destination::DOWNLOAD);
        exit;
    }

    private function fetchProducts(array $filters): array
    {
        [$baseSql, $params] = $this->buildProductBaseSql($filters);
        $sortField = (string) ($filters['sort_field'] ?? 'product_name');
        $sortDir = strtoupper((string) ($filters['sort_dir'] ?? 'ASC')) === 'DESC' ? 'DESC' : 'ASC';
        $sortSql = self::SORT_FIELD_MAP[$sortField] ?? self::SORT_FIELD_MAP['product_name'];
        $sql = 'SELECT * FROM (' . $baseSql . ') inventory_rows ORDER BY ' . $sortSql . ' ' . $sortDir . ', id_product ASC';

        $stmt = $this->getPdo()->prepare($sql);
        foreach ($params as $key => $value) {
            $stmt->bindValue($key, $value, is_int($value) ? PDO::PARAM_INT : PDO::PARAM_STR);
        }
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    private function fetchProductsPage(array $filters, int $page, int $perPage): array
    {
        [$baseSql, $params] = $this->buildProductBaseSql($filters);
        $countSql = '
            SELECT
                COUNT(*) AS total_rows,
                COALESCE(SUM(CASE WHEN product_cost > 0 THEN product_cost * stock_quantity ELSE 0 END), 0) AS total_value_netto,
                COALESCE(SUM(CASE WHEN product_price_brutto > 0 THEN product_price_brutto * stock_quantity ELSE 0 END), 0) AS total_value_brutto
            FROM (' . $baseSql . ') inventory_rows
        ';

        $countStmt = $this->getPdo()->prepare($countSql);
        foreach ($params as $key => $value) {
            $countStmt->bindValue($key, $value, is_int($value) ? PDO::PARAM_INT : PDO::PARAM_STR);
        }
        $countStmt->execute();
        $summary = $countStmt->fetch(PDO::FETCH_ASSOC) ?: [];

        $totalRows = (int) ($summary['total_rows'] ?? 0);
        $totalPages = max(1, (int) ceil($totalRows / $perPage));
        $currentPage = min($page, $totalPages);
        $offset = ($currentPage - 1) * $perPage;

        $sortField = (string) ($filters['sort_field'] ?? 'product_name');
        $sortDir = strtoupper((string) ($filters['sort_dir'] ?? 'ASC')) === 'DESC' ? 'DESC' : 'ASC';
        $sortSql = self::SORT_FIELD_MAP[$sortField] ?? self::SORT_FIELD_MAP['product_name'];
        $rowsSql = '
            SELECT * FROM (' . $baseSql . ') inventory_rows
            ORDER BY ' . $sortSql . ' ' . $sortDir . ', id_product ASC
            LIMIT :limit OFFSET :offset
        ';

        $rowsStmt = $this->getPdo()->prepare($rowsSql);
        foreach ($params as $key => $value) {
            $rowsStmt->bindValue($key, $value, is_int($value) ? PDO::PARAM_INT : PDO::PARAM_STR);
        }
        $rowsStmt->bindValue(':limit', $perPage, PDO::PARAM_INT);
        $rowsStmt->bindValue(':offset', $offset, PDO::PARAM_INT);
        $rowsStmt->execute();

        $from = $totalRows > 0 ? ($offset + 1) : 0;
        $to = min($offset + $perPage, $totalRows);

        return [
            'items' => $rowsStmt->fetchAll(PDO::FETCH_ASSOC),
            'current_page' => $currentPage,
            'per_page' => $perPage,
            'total_pages' => $totalPages,
            'total_rows' => $totalRows,
            'from' => $from,
            'to' => $to,
            'total_value_netto' => (float) ($summary['total_value_netto'] ?? 0),
            'total_value_brutto' => (float) ($summary['total_value_brutto'] ?? 0),
        ];
    }

    private function buildProductBaseSql(array $filters): array
    {
        $query = (string) ($filters['query'] ?? '');
        $lang = $this->resolveLanguage((string) ($filters['lang'] ?? 'pl'));
        $idLang = (int) $lang['id_lang'];
        $idCountry = (int) Configuration::get('PS_COUNTRY_DEFAULT');
        $idShop = (int) $this->context->shop->id;
        $idShopGroup = (int) $this->context->shop->id_shop_group;
        $activeOnly = $this->toBool($filters['activeOnly'] ?? false);
        $onlyAvailable = $this->toBool($filters['onlyAvailable'] ?? false);
        $missingPurchasePriceOnly = $this->toBool($filters['missingPurchasePriceOnly'] ?? false);
        $missingWeightOnly = $this->toBool($filters['missingWeightOnly'] ?? false);
        $keywords = $this->parseKeywords($query, $filters['keywords'] ?? null);
        $prefix = _DB_PREFIX_;

        $sql = "
            SELECT
                p.id_product,
                IFNULL(pa.id_product_attribute, 0) AS id_product_attribute,
                IFNULL(ps.active, p.active) AS active,
                p.ean13 AS product_ean13,
                pa.ean13 AS combination_ean13,
                pl.name AS product_name,
                (IFNULL(p.weight, 0) + IFNULL(pa.weight, 0)) AS product_weight,
                IFNULL(p.width, 0) AS product_width,
                IFNULL(p.height, 0) AS product_height,
                IFNULL(p.depth, 0) AS product_depth,
                IFNULL(pa.wholesale_price, p.wholesale_price) AS product_cost,
                (IFNULL(ps.price, 0) + IFNULL(pa.price, 0)) AS product_price_netto,
                (IFNULL(ps.price, 0) + IFNULL(pa.price, 0)) * (1 + IFNULL(t.rate, 0) / 100) AS product_price_brutto,
                IFNULL(t.rate, 0) AS tax_rate,
                IFNULL(sa.quantity, 0) AS stock_quantity,
                IFNULL(psl.unit_volume, 0) AS unit_volume,
                IFNULL(psl.units_per_carton, 0) AS units_per_carton,
                IFNULL(psl.carton_length, 0) AS carton_length,
                IFNULL(psl.carton_width, 0) AS carton_width,
                IFNULL(psl.carton_height, 0) AS carton_height,
                IFNULL(psl.carton_gross_weight, 0) AS carton_gross_weight,
                MIN(pai.id_image) AS combination_image_id,
                i.id_image AS product_image_id,
                GROUP_CONCAT(DISTINCT CONCAT(agl.name, ': ', al.name) SEPARATOR ', ') AS combination_name
            FROM `{$prefix}product` p
            LEFT JOIN `{$prefix}product_shop` ps
                ON p.id_product = ps.id_product AND ps.id_shop = :id_shop
            LEFT JOIN `{$prefix}product_lang` pl
                ON p.id_product = pl.id_product AND pl.id_lang = :id_lang AND pl.id_shop = ps.id_shop
            LEFT JOIN `{$prefix}tax_rule` tr
                ON ps.id_tax_rules_group = tr.id_tax_rules_group
                AND tr.id_country = :id_country
                AND (tr.id_state = 0 OR tr.id_state IS NULL)
            LEFT JOIN `{$prefix}tax` t
                ON tr.id_tax = t.id_tax
            LEFT JOIN `{$prefix}product_attribute` pa
                ON p.id_product = pa.id_product
            LEFT JOIN (
                SELECT
                    sa0.id_product,
                    sa0.id_product_attribute,
                    COALESCE(
                        MAX(CASE WHEN sa0.id_shop = :id_shop THEN sa0.quantity END),
                        MAX(CASE WHEN sa0.id_shop = 0 AND sa0.id_shop_group = :id_shop_group THEN sa0.quantity END),
                        MAX(CASE WHEN sa0.id_shop = 0 AND sa0.id_shop_group = 0 THEN sa0.quantity END)
                    ) AS quantity
                FROM `{$prefix}stock_available` sa0
                GROUP BY sa0.id_product, sa0.id_product_attribute
            ) sa
                ON p.id_product = sa.id_product
                AND sa.id_product_attribute = IFNULL(pa.id_product_attribute, 0)
            LEFT JOIN `{$prefix}product_attribute_image` pai
                ON pa.id_product_attribute = pai.id_product_attribute
            LEFT JOIN `{$prefix}image` i
                ON p.id_product = i.id_product AND i.cover = 1
            LEFT JOIN `{$prefix}product_attribute_combination` pac
                ON pa.id_product_attribute = pac.id_product_attribute
            LEFT JOIN `{$prefix}attribute` a
                ON pac.id_attribute = a.id_attribute
            LEFT JOIN `{$prefix}attribute_lang` al
                ON a.id_attribute = al.id_attribute AND al.id_lang = :id_lang
            LEFT JOIN `{$prefix}attribute_group_lang` agl
                ON a.id_attribute_group = agl.id_attribute_group AND agl.id_lang = :id_lang
            LEFT JOIN `{$prefix}prestashopinventory_product_logistics` psl
                ON p.id_product = psl.id_product
               AND psl.id_product_attribute = IFNULL(pa.id_product_attribute, 0)
            WHERE 1 = 1
        ";

        $params = [
            ':id_shop' => $idShop,
            ':id_shop_group' => $idShopGroup,
            ':id_lang' => $idLang,
            ':id_country' => $idCountry,
        ];

        $ignoredIds = $this->getIgnoredIds();
        if ($ignoredIds !== []) {
            $placeholders = [];
            foreach ($ignoredIds as $index => $id) {
                $placeholder = ':ign' . $index;
                $placeholders[] = $placeholder;
                $params[$placeholder] = (int) $id;
            }
            $sql .= ' AND p.id_product NOT IN (' . implode(',', $placeholders) . ')';
        }

        if ($activeOnly) {
            $sql .= ' AND IFNULL(ps.active, p.active) = 1';
        }

        if ($onlyAvailable) {
            $sql .= ' AND sa.quantity > 0';
        }

        if ($missingPurchasePriceOnly) {
            $sql .= ' AND IFNULL(pa.wholesale_price, p.wholesale_price) <= 0';
        }

        if ($missingWeightOnly) {
            $sql .= ' AND (IFNULL(p.weight, 0) + IFNULL(pa.weight, 0)) <= 0';
        }

        if ($keywords !== []) {
            $andParts = [];
            foreach ($keywords as $index => $keyword) {
                $placeholder = ':kw' . $index;
                $andParts[] = "(pl.name LIKE {$placeholder} OR p.ean13 LIKE {$placeholder} OR pa.ean13 LIKE {$placeholder})";
                $params[$placeholder] = '%' . $keyword . '%';
            }
            $sql .= ' AND (' . implode(' AND ', $andParts) . ')';
        }

        $sql .= ' GROUP BY p.id_product, pa.id_product_attribute';

        return [$sql, $params];
    }

    private function renderPagination(array $result): string
    {
        $currentPage = (int) $result['current_page'];
        $totalPages = (int) $result['total_pages'];
        $totalRows = (int) $result['total_rows'];
        $from = (int) $result['from'];
        $to = (int) $result['to'];
        $perPage = (int) $result['per_page'];
        $options = [20, 50, 100, 200];

        $html = '<div class="inventory-pagination-inner">';
        $html .= '<div class="inventory-pagination-pages">';
        $html .= '<ul class="pagination mb-0">';
        if ($totalPages > 1) {
            $html .= '<li class="page-item first' . ($currentPage === 1 ? ' disabled' : '') . '">';
            $html .= '<button type="button" class="page-link first inventory-page-edge" data-page="1"' . ($currentPage === 1 ? ' disabled' : '') . '>1</button>';
            $html .= '</li>';
            $html .= '<li class="page-item previous' . ($currentPage === 1 ? ' disabled' : '') . '">';
            $html .= '<button type="button" class="page-link previous inventory-page-nav" data-page="' . max(1, $currentPage - 1) . '"' . ($currentPage === 1 ? ' disabled' : '') . ' aria-label="' . htmlspecialchars($this->t('previous'), ENT_QUOTES, 'UTF-8') . '"><span aria-hidden="true">&#8249;</span><span class="sr-only">' . htmlspecialchars($this->t('previous'), ENT_QUOTES, 'UTF-8') . '</span></button>';
            $html .= '</li>';
            $html .= '<li class="page-item current active"><label><input type="text" inputmode="numeric" pattern="[0-9]*" name="paginator-jump-page" class="jump-to-page inventory-page-current" min="1" max="' . $totalPages . '" value="' . $currentPage . '" aria-label="' . htmlspecialchars($this->t('current_page'), ENT_QUOTES, 'UTF-8') . '"></label></li>';
            $html .= '<li class="page-item next' . ($currentPage >= $totalPages ? ' disabled' : '') . '">';
            $html .= '<button type="button" class="page-link next inventory-page-nav" data-page="' . min($totalPages, $currentPage + 1) . '"' . ($currentPage >= $totalPages ? ' disabled' : '') . ' aria-label="' . htmlspecialchars($this->t('next'), ENT_QUOTES, 'UTF-8') . '"><span aria-hidden="true">&#8250;</span><span class="sr-only">' . htmlspecialchars($this->t('next'), ENT_QUOTES, 'UTF-8') . '</span></button>';
            $html .= '</li>';
            $html .= '<li class="page-item last' . ($currentPage === $totalPages ? ' disabled' : '') . '">';
            $html .= '<button type="button" class="page-link last inventory-page-edge" data-page="' . $totalPages . '"' . ($currentPage === $totalPages ? ' disabled' : '') . '>' . $totalPages . '</button>';
            $html .= '</li>';
        } else {
            $html .= '<li class="page-item current active"><label><input type="text" inputmode="numeric" pattern="[0-9]*" name="paginator-jump-page" class="jump-to-page inventory-page-current" min="1" max="1" value="1" aria-label="' . htmlspecialchars($this->t('current_page'), ENT_QUOTES, 'UTF-8') . '"></label></li>';
        }
        $html .= '</ul>';
        $html .= '</div>';
        $html .= '<div class="inventory-pagination-status">' . htmlspecialchars($this->t('visible_range', ['from' => $from, 'to' => $to, 'total' => $totalRows, 'page' => $currentPage, 'total_pages' => $totalPages]), ENT_QUOTES, 'UTF-8') . '</div>';
        $html .= '<label class="inventory-per-page"><span class="inventory-per-page-label">' . htmlspecialchars($this->t('products_per_page'), ENT_QUOTES, 'UTF-8') . '</span> <select class="inventory-per-page-select">';
        foreach ($options as $option) {
            $selected = $option === $perPage ? ' selected' : '';
            $html .= '<option value="' . $option . '"' . $selected . '>' . $option . '</option>';
        }
        $html .= '</select></label>';
        $html .= '</div>';

        return $html;
    }

    private function normalizePage($value): int
    {
        $page = (int) $value;

        return $page > 0 ? $page : 1;
    }

    private function normalizePerPage($value): int
    {
        $perPage = (int) $value;
        $allowed = [20, 50, 100, 200];

        return in_array($perPage, $allowed, true) ? $perPage : 20;
    }

    private function getPdo(): PDO
    {
        if ($this->pdo instanceof PDO) {
            return $this->pdo;
        }

        $this->pdo = new PDO(
            'mysql:host=' . _DB_SERVER_ . ';dbname=' . _DB_NAME_ . ';charset=utf8mb4',
            _DB_USER_,
            _DB_PASSWD_,
            [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            ]
        );

        return $this->pdo;
    }

    private function resolveLanguage(string $isoCode): array
    {
        $idLang = (int) Language::getIdByIso($isoCode);
        if ($idLang <= 0) {
            $idLang = (int) $this->context->language->id;
        }

        return [
            'id_lang' => $idLang,
        ];
    }

    public function getIgnoredIds(): array
    {
        $configured = (string) Configuration::get(self::CONFIG_IGNORED_IDS);
        if (trim($configured) !== '') {
            return self::parseIgnoredIdsText($configured);
        }

        $filePath = $this->modulePath . 'ignore.txt';
        if (!is_file($filePath)) {
            return [];
        }

        return self::parseIgnoredIdsText((string) file_get_contents($filePath));
    }

    public function getTranslations(): array
    {
        return PrestashopInventoryI18n::all($this->module);
    }

    private function t(string $key, array $params = []): string
    {
        return PrestashopInventoryI18n::translate($this->module, $key, $params);
    }

    private function formatMoney(float $amount): string
    {
        $currencySign = 'zł';
        if (isset($this->context->currency) && isset($this->context->currency->sign) && $this->context->currency->sign) {
            $currencySign = (string) $this->context->currency->sign;
        }

        return number_format($amount, 2, ',', ' ') . ' ' . $currencySign;
    }

    private function formatMoneyByCurrency(float $amount, string $currencyCode): string
    {
        $currencyCode = strtoupper(trim($currencyCode));
        if ($currencyCode === '') {
            return $this->formatMoney($amount);
        }

        return number_format($amount, 2, ',', ' ') . ' ' . $currencyCode;
    }

    private function formatWeight(float $weight): string
    {
        if ($weight <= 0) {
            return '—';
        }

        return number_format($weight, 3, ',', ' ') . ' kg';
    }

    private function formatVolume(float $volume): string
    {
        if ($volume <= 0) {
            return '—';
        }

        return number_format($volume, 3, ',', ' ') . ' m3';
    }

    private function formatCartonDimensions(float $length, float $width, float $height): string
    {
        if ($length <= 0 || $width <= 0 || $height <= 0) {
            return '—';
        }

        return implode(' x ', [
            $this->trimFormattedNumber($length, 3),
            $this->trimFormattedNumber($width, 3),
            $this->trimFormattedNumber($height, 3),
        ]) . ' cm';
    }

    private function formatCartonDimensionsInput(float $length, float $width, float $height): string
    {
        if ($length <= 0 || $width <= 0 || $height <= 0) {
            return '';
        }

        return implode('x', [
            $this->trimFormattedNumber($length, 3, '.'),
            $this->trimFormattedNumber($width, 3, '.'),
            $this->trimFormattedNumber($height, 3, '.'),
        ]);
    }

    private function calculateVolumeFromDimensions(float $width, float $height, float $depth): float
    {
        if ($width <= 0 || $height <= 0 || $depth <= 0) {
            return 0.0;
        }

        return ($width * $height * $depth) / 1000000;
    }

    private function parseCartonDimensions(string $dimensionsRaw): array
    {
        $normalized = trim(mb_strtolower($dimensionsRaw));
        $normalized = str_replace(['×', '*', ';'], ['x', 'x', 'x'], $normalized);
        $normalized = preg_replace('/\s*x\s*/u', 'x', $normalized);
        $normalized = str_replace([',', ' '], ['.', ''], $normalized);

        $parts = explode('x', $normalized);
        if (count($parts) !== 3) {
            throw new InvalidArgumentException($this->t('invalid_carton_dimensions'));
        }

        $values = array_map('trim', $parts);
        foreach ($values as $value) {
            if ($value === '' || !is_numeric($value) || (float) $value <= 0) {
                throw new InvalidArgumentException($this->t('invalid_carton_dimensions'));
            }
        }

        return [
            'length' => round((float) $values[0], 3),
            'width' => round((float) $values[1], 3),
            'height' => round((float) $values[2], 3),
        ];
    }

    private function trimFormattedNumber(float $value, int $precision = 3, string $decimalSeparator = ','): string
    {
        $formatted = number_format($value, $precision, '.', '');
        $formatted = rtrim(rtrim($formatted, '0'), '.');

        return str_replace('.', $decimalSeparator, $formatted);
    }

    private function resolveProductUnitVolume(array $product): float
    {
        $unitVolume = (float) ($product['unit_volume'] ?? 0);
        if ($unitVolume > 0) {
            return $unitVolume;
        }

        $unitsPerCarton = (int) ($product['units_per_carton'] ?? 0);
        $cartonVolume = $this->calculateVolumeFromDimensions(
            (float) ($product['carton_length'] ?? 0),
            (float) ($product['carton_width'] ?? 0),
            (float) ($product['carton_height'] ?? 0)
        );
        if ($cartonVolume > 0 && $unitsPerCarton > 0) {
            return $cartonVolume / $unitsPerCarton;
        }

        return $this->calculateVolumeFromDimensions(
            (float) ($product['product_width'] ?? 0),
            (float) ($product['product_height'] ?? 0),
            (float) ($product['product_depth'] ?? 0)
        );
    }

    public static function parseIgnoredIdsText(string $raw): array
    {
        $items = preg_split('/[\s,;]+/u', trim($raw), -1, PREG_SPLIT_NO_EMPTY);
        $items = array_map('intval', $items ?: []);
        $items = array_values(array_unique(array_filter($items, static function ($id) {
            return $id > 0;
        })));

        return $items;
    }

    private function parseKeywords(string $query, $keywords): array
    {
        if (!is_array($keywords) || $keywords === []) {
            $keywords = preg_split('/[,\s]+/u', trim($query), -1, PREG_SPLIT_NO_EMPTY);
        }

        return array_values(array_filter(array_map('trim', (array) $keywords)));
    }

    private function toBool($value, bool $default = false): bool
    {
        if ($value === null || $value === '') {
            return $default;
        }

        return $value === true
            || $value === 1
            || $value === '1'
            || $value === 'true'
            || $value === 'on';
    }

    private function getImagePath(int $idImage): string
    {
        return __PS_BASE_URI__ . 'img/p/' . implode('/', str_split((string) $idImage)) . '/' . $idImage . '.jpg';
    }

    private function getImageThumbPath(int $idImage, string $type = 'small_default'): string
    {
        return __PS_BASE_URI__ . 'img/p/' . implode('/', str_split((string) $idImage)) . '/' . $idImage . '-' . $type . '.jpg';
    }

    private function getProductEditUrl(int $idProduct): string
    {
        $legacyUrl = $this->context->link->getAdminLink('AdminProducts', true, [], [
            'id_product' => $idProduct,
            'updateproduct' => 1,
        ]);

        $symfonyUrl = $this->context->link->getAdminLink('AdminProducts', true, [
            'route' => 'admin_product_form',
            'id' => $idProduct,
        ]);

        if (!is_string($symfonyUrl) || $symfonyUrl === '') {
            return $legacyUrl;
        }

        if (strpos($symfonyUrl, 'route=admin_product_form') !== false || preg_match('#/sell/catalog/products/' . $idProduct . '(?:/edit)?(?:[/?]|$)#', $symfonyUrl)) {
            return $symfonyUrl;
        }

        return $legacyUrl;
    }

    private function getSupplierEditUrl(int $idSupplier): string
    {
        return $this->context->link->getAdminLink('AdminSuppliers', true, [], [
            'id_supplier' => $idSupplier,
            'updatesupplier' => 1,
        ]);
    }

    private function getSupplierModuleEditUrl(int $idSupplier): string
    {
        return $this->context->link->getAdminLink('AdminPrestashopInventorySuppliers', true, [], [
            'editSupplier' => 1,
            'id_supplier' => $idSupplier,
        ]);
    }

    private function getSupplierAddressData(int $idSupplier): array
    {
        $sql = '
            SELECT id_address, phone, address1, address2, postcode, city, id_country
            FROM `' . _DB_PREFIX_ . 'address`
            WHERE id_supplier = :id_supplier
              AND deleted = 0
            ORDER BY id_address ASC
            LIMIT 1
        ';

        $stmt = $this->getPdo()->prepare($sql);
        $stmt->execute([
            ':id_supplier' => $idSupplier,
        ]);

        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!is_array($row)) {
            return [
                'id_address' => 0,
                'phone' => '',
                'address1' => '',
                'address2' => '',
                'postcode' => '',
                'city' => '',
                'id_country' => (int) Configuration::get('PS_COUNTRY_DEFAULT'),
            ];
        }

        return [
            'id_address' => (int) ($row['id_address'] ?? 0),
            'phone' => (string) ($row['phone'] ?? ''),
            'address1' => (string) ($row['address1'] ?? ''),
            'address2' => (string) ($row['address2'] ?? ''),
            'postcode' => (string) ($row['postcode'] ?? ''),
            'city' => (string) ($row['city'] ?? ''),
            'id_country' => (int) ($row['id_country'] ?? 0),
        ];
    }

    private function saveSupplierAddress(int $idSupplier, array $data): void
    {
        $addressData = $this->getSupplierAddressData($idSupplier);
        $address = (int) ($addressData['id_address'] ?? 0) > 0 ? new Address((int) $addressData['id_address']) : new Address();

        $address->id_supplier = $idSupplier;
        $address->id_customer = 0;
        $address->id_manufacturer = 0;
        $address->alias = Tools::substr((string) ($data['company'] ?? 'Supplier'), 0, 32);
        $address->lastname = 'Supplier';
        $address->firstname = 'Supplier';
        $address->company = (string) ($data['company'] ?? '');
        $address->phone = (string) ($data['phone'] ?? '');
        $address->address1 = (string) ($data['address1'] ?? '');
        $address->address2 = (string) ($data['address2'] ?? '');
        $address->postcode = (string) ($data['postcode'] ?? '');
        $address->city = (string) ($data['city'] ?? '');
        $address->id_country = (int) ($data['id_country'] ?? 0);
        $address->deleted = 0;

        $saved = Validate::isLoadedObject($address) ? $address->update() : $address->add();
        if (!$saved) {
            throw new RuntimeException($this->t('supplier_save_error'));
        }
    }

    private function createPurchaseOrderTables(): void
    {
        $engine = defined('_MYSQL_ENGINE_') ? _MYSQL_ENGINE_ : 'InnoDB';

        $this->getPdo()->exec('
            CREATE TABLE IF NOT EXISTS `' . $this->purchaseOrderTable('carrier') . '` (
                `id_psinv_carrier` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                `name` VARCHAR(191) NOT NULL DEFAULT "",
                `date_add` DATETIME NOT NULL,
                PRIMARY KEY (`id_psinv_carrier`)
            ) ENGINE=' . $engine . ' DEFAULT CHARSET=utf8mb4
        ');

        $this->getPdo()->exec('
            CREATE TABLE IF NOT EXISTS `' . $this->purchaseOrderTable('document_type') . '` (
                `id_psinv_document_type` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                `name` VARCHAR(191) NOT NULL DEFAULT "",
                `date_add` DATETIME NOT NULL,
                PRIMARY KEY (`id_psinv_document_type`)
            ) ENGINE=' . $engine . ' DEFAULT CHARSET=utf8mb4
        ');

        $this->getPdo()->exec('
            CREATE TABLE IF NOT EXISTS `' . $this->purchaseOrderTable('purchase_order') . '` (
                `id_purchase_order` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                `reference` VARCHAR(64) NOT NULL,
                `id_supplier` INT UNSIGNED NULL DEFAULT NULL,
                `supplier_name` VARCHAR(255) NOT NULL DEFAULT "",
                `delivery_address` TEXT NULL,
                `ordered_at` DATETIME NULL DEFAULT NULL,
                `delivery_at` DATETIME NULL DEFAULT NULL,
                `shipment_number` VARCHAR(128) NOT NULL DEFAULT "",
                `invoice_number` VARCHAR(128) NOT NULL DEFAULT "",
                `currency_code` VARCHAR(8) NOT NULL DEFAULT "PLN",
                `currency_rate` DECIMAL(20,6) NOT NULL DEFAULT 1.000000,
                `status_key` VARCHAR(32) NOT NULL DEFAULT "draft",
                `incoterm_code` VARCHAR(16) NOT NULL DEFAULT "FOB",
                `transport_cost` DECIMAL(20,6) NOT NULL DEFAULT 0.000000,
                `carrier_name` VARCHAR(191) NOT NULL DEFAULT "",
                `date_add` DATETIME NOT NULL,
                `date_upd` DATETIME NOT NULL,
                PRIMARY KEY (`id_purchase_order`),
                KEY `psinv_purchase_order_supplier` (`id_supplier`)
            ) ENGINE=' . $engine . ' DEFAULT CHARSET=utf8mb4
        ');

        $this->getPdo()->exec('
            CREATE TABLE IF NOT EXISTS `' . $this->purchaseOrderTable('purchase_order_item') . '` (
                `id_purchase_order_item` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                `id_purchase_order` INT UNSIGNED NOT NULL,
                `position` INT UNSIGNED NOT NULL DEFAULT 0,
                `id_product` INT UNSIGNED NULL DEFAULT NULL,
                `id_product_attribute` INT UNSIGNED NOT NULL DEFAULT 0,
                `model` VARCHAR(128) NOT NULL DEFAULT "",
                `product_name` VARCHAR(255) NOT NULL DEFAULT "",
                `ean13` VARCHAR(32) NOT NULL DEFAULT "",
                `quantity` DECIMAL(20,3) NOT NULL DEFAULT 0.000,
                `purchase_price` DECIMAL(20,6) NOT NULL DEFAULT 0.000000,
                `weight` DECIMAL(20,6) NOT NULL DEFAULT 0.000000,
                `image_id` INT UNSIGNED NOT NULL DEFAULT 0,
                `date_add` DATETIME NOT NULL,
                `date_upd` DATETIME NOT NULL,
                PRIMARY KEY (`id_purchase_order_item`),
                KEY `psinv_purchase_order_item_order` (`id_purchase_order`)
            ) ENGINE=' . $engine . ' DEFAULT CHARSET=utf8mb4
        ');

        $this->getPdo()->exec('
            CREATE TABLE IF NOT EXISTS `' . $this->purchaseOrderTable('purchase_order_file') . '` (
                `id_purchase_order_file` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                `id_purchase_order` INT UNSIGNED NOT NULL,
                `original_name` VARCHAR(255) NOT NULL,
                `stored_name` VARCHAR(255) NOT NULL,
                `file_path` VARCHAR(255) NOT NULL,
                `mime_type` VARCHAR(191) NOT NULL DEFAULT "",
                `size_bytes` INT UNSIGNED NOT NULL DEFAULT 0,
                `description` VARCHAR(255) NOT NULL DEFAULT "",
                `date_add` DATETIME NOT NULL,
                PRIMARY KEY (`id_purchase_order_file`),
                KEY `psinv_purchase_order_file_order` (`id_purchase_order`)
            ) ENGINE=' . $engine . ' DEFAULT CHARSET=utf8mb4
        ');
    }

    private function createProductLogisticsTable(): void
    {
        $engine = defined('_MYSQL_ENGINE_') ? _MYSQL_ENGINE_ : 'InnoDB';

        $this->getPdo()->exec('
            CREATE TABLE IF NOT EXISTS `' . $this->productLogisticsTable() . '` (
                `id_product_logistics` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                `id_product` INT UNSIGNED NOT NULL,
                `id_product_attribute` INT UNSIGNED NOT NULL DEFAULT 0,
                `unit_volume` DECIMAL(20,6) NOT NULL DEFAULT 0.000000,
                `units_per_carton` INT UNSIGNED NOT NULL DEFAULT 0,
                `carton_length` DECIMAL(20,3) NOT NULL DEFAULT 0.000,
                `carton_width` DECIMAL(20,3) NOT NULL DEFAULT 0.000,
                `carton_height` DECIMAL(20,3) NOT NULL DEFAULT 0.000,
                `carton_gross_weight` DECIMAL(20,6) NOT NULL DEFAULT 0.000000,
                `module_model` VARCHAR(128) NOT NULL DEFAULT "",
                `material` VARCHAR(191) NOT NULL DEFAULT "",
                `description` TEXT NULL,
                `hs_code` VARCHAR(64) NOT NULL DEFAULT "",
                `customs_duty_rate` DECIMAL(10,4) NOT NULL DEFAULT 0.0000,
                `date_add` DATETIME NOT NULL,
                `date_upd` DATETIME NOT NULL,
                PRIMARY KEY (`id_product_logistics`),
                UNIQUE KEY `psinv_product_logistics_product` (`id_product`, `id_product_attribute`)
            ) ENGINE=' . $engine . ' DEFAULT CHARSET=utf8mb4
        ');
    }

    private function ensureProductLogisticsTableColumns(): void
    {
        $existingColumns = [];
        $rows = $this->getPdo()->query('SHOW COLUMNS FROM `' . $this->productLogisticsTable() . '`')->fetchAll(PDO::FETCH_ASSOC);
        foreach ($rows as $row) {
            $field = (string) ($row['Field'] ?? '');
            if ($field !== '') {
                $existingColumns[$field] = true;
            }
        }

        $columnDefinitions = [
            'module_model' => '`module_model` VARCHAR(128) NOT NULL DEFAULT "" AFTER `carton_gross_weight`',
            'material' => '`material` VARCHAR(191) NOT NULL DEFAULT "" AFTER `module_model`',
            'description' => '`description` TEXT NULL AFTER `material`',
            'hs_code' => '`hs_code` VARCHAR(64) NOT NULL DEFAULT "" AFTER `description`',
            'customs_duty_rate' => '`customs_duty_rate` DECIMAL(10,4) NOT NULL DEFAULT 0.0000 AFTER `hs_code`',
        ];

        foreach ($columnDefinitions as $columnName => $definition) {
            if (isset($existingColumns[$columnName])) {
                continue;
            }

            $this->getPdo()->exec('ALTER TABLE `' . $this->productLogisticsTable() . '` ADD COLUMN ' . $definition);
        }
    }

    private function ensurePurchaseOrderFileTableColumns(): void
    {
        $table = $this->purchaseOrderTable('purchase_order_file');
        try {
            $existingColumns = [];
            $rows = $this->getPdo()->query('SHOW COLUMNS FROM `' . $table . '`')->fetchAll(PDO::FETCH_ASSOC);
            foreach ($rows as $row) {
                $field = (string) ($row['Field'] ?? '');
                if ($field !== '') {
                    $existingColumns[$field] = true;
                }
            }

            if (!isset($existingColumns['id_psinv_document_type'])) {
                $this->getPdo()->exec('ALTER TABLE `' . $table . '` ADD COLUMN `id_psinv_document_type` INT UNSIGNED NULL DEFAULT NULL AFTER `id_purchase_order`');
            }
        } catch (\Throwable $e) {
            // Table may not exist yet — will be created in createPurchaseOrderTables()
        }
    }

    private function seedPurchaseOrdersIfEmpty(): void
    {
        $count = (int) $this->getPdo()->query('SELECT COUNT(*) FROM `' . $this->purchaseOrderTable('purchase_order') . '`')->fetchColumn();
        if ($count > 0) {
            return;
        }

        for ($i = 0; $i < 3; $i++) {
            $idPurchaseOrder = $this->createPurchaseOrder();
            $statusKeys = array_column($this->getConfiguredPurchaseOrderStatuses(), 'key');
            if ($statusKeys === []) {
                $statusKeys = [$this->getDefaultPurchaseOrderStatusKey()];
            }
            $incoterms = ['FOB', 'FCA', 'DAP'];
            $currencies = ['USD', 'EUR', 'PLN'];
            $orderedAt = (new DateTimeImmutable('today 09:00:00'))->modify(sprintf('-%d days', $i * 6));
            $deliveryAt = $orderedAt->modify('+25 days');

            $stmt = $this->getPdo()->prepare('
                UPDATE `' . $this->purchaseOrderTable('purchase_order') . '`
                SET
                    reference = :reference,
                    ordered_at = :ordered_at,
                    delivery_at = :delivery_at,
                    currency_code = :currency_code,
                    currency_rate = :currency_rate,
                    status_key = :status_key,
                    incoterm_code = :incoterm_code,
                    transport_cost = :transport_cost,
                    carrier_name = :carrier_name,
                    shipment_number = :shipment_number,
                    invoice_number = :invoice_number,
                    date_upd = NOW()
                WHERE id_purchase_order = :id_purchase_order
                LIMIT 1
            ');
            $stmt->execute([
                ':reference' => sprintf('ZT-%s-%03d', $orderedAt->format('Y'), $i + 1),
                ':ordered_at' => $orderedAt->format('Y-m-d H:i:s'),
                ':delivery_at' => $deliveryAt->format('Y-m-d H:i:s'),
                ':currency_code' => $currencies[$i % count($currencies)],
                ':currency_rate' => $i === 0 ? '3.980000' : ($i === 1 ? '4.310000' : '1.000000'),
                ':status_key' => $statusKeys[$i % count($statusKeys)],
                ':incoterm_code' => $incoterms[$i % count($incoterms)],
                ':transport_cost' => number_format(320 + ($i * 180), 6, '.', ''),
                ':carrier_name' => $i === 0 ? 'MSC' : ($i === 1 ? 'DHL Global Forwarding' : 'DB Schenker'),
                ':shipment_number' => $i === 0 ? 'CONT-458821' : ($i === 1 ? 'AIR-903421' : 'ROAD-118204'),
                ':invoice_number' => $i === 0 ? 'FV/IMP/2026/001' : ($i === 1 ? 'FV/IMP/2026/002' : 'FV/IMP/2026/003'),
                ':id_purchase_order' => $idPurchaseOrder,
            ]);
        }
    }

    private function seedPurchaseOrderItems(int $idPurchaseOrder, int $offset = 0): void
    {
        $seedProducts = $this->fetchSeedProducts(4);
        $stmt = $this->getPdo()->prepare('
            INSERT INTO `' . $this->purchaseOrderTable('purchase_order_item') . '` (
                id_purchase_order,
                position,
                id_product,
                id_product_attribute,
                model,
                product_name,
                ean13,
                quantity,
                purchase_price,
                weight,
                image_id,
                date_add,
                date_upd
            ) VALUES (
                :id_purchase_order,
                :position,
                :id_product,
                :id_product_attribute,
                :model,
                :product_name,
                :ean13,
                :quantity,
                :purchase_price,
                :weight,
                :image_id,
                NOW(),
                NOW()
            )
        ');

        foreach ($seedProducts as $index => $product) {
            $quantity = (float) (5 + (($index + $offset) % 4) * 3);
            $purchasePrice = (float) ($product['purchase_price'] ?? 0);
            if ($purchasePrice <= 0) {
                $purchasePrice = 18.50 + ($index * 7.25) + ($offset * 0.9);
            } else {
                $purchasePrice += ($offset * 1.15) + ($index * 0.45);
            }

            $stmt->execute([
                ':id_purchase_order' => $idPurchaseOrder,
                ':position' => $index + 1,
                ':id_product' => (int) ($product['id_product'] ?? 0) > 0 ? (int) $product['id_product'] : null,
                ':id_product_attribute' => (int) ($product['id_product_attribute'] ?? 0),
                ':model' => (string) ($product['model'] ?? ''),
                ':product_name' => (string) ($product['product_name'] ?? ''),
                ':ean13' => (string) ($product['ean13'] ?? ''),
                ':quantity' => number_format($quantity, 3, '.', ''),
                ':purchase_price' => number_format($purchasePrice, 6, '.', ''),
                ':weight' => number_format((float) ($product['weight'] ?? 0), 6, '.', ''),
                ':image_id' => (int) ($product['image_id'] ?? 0),
            ]);
        }
    }

    private function fetchSeedProducts(int $limit): array
    {
        $stmt = $this->getPdo()->prepare('
            SELECT
                p.id_product,
                0 AS id_product_attribute,
                COALESCE(NULLIF(p.reference, ""), CONCAT("SKU-", p.id_product)) AS model,
                COALESCE(NULLIF(pl.name, ""), CONCAT("Produkt ", p.id_product)) AS product_name,
                COALESCE(NULLIF(p.ean13, ""), "") AS ean13,
                IFNULL(p.weight, 0) AS weight,
                IFNULL(p.wholesale_price, 0) AS purchase_price,
                IFNULL(i.id_image, 0) AS image_id
            FROM `' . _DB_PREFIX_ . 'product` p
            INNER JOIN `' . _DB_PREFIX_ . 'product_shop` ps
                ON ps.id_product = p.id_product
               AND ps.id_shop = :id_shop
            LEFT JOIN `' . _DB_PREFIX_ . 'product_lang` pl
                ON pl.id_product = p.id_product
               AND pl.id_lang = :id_lang
               AND pl.id_shop = :id_shop
            LEFT JOIN `' . _DB_PREFIX_ . 'image` i
                ON i.id_product = p.id_product
               AND i.cover = 1
            ORDER BY p.id_product ASC
            LIMIT ' . max(1, (int) $limit)
        );
        $stmt->execute([
            ':id_shop' => (int) $this->context->shop->id,
            ':id_lang' => (int) $this->context->language->id,
        ]);

        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        if (is_array($rows) && $rows) {
            return $rows;
        }

        return [
            ['id_product' => 0, 'id_product_attribute' => 0, 'model' => 'MODEL-001', 'product_name' => 'Przykładowy produkt 1', 'ean13' => '', 'weight' => 1.200, 'purchase_price' => 18.50, 'image_id' => 0],
            ['id_product' => 0, 'id_product_attribute' => 0, 'model' => 'MODEL-002', 'product_name' => 'Przykładowy produkt 2', 'ean13' => '', 'weight' => 0.800, 'purchase_price' => 27.90, 'image_id' => 0],
            ['id_product' => 0, 'id_product_attribute' => 0, 'model' => 'MODEL-003', 'product_name' => 'Przykładowy produkt 3', 'ean13' => '', 'weight' => 2.500, 'purchase_price' => 34.20, 'image_id' => 0],
        ];
    }

    private function getPurchaseOrderCatalogProducts(): array
    {
        $stmt = $this->getPdo()->prepare('
            SELECT
                p.id_product,
                IFNULL(pa.id_product_attribute, 0) AS id_product_attribute,
                COALESCE(NULLIF(psl.module_model, ""), NULLIF(pa.reference, ""), NULLIF(p.reference, ""), CONCAT("SKU-", p.id_product)) AS model,
                COALESCE(NULLIF(pl.name, ""), CONCAT("Produkt ", p.id_product)) AS product_name,
                COALESCE(NULLIF(pa.ean13, ""), NULLIF(p.ean13, ""), "") AS ean13,
                (IFNULL(p.weight, 0) + IFNULL(pa.weight, 0)) AS weight,
                IFNULL(pa.wholesale_price, p.wholesale_price) AS purchase_price,
                IFNULL(psl.units_per_carton, 0) AS units_per_carton,
                GROUP_CONCAT(DISTINCT CONCAT(agl.name, ": ", al.name) SEPARATOR ", ") AS combination_name,
                MIN(pai.id_image) AS combination_image_id,
                i.id_image AS product_image_id,
                lpp.purchase_price AS last_purchase_price
            FROM `' . _DB_PREFIX_ . 'product` p
            INNER JOIN `' . _DB_PREFIX_ . 'product_shop` ps
                ON ps.id_product = p.id_product
               AND ps.id_shop = :id_shop
            LEFT JOIN `' . _DB_PREFIX_ . 'product_lang` pl
                ON pl.id_product = p.id_product
               AND pl.id_lang = :id_lang
               AND pl.id_shop = :id_shop
            LEFT JOIN `' . _DB_PREFIX_ . 'product_attribute` pa
                ON pa.id_product = p.id_product
            LEFT JOIN `' . $this->productLogisticsTable() . '` psl
                ON psl.id_product = p.id_product
               AND psl.id_product_attribute = IFNULL(pa.id_product_attribute, 0)
            LEFT JOIN `' . _DB_PREFIX_ . 'product_attribute_image` pai
                ON pai.id_product_attribute = pa.id_product_attribute
            LEFT JOIN `' . _DB_PREFIX_ . 'image` i
                ON i.id_product = p.id_product
               AND i.cover = 1
            LEFT JOIN `' . _DB_PREFIX_ . 'product_attribute_combination` pac
                ON pac.id_product_attribute = pa.id_product_attribute
            LEFT JOIN `' . _DB_PREFIX_ . 'attribute` a
                ON a.id_attribute = pac.id_attribute
            LEFT JOIN `' . _DB_PREFIX_ . 'attribute_lang` al
                ON al.id_attribute = a.id_attribute
               AND al.id_lang = :id_lang
            LEFT JOIN `' . _DB_PREFIX_ . 'attribute_group_lang` agl
                ON agl.id_attribute_group = a.id_attribute_group
               AND agl.id_lang = :id_lang
            LEFT JOIN (
                SELECT poi2.id_product, poi2.id_product_attribute, poi2.purchase_price
                FROM `' . $this->purchaseOrderTable('purchase_order_item') . '` poi2
                INNER JOIN (
                    SELECT id_product, id_product_attribute, MAX(date_add) AS max_date
                    FROM `' . $this->purchaseOrderTable('purchase_order_item') . '`
                    WHERE id_product IS NOT NULL
                    GROUP BY id_product, id_product_attribute
                ) latest ON latest.id_product = poi2.id_product
                         AND latest.id_product_attribute = poi2.id_product_attribute
                         AND latest.max_date = poi2.date_add
            ) lpp ON lpp.id_product = p.id_product
                  AND lpp.id_product_attribute = IFNULL(pa.id_product_attribute, 0)
            GROUP BY
                p.id_product,
                pa.id_product_attribute,
                psl.module_model,
                pa.reference,
                p.reference,
                pl.name,
                pa.ean13,
                p.ean13,
                p.weight,
                pa.weight,
                pa.wholesale_price,
                p.wholesale_price,
                psl.units_per_carton,
                lpp.purchase_price,
                i.id_image
            ORDER BY pl.name ASC, pa.id_product_attribute ASC, p.id_product ASC
        ');
        $stmt->execute([
            ':id_shop' => (int) $this->context->shop->id,
            ':id_lang' => (int) $this->context->language->id,
        ]);

        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        if (!is_array($rows)) {
            return [];
        }

        return array_map(function (array $row): array {
            $combinationImageId = (int) ($row['combination_image_id'] ?? 0);
            $coverImageId = (int) ($row['product_image_id'] ?? 0);
            $imageId = $combinationImageId > 0 ? $combinationImageId : $coverImageId;
            $productName = trim((string) ($row['product_name'] ?? ''));
            $combinationName = trim((string) ($row['combination_name'] ?? ''));
            $model = trim((string) ($row['model'] ?? ''));
            $ean13 = trim((string) ($row['ean13'] ?? ''));

            $labelParts = [];
            if ($model !== '') {
                $labelParts[] = $model;
            }
            if ($productName !== '') {
                $labelParts[] = $productName;
            }
            if ($combinationName !== '') {
                $labelParts[] = $combinationName;
            }
            if ($ean13 !== '') {
                $labelParts[] = 'EAN: ' . $ean13;
            }

            return [
                'id_product' => (int) ($row['id_product'] ?? 0),
                'id_product_attribute' => (int) ($row['id_product_attribute'] ?? 0),
                'selection_key' => (int) ($row['id_product'] ?? 0) . ':' . (int) ($row['id_product_attribute'] ?? 0),
                'model' => $model,
                'product_name' => $productName,
                'combination_name' => $combinationName,
                'ean13' => $ean13,
                'weight' => (float) ($row['weight'] ?? 0),
                'purchase_price' => (float) ($row['purchase_price'] ?? 0),
                'purchase_price_raw' => rtrim(rtrim(number_format((float) ($row['purchase_price'] ?? 0), 6, '.', ''), '0'), '.'),
                'units_per_carton' => (int) ($row['units_per_carton'] ?? 0),
                'last_purchase_price' => $row['last_purchase_price'] !== null ? (float) $row['last_purchase_price'] : null,
                'last_purchase_price_raw' => $row['last_purchase_price'] !== null ? rtrim(rtrim(number_format((float) $row['last_purchase_price'], 6, '.', ''), '0'), '.') : '',
                'image_id' => $imageId,
                'image_url' => $imageId > 0 ? $this->getImagePath($imageId) : null,
                'image_thumb_url' => $imageId > 0 ? $this->getImageThumbPath($imageId) : null,
                'label' => implode(' | ', array_filter($labelParts)),
            ];
        }, $rows);
    }

    private function getPurchaseOrderCatalogProduct(int $idProduct, int $idProductAttribute): array
    {
        foreach ($this->getPurchaseOrderCatalogProducts() as $product) {
            if ((int) ($product['id_product'] ?? 0) === $idProduct && (int) ($product['id_product_attribute'] ?? 0) === $idProductAttribute) {
                return $product;
            }
        }

        throw new InvalidArgumentException('Nie znaleziono produktu do dodania.');
    }

    private function parsePurchaseOrderProductSelection(string $selection): array
    {
        $selection = trim($selection);
        if ($selection === '' || strpos($selection, ':') === false) {
            throw new InvalidArgumentException('Wybierz produkt do dodania.');
        }

        [$idProduct, $idProductAttribute] = array_pad(explode(':', $selection, 2), 2, '0');
        $idProduct = (int) $idProduct;
        $idProductAttribute = (int) $idProductAttribute;
        if ($idProduct <= 0 || $idProductAttribute < 0) {
            throw new InvalidArgumentException('Wybierz produkt do dodania.');
        }

        return [$idProduct, $idProductAttribute];
    }

    private function getNextPurchaseOrderItemPosition(int $idPurchaseOrder): int
    {
        $stmt = $this->getPdo()->prepare('
            SELECT IFNULL(MAX(position), 0) + 1
            FROM `' . $this->purchaseOrderTable('purchase_order_item') . '`
            WHERE id_purchase_order = :id_purchase_order
        ');
        $stmt->execute([
            ':id_purchase_order' => $idPurchaseOrder,
        ]);

        return max(1, (int) $stmt->fetchColumn());
    }

    private function getPurchaseOrderItems(int $idPurchaseOrder, string $currencyCode): array
    {
        $this->ensureProductLogisticsInfrastructure();

        $stmt = $this->getPdo()->prepare('
            SELECT
                poi.*,
                IFNULL(p.width, 0) AS product_width,
                IFNULL(p.height, 0) AS product_height,
                IFNULL(p.depth, 0) AS product_depth,
                IFNULL(psl.unit_volume, 0) AS unit_volume,
                IFNULL(psl.units_per_carton, 0) AS units_per_carton,
                IFNULL(psl.carton_length, 0) AS carton_length,
                IFNULL(psl.carton_width, 0) AS carton_width,
                IFNULL(psl.carton_height, 0) AS carton_height,
                IFNULL(psl.carton_gross_weight, 0) AS carton_gross_weight,
                IFNULL(psl.module_model, "") AS module_model,
                IFNULL(psl.material, "") AS material,
                IFNULL(psl.description, "") AS logistics_description,
                IFNULL(psl.hs_code, "") AS hs_code,
                IFNULL(psl.customs_duty_rate, 0) AS customs_duty_rate
            FROM `' . $this->purchaseOrderTable('purchase_order_item') . '` poi
            LEFT JOIN `' . _DB_PREFIX_ . 'product` p ON p.id_product = poi.id_product
            LEFT JOIN `' . $this->productLogisticsTable() . '` psl
                ON psl.id_product = poi.id_product
               AND psl.id_product_attribute = poi.id_product_attribute
            WHERE poi.id_purchase_order = :id_purchase_order
            ORDER BY poi.position ASC, poi.id_purchase_order_item ASC
        ');
        $stmt->execute([
            ':id_purchase_order' => $idPurchaseOrder,
        ]);

        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        if (!is_array($rows)) {
            return [];
        }

        $items = [];
        foreach ($rows as $index => $row) {
            $quantity = max(0, (int) round((float) ($row['quantity'] ?? 0)));
            $purchasePrice = (float) ($row['purchase_price'] ?? 0);
            $weight = (float) ($row['weight'] ?? 0);
            $lineValue = $quantity * $purchasePrice;
            $totalWeight = $quantity * $weight;
            $unitVolume = $this->resolveProductUnitVolume($row);
            $totalVolume = $quantity * $unitVolume;
            $imageId = (int) ($row['image_id'] ?? 0);
            $idProduct = (int) ($row['id_product'] ?? 0);
            $idProductAttribute = (int) ($row['id_product_attribute'] ?? 0);
            $moduleModel = trim((string) ($row['module_model'] ?? ''));
            $fallbackModel = trim((string) ($row['model'] ?? ''));
            $displayModel = $moduleModel !== '' ? $moduleModel : $fallbackModel;
            $customsDutyRate = (float) ($row['customs_duty_rate'] ?? 0);

            $items[] = [
                'id_purchase_order_item' => (int) ($row['id_purchase_order_item'] ?? 0),
                'id_product' => $idProduct,
                'id_product_attribute' => $idProductAttribute,
                'lp' => $index + 1,
                'image_url' => $imageId > 0 ? $this->getImagePath($imageId) : null,
                'image_thumb_url' => $imageId > 0 ? $this->getImageThumbPath($imageId) : null,
                'model' => $displayModel,
                'product_name' => (string) ($row['product_name'] ?? ''),
                'ean13' => (string) ($row['ean13'] ?? ''),
                'quantity' => number_format($quantity, 0, ',', ' '),
                'quantity_raw' => (string) $quantity,
                'purchase_price_raw' => $purchasePrice > 0 ? rtrim(rtrim(number_format($purchasePrice, 6, '.', ''), '0'), '.') : '0',
                'purchase_price_formatted' => $this->formatMoneyByCurrency($purchasePrice, $currencyCode),
                'weight_formatted' => $this->formatWeight($weight),
                'total_weight_formatted' => $this->formatWeight($totalWeight),
                'total_weight_raw' => $totalWeight,
                'volume_formatted' => $this->formatVolume($totalVolume),
                'volume_raw' => $totalVolume,
                'value_formatted' => $this->formatMoneyByCurrency($lineValue, $currencyCode),
                'line_value_raw' => $lineValue,
                'product_edit_url' => $idProduct > 0 ? $this->getProductEditUrl($idProduct) : '',
                'product_module_data' => [
                    'model' => $displayModel,
                    'unit_volume_raw' => $unitVolume > 0 ? rtrim(rtrim(number_format($unitVolume, 6, '.', ''), '0'), '.') : '',
                    'dimension_w_raw' => (float) ($row['carton_height'] ?? 0) > 0 ? rtrim(rtrim(number_format((float) ($row['carton_height'] ?? 0), 3, '.', ''), '0'), '.') : '',
                    'dimension_s_raw' => (float) ($row['carton_width'] ?? 0) > 0 ? rtrim(rtrim(number_format((float) ($row['carton_width'] ?? 0), 3, '.', ''), '0'), '.') : '',
                    'dimension_d_raw' => (float) ($row['carton_length'] ?? 0) > 0 ? rtrim(rtrim(number_format((float) ($row['carton_length'] ?? 0), 3, '.', ''), '0'), '.') : '',
                    'gross_weight_raw' => (float) ($row['carton_gross_weight'] ?? 0) > 0 ? rtrim(rtrim(number_format((float) ($row['carton_gross_weight'] ?? 0), 3, '.', ''), '0'), '.') : '',
                    'units_per_carton_raw' => (int) ($row['units_per_carton'] ?? 0) > 0 ? (string) (int) ($row['units_per_carton'] ?? 0) : '',
                    'material' => trim((string) ($row['material'] ?? '')),
                    'description' => trim((string) ($row['logistics_description'] ?? '')),
                    'hs_code' => trim((string) ($row['hs_code'] ?? '')),
                    'customs_duty_rate_raw' => $customsDutyRate > 0 ? rtrim(rtrim(number_format($customsDutyRate, 4, '.', ''), '0'), '.') : '',
                ],
            ];
        }

        return $items;
    }

    private function getPurchaseOrderFiles(int $idPurchaseOrder): array
    {
        $stmt = $this->getPdo()->prepare('
            SELECT f.*, dt.name AS document_type_name
            FROM `' . $this->purchaseOrderTable('purchase_order_file') . '` f
            LEFT JOIN `' . $this->purchaseOrderTable('document_type') . '` dt
                ON dt.id_psinv_document_type = f.id_psinv_document_type
            WHERE f.id_purchase_order = :id_purchase_order
            ORDER BY f.date_add DESC, f.id_purchase_order_file DESC
        ');
        $stmt->execute([':id_purchase_order' => $idPurchaseOrder]);

        $rows = $stmt->fetchAll(\PDO::FETCH_ASSOC);
        if (!is_array($rows)) {
            return [];
        }

        $imageExts = ['jpg', 'jpeg', 'png', 'gif', 'webp'];

        return array_map(function (array $row) use ($imageExts): array {
            $storedName = (string) ($row['stored_name'] ?? '');
            $filePath = (string) ($row['file_path'] ?? '');
            $mimeType = (string) ($row['mime_type'] ?? '');
            $ext = strtolower(pathinfo($storedName, PATHINFO_EXTENSION));

            return [
                'id_purchase_order_file' => (int) ($row['id_purchase_order_file'] ?? 0),
                'id_psinv_document_type' => (int) ($row['id_psinv_document_type'] ?? 0) ?: null,
                'original_name' => (string) ($row['original_name'] ?? ''),
                'description' => (string) ($row['description'] ?? ''),
                'document_type_name' => (string) ($row['document_type_name'] ?? ''),
                'mime_type' => $mimeType,
                'size_label' => $this->formatFileSize((int) ($row['size_bytes'] ?? 0)),
                'date_add' => $this->formatDateTimeLabel($row['date_add'] ?? null),
                'download_url' => $this->getPurchaseOrderFileUrl($filePath, $storedName),
                'is_image' => in_array($ext, $imageExts, true) || str_starts_with($mimeType, 'image/'),
                'is_pdf' => $ext === 'pdf' || $mimeType === 'application/pdf',
            ];
        }, $rows);
    }

    private function getPurchaseOrderSupplierSummary(int $idSupplier, string $fallbackName = ''): array
    {
        if ($idSupplier <= 0) {
            return [
                'name' => $fallbackName,
                'phone' => '',
                'address' => '',
            ];
        }

        try {
            $supplier = $this->getSupplierFormData($idSupplier);
        } catch (Throwable $e) {
            return [
                'name' => $fallbackName,
                'phone' => '',
                'address' => '',
            ];
        }

        $countryName = $this->getCountryName((int) ($supplier['id_country'] ?? 0));
        $addressLines = array_filter([
            trim((string) ($supplier['address1'] ?? '')),
            trim((string) ($supplier['address2'] ?? '')),
            trim(sprintf('%s %s', (string) ($supplier['postcode'] ?? ''), (string) ($supplier['city'] ?? ''))),
            $countryName,
        ]);

        return [
            'name' => trim((string) ($supplier['name'] ?? $fallbackName)),
            'phone' => trim((string) ($supplier['phone'] ?? '')),
            'address' => implode("\n", $addressLines),
        ];
    }

    private function getCountryName(int $idCountry): string
    {
        if ($idCountry <= 0) {
            return '';
        }

        $stmt = $this->getPdo()->prepare('
            SELECT name
            FROM `' . _DB_PREFIX_ . 'country_lang`
            WHERE id_country = :id_country
              AND id_lang = :id_lang
            LIMIT 1
        ');
        $stmt->execute([
            ':id_country' => $idCountry,
            ':id_lang' => (int) $this->context->language->id,
        ]);

        return trim((string) $stmt->fetchColumn());
    }

    private function findSupplierNameById(int $idSupplier): string
    {
        if ($idSupplier <= 0) {
            return '';
        }

        foreach ($this->getSuppliers() as $supplier) {
            if ((int) ($supplier['id_supplier'] ?? 0) === $idSupplier) {
                return trim((string) ($supplier['name'] ?? ''));
            }
        }

        return '';
    }

    private function buildNextPurchaseOrderReference(): string
    {
        $nextId = (int) $this->getPdo()->query('SELECT IFNULL(MAX(id_purchase_order), 0) + 1 FROM `' . $this->purchaseOrderTable('purchase_order') . '`')->fetchColumn();

        return sprintf('ZT-%s-%03d', date('Y'), max(1, $nextId));
    }

    private function getPurchaseOrderStatusMap(): array
    {
        $map = [];
        foreach ($this->getConfiguredPurchaseOrderStatuses() as $status) {
            $key = (string) ($status['key'] ?? '');
            if ($key === '') {
                continue;
            }

            $color = $this->normalizePurchaseOrderStatusColor((string) ($status['color'] ?? ''));
            $map[$key] = [
                'label' => (string) ($status['label'] ?? $key),
                'class' => 'badge',
                'color' => $color,
                'badge_style' => $this->buildPurchaseOrderBadgeStyle($color),
            ];
        }

        if ($map === []) {
            foreach ($this->getDefaultPurchaseOrderStatuses() as $status) {
                $map[(string) $status['key']] = [
                    'label' => (string) $status['label'],
                    'class' => 'badge',
                    'color' => (string) $status['color'],
                    'badge_style' => (string) $status['badge_style'],
                ];
            }
        }

        return $map;
    }

    private function normalizePurchaseOrderStatusKey(string $statusKey): string
    {
        $statusKey = trim($statusKey);
        $aliases = [
            'sent' => 'ordered',
            'confirmed' => 'paid',
            'completed' => 'finished',
        ];

        return $aliases[$statusKey] ?? ($statusKey !== '' ? $statusKey : $this->getDefaultPurchaseOrderStatusKey());
    }

    private function migratePurchaseOrderStatuses(): void
    {
        $aliases = [
            'sent' => 'ordered',
            'confirmed' => 'paid',
            'completed' => 'finished',
        ];

        foreach ($aliases as $oldKey => $newKey) {
            $stmt = $this->getPdo()->prepare('
                UPDATE `' . $this->purchaseOrderTable('purchase_order') . '`
                SET status_key = :new_key
                WHERE status_key = :old_key
            ');
            $stmt->execute([
                ':new_key' => $newKey,
                ':old_key' => $oldKey,
            ]);
        }
    }

    private function getPurchaseOrderStatusMeta(string $statusKey): array
    {
        $map = $this->getPurchaseOrderStatusMap();

        $defaultKey = $this->getDefaultPurchaseOrderStatusKey();

        return $map[$statusKey] ?? $map[$defaultKey] ?? reset($map);
    }

    public function getPurchaseOrderStatusOptions(): array
    {
        $options = [];
        foreach ($this->getPurchaseOrderStatusMap() as $value => $meta) {
            $options[] = [
                'value' => $value,
                'label' => $meta['label'],
                'color' => $meta['color'],
                'badge_style' => $meta['badge_style'],
            ];
        }

        return $options;
    }

    private function getDefaultPurchaseOrderStatuses(): array
    {
        $statuses = [
            [
                'key' => 'draft',
                'label' => $this->t('purchase_order_status_draft'),
                'color' => '#B7C1CB',
            ],
            [
                'key' => 'ordered',
                'label' => $this->t('purchase_order_status_ordered'),
                'color' => '#EF5A67',
            ],
            [
                'key' => 'paid',
                'label' => $this->t('purchase_order_status_paid'),
                'color' => '#25B9D7',
            ],
            [
                'key' => 'shipped',
                'label' => $this->t('purchase_order_status_shipped'),
                'color' => '#3E7BFA',
            ],
            [
                'key' => 'delivered',
                'label' => $this->t('purchase_order_status_delivered'),
                'color' => '#35B36B',
            ],
            [
                'key' => 'ready_for_accounting',
                'label' => $this->t('purchase_order_status_ready_for_accounting'),
                'color' => '#20A67A',
            ],
            [
                'key' => 'finished',
                'label' => $this->t('purchase_order_status_finished'),
                'color' => '#2E8B57',
            ],
        ];

        return array_map(function (array $status): array {
            $status['badge_style'] = $this->buildPurchaseOrderBadgeStyle((string) ($status['color'] ?? ''));

            return $status;
        }, $statuses);
    }

    private function getDefaultPurchaseOrderStatusKey(): string
    {
        $statuses = $this->getConfiguredPurchaseOrderStatuses();

        return (string) ($statuses[0]['key'] ?? 'draft');
    }

    private function normalizePurchaseOrderStatusesForStorage(array $statuses): array
    {
        $defaultsByKey = [];
        foreach ($this->getDefaultPurchaseOrderStatuses() as $status) {
            $defaultsByKey[(string) $status['key']] = $status;
        }

        $normalized = [];
        $usedKeys = [];
        foreach ($statuses as $status) {
            if (!is_array($status)) {
                continue;
            }

            $rawKey = trim((string) ($status['key'] ?? ''));
            $rawLabel = trim((string) ($status['label'] ?? ''));
            $rawColorMode = trim((string) ($status['color_mode'] ?? ''));
            $rawCustomColor = trim((string) ($status['color_custom'] ?? $status['color'] ?? ''));
            $rawColor = $rawColorMode !== '' && $rawColorMode !== '__custom__' ? $rawColorMode : $rawCustomColor;

            if ($rawKey === '' && $rawLabel === '' && $rawColor === '') {
                continue;
            }

            $normalizedKey = $this->buildUniquePurchaseOrderStatusKey($rawKey !== '' ? $rawKey : $rawLabel, $usedKeys);
            $defaultMeta = $defaultsByKey[$normalizedKey] ?? null;
            $label = $rawLabel !== '' ? $rawLabel : (string) ($defaultMeta['label'] ?? ucfirst(str_replace('_', ' ', $normalizedKey)));
            $color = $this->normalizePurchaseOrderStatusColor($rawColor, (string) ($defaultMeta['color'] ?? '#25B9D7'));

            $normalized[] = [
                'key' => $normalizedKey,
                'label' => $this->truncatePurchaseOrderStatusLabel($label),
                'color' => $color,
            ];
        }

        return $normalized !== [] ? $normalized : array_map(static function (array $status): array {
            return [
                'key' => (string) $status['key'],
                'label' => (string) $status['label'],
                'color' => (string) $status['color'],
            ];
        }, $this->getDefaultPurchaseOrderStatuses());
    }

    private function truncatePurchaseOrderStatusLabel(string $label): string
    {
        $label = trim($label);
        if ($label === '') {
            return 'Status';
        }

        if (function_exists('mb_substr')) {
            return (string) mb_substr($label, 0, 80);
        }

        return substr($label, 0, 80);
    }

    private function buildUniquePurchaseOrderStatusKey(string $seed, array &$usedKeys): string
    {
        $base = $this->slugifyPurchaseOrderStatusKey($seed);
        if ($base === '') {
            $base = 'status';
        }

        $candidate = $base;
        $suffix = 2;
        while (in_array($candidate, $usedKeys, true)) {
            $suffixLabel = '_' . $suffix;
            $candidate = substr($base, 0, max(1, 32 - strlen($suffixLabel))) . $suffixLabel;
            ++$suffix;
        }

        $usedKeys[] = $candidate;

        return $candidate;
    }

    private function slugifyPurchaseOrderStatusKey(string $value): string
    {
        $value = trim((string) Tools::link_rewrite($value));
        $value = strtolower(str_replace('-', '_', $value));
        $value = preg_replace('/[^a-z0-9_]+/', '_', $value) ?? '';
        $value = trim($value, '_');

        return substr($value, 0, 32);
    }

    private function normalizePurchaseOrderStatusColor(string $color, string $fallback = '#25B9D7'): string
    {
        $color = strtoupper(trim($color));
        if ($color === '') {
            return strtoupper($fallback);
        }

        if ($color[0] !== '#') {
            $color = '#' . $color;
        }

        if (!preg_match('/^#[0-9A-F]{6}$/', $color)) {
            return strtoupper($fallback);
        }

        return $color;
    }

    private function buildPurchaseOrderBadgeStyle(string $color): string
    {
        $color = $this->normalizePurchaseOrderStatusColor($color);

        return sprintf('background-color: %s !important; color: #fff !important;', $color);
    }

    private function hexToRgb(string $color): array
    {
        $color = ltrim($this->normalizePurchaseOrderStatusColor($color), '#');

        return [
            hexdec(substr($color, 0, 2)),
            hexdec(substr($color, 2, 2)),
            hexdec(substr($color, 4, 2)),
        ];
    }

    public function getPurchaseOrderIncotermOptions(): array
    {
        $incoterms = [
            'FCA' => 'Free Carrier – sprzedawca dostarcza towar do przewoźnika wskazanego przez kupującego',
            'FOB' => 'Free On Board – sprzedawca ładuje towar na statek w porcie załadunku; ryzyko przechodzi z chwilą załadunku',
            'DAP' => 'Delivered At Place – towar dostarczony do miejsca przeznaczenia; kupujący odprawia cło i płaci podatki',
            'EXW' => 'Ex Works – kupujący odbiera towar z magazynu sprzedawcy i ponosi wszystkie koszty transportu',
            'DDP' => 'Delivered Duty Paid – sprzedawca ponosi wszystkie koszty i formalności celne do miejsca przeznaczenia',
            'CIF' => 'Cost, Insurance & Freight – sprzedawca opłaca fracht i ubezpieczenie do portu przeznaczenia',
            'CIP' => 'Carriage & Insurance Paid To – sprzedawca opłaca transport i ubezpieczenie do uzgodnionego miejsca',
            'CPT' => 'Carriage Paid To – sprzedawca opłaca transport do uzgodnionego miejsca przeznaczenia',
            'FAS' => 'Free Alongside Ship – sprzedawca dostarcza towar wzdłuż burty statku w porcie załadunku',
            'CFR' => 'Cost & Freight – sprzedawca opłaca fracht do portu przeznaczenia; ryzyko przechodzi przy załadunku',
        ];

        return array_map(static function (string $code, string $description): array {
            return [
                'value'       => $code,
                'label'       => $code,
                'description' => $description,
            ];
        }, array_keys($incoterms), array_values($incoterms));
    }

    public function getCarriers(): array
    {
        $this->ensurePurchaseOrderInfrastructure();
        $rows = $this->getPdo()->query('SELECT * FROM `' . $this->purchaseOrderTable('carrier') . '` ORDER BY name ASC')->fetchAll(\PDO::FETCH_ASSOC);

        return array_map(static function (array $row): array {
            return [
                'id' => (int) ($row['id_psinv_carrier'] ?? 0),
                'name' => (string) ($row['name'] ?? ''),
            ];
        }, is_array($rows) ? $rows : []);
    }

    public function saveCarrier(int $id, string $name): array
    {
        $this->ensurePurchaseOrderInfrastructure();
        $name = trim($name);
        if ($name === '') {
            throw new \InvalidArgumentException('Nazwa przewoźnika nie może być pusta.');
        }

        if ($id > 0) {
            $stmt = $this->getPdo()->prepare('UPDATE `' . $this->purchaseOrderTable('carrier') . '` SET name = :name WHERE id_psinv_carrier = :id LIMIT 1');
            $stmt->execute([':name' => $name, ':id' => $id]);
        } else {
            $stmt = $this->getPdo()->prepare('INSERT INTO `' . $this->purchaseOrderTable('carrier') . '` (name, date_add) VALUES (:name, NOW())');
            $stmt->execute([':name' => $name]);
            $id = (int) $this->getPdo()->lastInsertId();
        }

        return ['id' => $id, 'name' => $name];
    }

    public function deleteCarrier(int $id): void
    {
        $this->ensurePurchaseOrderInfrastructure();
        $stmt = $this->getPdo()->prepare('DELETE FROM `' . $this->purchaseOrderTable('carrier') . '` WHERE id_psinv_carrier = :id LIMIT 1');
        $stmt->execute([':id' => $id]);
    }

    public function getDocumentTypes(): array
    {
        $this->ensurePurchaseOrderInfrastructure();
        $rows = $this->getPdo()->query('SELECT * FROM `' . $this->purchaseOrderTable('document_type') . '` ORDER BY name ASC')->fetchAll(\PDO::FETCH_ASSOC);

        return array_map(static function (array $row): array {
            return [
                'id' => (int) ($row['id_psinv_document_type'] ?? 0),
                'name' => (string) ($row['name'] ?? ''),
            ];
        }, is_array($rows) ? $rows : []);
    }

    public function saveDocumentType(int $id, string $name): array
    {
        $this->ensurePurchaseOrderInfrastructure();
        $name = trim($name);
        if ($name === '') {
            throw new \InvalidArgumentException('Nazwa rodzaju dokumentu nie może być pusta.');
        }

        if ($id > 0) {
            $stmt = $this->getPdo()->prepare('UPDATE `' . $this->purchaseOrderTable('document_type') . '` SET name = :name WHERE id_psinv_document_type = :id LIMIT 1');
            $stmt->execute([':name' => $name, ':id' => $id]);
        } else {
            $stmt = $this->getPdo()->prepare('INSERT INTO `' . $this->purchaseOrderTable('document_type') . '` (name, date_add) VALUES (:name, NOW())');
            $stmt->execute([':name' => $name]);
            $id = (int) $this->getPdo()->lastInsertId();
        }

        return ['id' => $id, 'name' => $name];
    }

    public function deleteDocumentType(int $id): void
    {
        $this->ensurePurchaseOrderInfrastructure();
        $stmt = $this->getPdo()->prepare('DELETE FROM `' . $this->purchaseOrderTable('document_type') . '` WHERE id_psinv_document_type = :id LIMIT 1');
        $stmt->execute([':id' => $id]);
    }

    public function getPurchaseOrderCurrencyOptions(): array
    {
        $codes = ['PLN', 'EUR', 'USD', 'GBP', 'CNY'];
        $currentCode = strtoupper(trim((string) ($this->context->currency->iso_code ?? '')));
        if ($currentCode !== '' && !in_array($currentCode, $codes, true)) {
            array_unshift($codes, $currentCode);
        }

        return array_map(static function (string $code): array {
            return [
                'value' => $code,
                'label' => $code,
            ];
        }, array_values(array_unique($codes)));
    }

    private function ensurePurchaseOrderUploadDirectory(): void
    {
        $dir = $this->getPurchaseOrderUploadDirectory();
        if (!is_dir($dir) && !mkdir($dir, 0775, true) && !is_dir($dir)) {
            throw new RuntimeException('Nie udało się przygotować katalogu na pliki zamówień.');
        }
    }

    private function getPurchaseOrderUploadDirectory(string $dirName = ''): string
    {
        $base = rtrim($this->modulePath, '/') . '/uploads/purchase_orders/';

        return $dirName !== '' ? $base . $dirName . '/' : $base;
    }

    private function getPurchaseOrderDirName(int $idPurchaseOrder): string
    {
        $stmt = $this->getPdo()->prepare('SELECT reference FROM `' . $this->purchaseOrderTable('purchase_order') . '` WHERE id_purchase_order = :id LIMIT 1');
        $stmt->execute([':id' => $idPurchaseOrder]);
        $row = $stmt->fetch(\PDO::FETCH_ASSOC);
        $ref = trim((string) ($row['reference'] ?? ''));

        if ($ref !== '') {
            // Sanitize: keep alphanumeric, dashes, underscores; replace anything else with _
            $safe = preg_replace('/[^A-Za-z0-9\-_]/', '_', $ref);
            $safe = trim((string) $safe, '_');
            if ($safe !== '') {
                return $safe;
            }
        }

        return (string) $idPurchaseOrder;
    }

    private function getPurchaseOrderFileAbsolutePath(string $filePath, string $storedName): string
    {
        if ($filePath !== '') {
            // file_path stored as 'modules/prestashopinventory/...' — resolve from PS root
            $psRoot = defined('_PS_ROOT_DIR_') ? rtrim(_PS_ROOT_DIR_, '/') : rtrim($this->modulePath, '/') . '/../..';

            // Legacy path starting with 'upload/' — stored in old PS upload dir
            if (str_starts_with($filePath, 'upload/')) {
                $uploadRoot = defined('_PS_UPLOAD_DIR_') ? _PS_UPLOAD_DIR_ : $psRoot . '/upload/';
                $rel = preg_replace('#^upload/#', '', $filePath);

                return rtrim($uploadRoot, '/') . '/' . $rel;
            }

            return $psRoot . '/' . ltrim($filePath, '/');
        }

        // Fallback: legacy flat structure using stored_name
        return rtrim($this->modulePath, '/') . '/uploads/purchase_orders/' . $storedName;
    }

    private function getPurchaseOrderFileUrl(string $filePath, string $storedName): string
    {
        $base = rtrim(__PS_BASE_URI__, '/');

        if ($filePath !== '') {
            return $base . '/' . ltrim($filePath, '/');
        }

        return $base . '/modules/prestashopinventory/uploads/purchase_orders/' . rawurlencode($storedName);
    }

    private function purchaseOrderTable(string $name): string
    {
        return _DB_PREFIX_ . 'prestashopinventory_' . $name;
    }

    private function productLogisticsTable(): string
    {
        return _DB_PREFIX_ . 'prestashopinventory_product_logistics';
    }

    private function upsertProductLogisticsData(int $idProduct, int $idAttr, array $data): void
    {
        $existing = $this->getProductLogisticsRow($idProduct, $idAttr);
        $row = array_merge($existing, $data);

        $stmt = $this->getPdo()->prepare('
            INSERT INTO `' . $this->productLogisticsTable() . '` (
                id_product,
                id_product_attribute,
                unit_volume,
                units_per_carton,
                carton_length,
                carton_width,
                carton_height,
                carton_gross_weight,
                module_model,
                material,
                description,
                hs_code,
                customs_duty_rate,
                date_add,
                date_upd
            ) VALUES (
                :id_product,
                :id_product_attribute,
                :unit_volume,
                :units_per_carton,
                :carton_length,
                :carton_width,
                :carton_height,
                :carton_gross_weight,
                :module_model,
                :material,
                :description,
                :hs_code,
                :customs_duty_rate,
                NOW(),
                NOW()
            )
            ON DUPLICATE KEY UPDATE
                unit_volume = VALUES(unit_volume),
                units_per_carton = VALUES(units_per_carton),
                carton_length = VALUES(carton_length),
                carton_width = VALUES(carton_width),
                carton_height = VALUES(carton_height),
                carton_gross_weight = VALUES(carton_gross_weight),
                module_model = VALUES(module_model),
                material = VALUES(material),
                description = VALUES(description),
                hs_code = VALUES(hs_code),
                customs_duty_rate = VALUES(customs_duty_rate),
                date_upd = NOW()
        ');
        $stmt->execute([
            ':id_product' => $idProduct,
            ':id_product_attribute' => $idAttr,
            ':unit_volume' => number_format((float) ($row['unit_volume'] ?? 0), 6, '.', ''),
            ':units_per_carton' => max(0, (int) ($row['units_per_carton'] ?? 0)),
            ':carton_length' => number_format((float) ($row['carton_length'] ?? 0), 3, '.', ''),
            ':carton_width' => number_format((float) ($row['carton_width'] ?? 0), 3, '.', ''),
            ':carton_height' => number_format((float) ($row['carton_height'] ?? 0), 3, '.', ''),
            ':carton_gross_weight' => number_format((float) ($row['carton_gross_weight'] ?? 0), 6, '.', ''),
            ':module_model' => trim((string) ($row['module_model'] ?? '')),
            ':material' => trim((string) ($row['material'] ?? '')),
            ':description' => trim((string) ($row['description'] ?? '')),
            ':hs_code' => trim((string) ($row['hs_code'] ?? '')),
            ':customs_duty_rate' => number_format((float) ($row['customs_duty_rate'] ?? 0), 4, '.', ''),
        ]);
    }

    private function getProductLogisticsRow(int $idProduct, int $idAttr): array
    {
        $stmt = $this->getPdo()->prepare('
            SELECT *
            FROM `' . $this->productLogisticsTable() . '`
            WHERE id_product = :id_product
              AND id_product_attribute = :id_product_attribute
            LIMIT 1
        ');
        $stmt->execute([
            ':id_product' => $idProduct,
            ':id_product_attribute' => $idAttr,
        ]);

        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!is_array($row)) {
            return [
                'unit_volume' => 0,
                'units_per_carton' => 0,
                'carton_length' => 0,
                'carton_width' => 0,
                'carton_height' => 0,
                'carton_gross_weight' => 0,
                'module_model' => '',
                'material' => '',
                'description' => '',
                'hs_code' => '',
                'customs_duty_rate' => 0,
            ];
        }

        return $row;
    }

    private function buildPurchaseOrderInlineOrderPayload(array $purchaseOrder): array
    {
        $order = is_array($purchaseOrder['order'] ?? null) ? $purchaseOrder['order'] : [];

        return [
            'incoterm_code' => (string) ($order['incoterm_code'] ?? ''),
            'ordered_at_date' => (string) ($order['ordered_at_date'] ?? ''),
            'ordered_at_label' => (string) ($order['ordered_at_label'] ?? '—'),
            'delivery_at_date' => (string) ($order['delivery_at_date'] ?? ''),
            'delivery_at_label' => (string) ($order['delivery_at_label'] ?? '—'),
            'carrier_name' => (string) ($order['carrier_name'] ?? ''),
            'invoice_number' => (string) ($order['invoice_number'] ?? ''),
            'transport_cost' => (string) ($order['transport_cost'] ?? '0.00'),
            'transport_cost_label' => (string) ($order['transport_cost_label'] ?? '---'),
            'shipment_number' => (string) ($order['shipment_number'] ?? ''),
            'currency_code' => (string) ($order['currency_code'] ?? 'PLN'),
            'currency_rate' => (string) ($order['currency_rate'] ?? '1.000000'),
        ];
    }

    private function normalizeProductModuleData(array $data, string $fallbackModel = ''): array
    {
        $unitVolumeRaw = str_replace([' ', ','], ['', '.'], trim((string) ($data['unit_volume'] ?? '')));
        $dimensionWRaw = str_replace([' ', ','], ['', '.'], trim((string) ($data['dimension_w'] ?? '')));
        $dimensionSRaw = str_replace([' ', ','], ['', '.'], trim((string) ($data['dimension_s'] ?? '')));
        $dimensionDRaw = str_replace([' ', ','], ['', '.'], trim((string) ($data['dimension_d'] ?? '')));
        $customsDutyRateRaw = str_replace([' ', ','], ['', '.'], trim((string) ($data['customs_duty_rate'] ?? '')));
        $grossWeightRaw = str_replace([' ', ','], ['', '.'], trim((string) ($data['gross_weight'] ?? '')));
        if ($unitVolumeRaw !== '' && (!is_numeric($unitVolumeRaw) || (float) $unitVolumeRaw < 0)) {
            throw new InvalidArgumentException('Objętość ma nieprawidłowy format.');
        }

        foreach ([
            'W' => $dimensionWRaw,
            'S' => $dimensionSRaw,
            'D' => $dimensionDRaw,
        ] as $label => $rawValue) {
            if ($rawValue !== '' && (!is_numeric($rawValue) || (float) $rawValue < 0)) {
                throw new InvalidArgumentException(sprintf('Wymiar %s ma nieprawidłowy format.', $label));
            }
        }

        if ($customsDutyRateRaw !== '' && (!is_numeric($customsDutyRateRaw) || (float) $customsDutyRateRaw < 0)) {
            throw new InvalidArgumentException('Stawka celna ma nieprawidłowy format.');
        }

        return [
            'module_model' => $this->truncateTextValue((string) ($data['module_model'] ?? $data['model'] ?? $fallbackModel), 128),
            'unit_volume' => $unitVolumeRaw !== '' ? round((float) $unitVolumeRaw, 6) : 0,
            'carton_height' => $dimensionWRaw !== '' ? round((float) $dimensionWRaw, 3) : 0,
            'carton_width' => $dimensionSRaw !== '' ? round((float) $dimensionSRaw, 3) : 0,
            'carton_length' => $dimensionDRaw !== '' ? round((float) $dimensionDRaw, 3) : 0,
            'material' => $this->truncateTextValue((string) ($data['material'] ?? ''), 191),
            'description' => $this->truncateTextValue((string) ($data['description'] ?? ''), 5000),
            'hs_code' => strtoupper($this->truncateTextValue((string) ($data['hs_code'] ?? ''), 64)),
            'customs_duty_rate' => $customsDutyRateRaw !== '' ? round((float) $customsDutyRateRaw, 4) : 0,
            'carton_gross_weight' => $grossWeightRaw !== '' ? round((float) $grossWeightRaw, 3) : 0,
            'units_per_carton' => max(0, (int) ($data['units_per_carton'] ?? 0)),
        ];
    }

    private function truncateTextValue(string $value, int $maxLength): string
    {
        $value = trim($value);
        if ($value === '') {
            return '';
        }

        if (function_exists('mb_substr')) {
            return (string) mb_substr($value, 0, $maxLength);
        }

        return substr($value, 0, $maxLength);
    }

    private function formatDateInput($value): string
    {
        $normalized = $this->normalizeDateTimeValue((string) $value);
        if ($normalized === null) {
            return '';
        }

        return (new DateTimeImmutable($normalized))->format('Y-m-d');
    }

    private function normalizeDateTimeValue(string $value): ?string
    {
        $value = trim($value);
        if ($value === '') {
            return null;
        }

        $formats = ['Y-m-d\TH:i', 'Y-m-d H:i', 'Y-m-d H:i:s', DateTimeInterface::ATOM];
        foreach ($formats as $format) {
            $date = DateTimeImmutable::createFromFormat($format, $value);
            if ($date instanceof DateTimeImmutable) {
                return $date->format('Y-m-d H:i:s');
            }
        }

        try {
            return (new DateTimeImmutable($value))->format('Y-m-d H:i:s');
        } catch (Throwable $e) {
            return null;
        }
    }

    private function formatDateTimeInput($value): string
    {
        $normalized = $this->normalizeDateTimeValue((string) $value);
        if ($normalized === null) {
            return '';
        }

        return (new DateTimeImmutable($normalized))->format('Y-m-d\TH:i');
    }

    private function formatDateTimeLabel($value): string
    {
        $normalized = $this->normalizeDateTimeValue((string) $value);
        if ($normalized === null) {
            return '—';
        }

        return (new DateTimeImmutable($normalized))->format('Y-m-d H:i');
    }

    private function formatDateLabel($value): string
    {
        $normalized = $this->normalizeDateTimeValue((string) $value);
        if ($normalized === null) {
            return '—';
        }

        return (new DateTimeImmutable($normalized))->format('Y-m-d');
    }

    private function formatFileSize(int $bytes): string
    {
        if ($bytes <= 0) {
            return '—';
        }

        if ($bytes >= 1048576) {
            return number_format($bytes / 1048576, 2, ',', ' ') . ' MB';
        }

        if ($bytes >= 1024) {
            return number_format($bytes / 1024, 1, ',', ' ') . ' KB';
        }

        return $bytes . ' B';
    }

    private function getAbsoluteImagePath(int $idImage): ?string
    {
        $relativePath = '/img/p/' . implode('/', str_split((string) $idImage)) . '/' . $idImage . '.jpg';
        $filePath = _PS_ROOT_DIR_ . $relativePath;
        if (is_file($filePath)) {
            return $filePath;
        }

        return null;
    }

    private function switchSvgDataUri(bool $on): string
    {
        $bg = $on ? '#6bb35a' : '#d9d9d9';
        $cx = $on ? 30 : 10;
        $svg = <<<SVG
<svg xmlns="http://www.w3.org/2000/svg" width="40" height="20" viewBox="0 0 40 20">
  <rect x="0" y="0" width="40" height="20" rx="10" fill="$bg"/>
  <circle cx="$cx" cy="10" r="8" fill="#ffffff"/>
</svg>
SVG;

        return 'data:image/svg+xml;base64,' . base64_encode($svg);
    }

    private function loadPdfLibrary(): void
    {
        if (class_exists(\Mpdf\Mpdf::class)) {
            return;
        }

        $autoloadCandidates = [
            $this->modulePath . 'vendor/autoload.php',
            dirname($this->modulePath, 2) . '/vendor/autoload.php',
        ];

        foreach ($autoloadCandidates as $autoloadFile) {
            if (is_file($autoloadFile)) {
                require_once $autoloadFile;
                if (class_exists(\Mpdf\Mpdf::class)) {
                    return;
                }
            }
        }

        throw new RuntimeException('mPDF autoloader not found for prestashopinventory module.');
    }
}
