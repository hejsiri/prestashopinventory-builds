Modal Edytuj na stronie Produkty: poprawione wczytywanie pełnych danych i sekcji szybkiej edycji.
Ujednolicono stan modala przez współdzielony storage window.prestashopInventoryScannerState, aby zapobiec rozjazdom danych między scope skryptów.
