# Wpisz tu zmiany do następnego release (jedna linia = jeden bullet)
# Przykład:
# Poprawa walidacji wymiarów w modalu produktu.
# Usunięcie znaku % z nagłówka kolumny Cło.
Zmiana kolejności ikon w kolumnie akcji zamówień, tak aby Usuń było pierwsze.
