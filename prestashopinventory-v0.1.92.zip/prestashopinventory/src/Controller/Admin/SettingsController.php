<?php
declare(strict_types=1);

namespace PrestaShop\Module\PrestashopInventory\Controller\Admin;

use PrestaShopBundle\Security\Annotation\AdminSecurity;
use Symfony\Component\HttpFoundation\Response;

class SettingsController extends AbstractInventoryController
{
    /**
     * @AdminSecurity("is_granted('read', request.get('_legacy_controller'))")
     */
    public function indexAction(): Response
    {
        return $this->renderInventoryPage(
            '@Modules/prestashopinventory/views/templates/admin-modern/settings.html.twig',
            'prestashop_inventory_settings',
            'Ustawienia',
            [
                'migrationNotice' => $this->translate('Ta zakładka będzie nowym miejscem na konfigurację ukrytych produktów i ustawienia modułu po zakończeniu migracji.'),
            ]
        );
    }
}
