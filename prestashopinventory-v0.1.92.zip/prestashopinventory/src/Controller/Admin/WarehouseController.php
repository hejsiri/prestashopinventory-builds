<?php
declare(strict_types=1);

namespace PrestaShop\Module\PrestashopInventory\Controller\Admin;

use PrestaShopBundle\Security\Annotation\AdminSecurity;
use Symfony\Component\HttpFoundation\Response;

class WarehouseController extends AbstractInventoryController
{
    public const TAB_CLASS_NAME = 'AdminPrestashopInventory';

    /**
     * @AdminSecurity("is_granted('read', request.get('_legacy_controller'))")
     */
    public function indexAction(): Response
    {
        return $this->renderInventoryPage(
            '@Modules/prestashopinventory/views/templates/admin-modern/warehouse.html.twig',
            'prestashop_inventory_warehouse',
            'Magazyn',
            [
                'migrationNotice' => $this->translate('To jest nowy szkielet modułu Inventory oparty o zgodną architekturę PS 8.2+ / 9.x. W kolejnych krokach będziemy przenosić logikę tabeli, filtrów i edycji cen.'),
            ]
        );
    }
}
