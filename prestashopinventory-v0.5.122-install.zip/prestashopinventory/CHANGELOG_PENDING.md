# Wpisz tu zmiany do następnego release (jedna linia = jeden bullet)
# Przykład:
# Poprawa walidacji wymiarów w modalu produktu.
# Usunięcie znaku % z nagłówka kolumny Cło.
Dodane notatki do zamówień jako żółte karteczki w widoku zamówienia.
Dopasowany styl ikonki listy zamówień w akcjach produktów do pozostałych ikon.
