Powiększone nagłówki sekcji w menu filtrów.
Etykiety filtrów kolumn i opcji skrócone oraz ujednolicone z nazwami w interfejsie.
Miniatury produktów na liście nie są już ściskane przy wąskim oknie i dużej liczbie kolumn.
