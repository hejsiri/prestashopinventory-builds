Modal Edytuj na stronie Produkty: zawartość przebudowana wizualnie w stylu modala Rentowność.
Dane produktu, logistyki i pola dodatkowe pokazują się teraz w kartach z liniowym układem wartości, zachowując szybką edycję po kliknięciu.
