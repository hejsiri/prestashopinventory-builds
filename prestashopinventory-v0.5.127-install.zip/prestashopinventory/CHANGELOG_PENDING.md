# Wpisz tu zmiany do następnego release (jedna linia = jeden bullet)
# Przykład:
# Poprawa walidacji wymiarów w modalu produktu.
# Usunięcie znaku % z nagłówka kolumny Cło.
Dodanie ikony usuwania dostawców z potwierdzeniem oraz blokadą usuwania dostawców powiązanych z zamówieniami.
