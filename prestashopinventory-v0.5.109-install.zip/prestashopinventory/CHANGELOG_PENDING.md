# Wpisz tu zmiany do następnego release (jedna linia = jeden bullet)
# Przykład:
# Poprawa walidacji wymiarów w modalu produktu.
# Usunięcie znaku % z nagłówka kolumny Cło.
Lista zamówień: dodana wyszukiwarka po numerze zamówienia, dostawcy, numerze przesyłki i numerze faktury.
Lista zamówień: sortowanie według ID malejąco, najnowsze zamówienia na górze.
Podgląd zamówienia: nawigacja poprzednie/następne działa po najbliższym niższym i wyższym ID, także przy lukach w numeracji.
Tabela produktów w zamówieniu: waga pozycji jest pobierana z aktualnej wagi produktu i kombinacji zamiast z pustej lub nieaktualnej wartości rekordu zamówienia.
