<?php
declare(strict_types=1);

namespace PrestaShop\Module\PrestashopInventory\Controller\Admin;

require_once dirname(__DIR__, 3) . '/classes/PrestashopInventoryService.php';

use PrestaShopBundle\Security\Annotation\AdminSecurity;
use Symfony\Component\HttpFoundation\Response;

class PurchaseOrdersController extends AbstractInventoryController
{
    /**
     * @AdminSecurity("is_granted('read', request.get('_legacy_controller'))")
     */
    public function indexAction(): Response
    {
        $module = \Module::getInstanceByName('prestashopinventory');
        $purchaseOrders = [];

        if ($module instanceof \Module) {
            if ($module instanceof \PrestashopInventory) {
                $module->ensureTabsAvailable();
            }

            $service = new \PrestashopInventoryService($module->getLocalPath(), \Context::getContext(), $module);
            $purchaseOrders = $service->getPurchaseOrders();
        }

        return $this->renderInventoryPage(
            '@Modules/prestashopinventory/views/templates/admin-modern/purchase_orders.html.twig',
            'prestashop_inventory_purchase_orders',
            'purchase_orders_tab',
            [
                'purchaseOrders' => $purchaseOrders,
            ]
        );
    }
}
