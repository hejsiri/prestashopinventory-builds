<div class="inventory-module-content">
<div class="page-head-tabs inventory-panel-tabs" role="tablist" aria-label="{$inventoryTranslations.module_navigation|escape:'html':'UTF-8'}">
  <ul class="nav nav-pills">
    <li class="nav-item">
      <a href="{$inventoryModuleUrl|escape:'html':'UTF-8'}" class="nav-link" role="tab">{$inventoryTranslations.products_tab|escape:'html':'UTF-8'}</a>
    </li>
    <li class="nav-item">
      <a href="{$inventorySuppliersUrl|escape:'html':'UTF-8'}" class="router-link-active router-link-exact-active nav-link active" aria-current="page" role="tab">{$inventoryTranslations.suppliers_tab|escape:'html':'UTF-8'}</a>
    </li>
    <li class="nav-item">
      <a href="{$inventoryPurchaseOrdersUrl|escape:'html':'UTF-8'}" class="nav-link" role="tab">{$inventoryTranslations.purchase_orders_tab|escape:'html':'UTF-8'}</a>
    </li>
    <li class="nav-item">
      <a href="{$inventoryConfigUrl|escape:'html':'UTF-8'}" class="nav-link" role="tab">{$inventoryTranslations.settings_tab|escape:'html':'UTF-8'}</a>
    </li>
  </ul>
</div>

<div class="panel prestashopinventory-placeholder-panel">
  <h3 class="prestashopinventory-placeholder-title">{$inventoryPlaceholderTitle|escape:'html':'UTF-8'}</h3>
  <p class="prestashopinventory-placeholder-copy">{$inventoryPlaceholderDescription|escape:'html':'UTF-8'}</p>
  <div class="alert alert-info mb-0">{$inventoryPlaceholderNotice|escape:'html':'UTF-8'}</div>
</div>
</div>

<style>
  .prestashopinventory-placeholder-panel {
    border: 1px solid #dce7ef;
    border-radius: 0 20px 20px 20px;
    box-shadow: 0 14px 28px rgba(31, 52, 66, 0.10);
    padding: 24px 28px;
    background: #fff;
  }

  .prestashopinventory-placeholder-title {
    margin: 0 0 10px;
    font-size: 22px;
    font-weight: 700;
    color: #243746;
  }

  .prestashopinventory-placeholder-copy {
    margin: 0 0 18px;
    color: #5f7484;
  }
</style>
