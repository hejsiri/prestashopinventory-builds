<?php
declare(strict_types=1);

namespace PrestaShop\Module\PrestashopInventory\Controller\Admin;

require_once dirname(__DIR__, 3) . '/classes/PrestashopInventoryService.php';
require_once dirname(__DIR__, 3) . '/classes/PrestashopInventoryLicense.php';
require_once dirname(__DIR__, 3) . '/classes/PrestashopInventoryUpdater.php';

use PrestaShopBundle\Security\Annotation\AdminSecurity;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Response;

class WarehouseController extends AbstractInventoryController
{
    public const TAB_CLASS_NAME = 'AdminPrestashopInventory';

    /**
     * @AdminSecurity("is_granted('read', request.get('_legacy_controller'))")
     */
    public function indexAction(): Response
    {
        $module = \Module::getInstanceByName('prestashopinventory');
        $context = \Context::getContext();

        if ($module instanceof \PrestashopInventory) {
            $module->ensureTabsAvailable();
        }

        $dashboardUrl = $context->link->getAdminLink('AdminDashboard', true);
        $indexPos = strpos($dashboardUrl, 'index.php');
        $adminBase = $indexPos !== false
            ? substr($dashboardUrl, 0, $indexPos + strlen('index.php'))
            : $dashboardUrl;

        $legacyUrl = $adminBase . '?controller=AdminPrestashopInventory&token=' . rawurlencode(\Tools::getAdminTokenLite('AdminPrestashopInventory'));

        return new RedirectResponse($legacyUrl);
    }
}
