Poprawiono ikonę edycji produktu w tabeli Produkty: usunięto błąd JS renderScannerEan is not defined blokujący otwarcie popupu.
Dodano fallback renderowania EAN w popupie, gdy renderer kodu kreskowego nie jest dostępny.
