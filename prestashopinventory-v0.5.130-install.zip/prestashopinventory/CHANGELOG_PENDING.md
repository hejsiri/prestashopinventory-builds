# Wpisz tu zmiany do następnego release (jedna linia = jeden bullet)
# Przykład:
# Poprawa walidacji wymiarów w modalu produktu.
# Usunięcie znaku % z nagłówka kolumny Cło.
Poprawa wyrównania sekcji Sprzedawca, Nabywca i Szczegóły w PDF zamówienia.
