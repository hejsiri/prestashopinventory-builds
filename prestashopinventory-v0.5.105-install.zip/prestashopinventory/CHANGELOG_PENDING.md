Wyrównane przyciski w formularzu dodawania plików do zamówienia.
Zmniejszona domyślna wysokość przycisków w formularzu dodawania plików dla lżejszego wyglądu.
