<div class="inventory-module-content{if !empty($prestashopInventoryEmbeddedInModernLayout)} inventory-module-content--embedded{/if}">
{if empty($prestashopInventoryEmbeddedInModernLayout)}
<div id="psinventory-config-head-tabs-source" class="page-head-tabs inventory-panel-tabs" role="tablist" aria-label="{$prestashopInventoryTranslations.module_navigation|escape:'html':'UTF-8'}">
  <ul class="nav nav-pills">
    <li class="nav-item">
      <a href="{$prestashopInventoryBackUrl|escape:'html':'UTF-8'}" class="nav-link" role="tab"><span class="inventory-tab-link-content"><span class="menu-icon material-icons" aria-hidden="true">list_alt</span><span>{$prestashopInventoryTranslations.products_tab|escape:'html':'UTF-8'}</span></span></a>
    </li>
    <li class="nav-item">
      <a href="{$prestashopInventorySuppliersUrl|escape:'html':'UTF-8'}" class="nav-link" role="tab"><span class="inventory-tab-link-content"><span class="menu-icon material-icons" aria-hidden="true">local_shipping</span><span>{$prestashopInventoryTranslations.suppliers_tab|escape:'html':'UTF-8'}</span></span></a>
    </li>
    <li class="nav-item">
      <a href="{$prestashopInventoryPurchaseOrdersUrl|escape:'html':'UTF-8'}" class="nav-link" role="tab"><span class="inventory-tab-link-content"><span class="menu-icon material-icons" aria-hidden="true">inventory_2</span><span>{$prestashopInventoryTranslations.purchase_orders_tab|escape:'html':'UTF-8'}</span></span></a>
    </li>
    <li class="nav-item">
      <a href="{$prestashopInventoryConfigAction|escape:'html':'UTF-8'}" class="router-link-active router-link-exact-active nav-link active" aria-current="page" role="tab"><span class="inventory-tab-link-content"><span class="menu-icon material-icons" aria-hidden="true">settings</span><span>{$prestashopInventoryTranslations.settings_tab|escape:'html':'UTF-8'}</span></span></a>
    </li>
  </ul>
  <div class="inventory-update-meta">
    <div class="inventory-update-meta-status"></div>
  </div>
</div>
{/if}
{foreach from=$prestashopInventoryMessages item=message}
  <div class="alert alert-success">{$message|escape:'html':'UTF-8'}</div>
{/foreach}

{foreach from=$prestashopInventoryErrors item=errorMessage}
  <div class="alert alert-danger">{$errorMessage|escape:'html':'UTF-8'}</div>
{/foreach}

<div class="card js-grid-panel prestashopinventory-config-list">
  <div class="card-header js-grid-header">
    <h3 class="d-inline-block card-header-title">Informacje o module</h3>
  </div>
  <div class="card-body">
    <table class="psinv-info-table">
      <tr><td class="psinv-info-label">Wersja</td><td>{$prestashopInventoryModuleVersion|escape:'html':'UTF-8'}</td></tr>
      <tr><td class="psinv-info-label">Licencja dla</td><td>{$prestashopInventoryLicenseSummary.customer|escape:'html':'UTF-8'}</td></tr>
      <tr><td class="psinv-info-label">Domena</td><td>{$prestashopInventoryLicenseSummary.domain|escape:'html':'UTF-8'}</td></tr>
      <tr><td class="psinv-info-label">Wygasa</td><td>{$prestashopInventoryLicenseSummary.expires_at|escape:'html':'UTF-8'}</td></tr>
    </table>
    {if !$prestashopInventoryLicenseStatus.valid}
      <div class="alert alert-danger mt-3" role="alert">
        <strong>{$prestashopInventoryTranslations.license_required_title|escape:'html':'UTF-8'}:</strong>
        <span>{$prestashopInventoryLicenseStatus.message|escape:'html':'UTF-8'}</span>
      </div>
    {/if}
  </div>
</div>

<div class="card js-grid-panel prestashopinventory-config-list">
  <div class="card-header js-grid-header">
    <h3 class="d-inline-block card-header-title">Lista ukrytych produktów</h3>
  </div>
  <div class="card-body">
    {if $prestashopInventoryIgnoredProducts}
      <div class="table-responsive-row clearfix">
        <table class="grid-table js-grid-table table">
          <thead class="thead-default">
            <tr>
              <th>ID</th>
              <th>{$prestashopInventoryTranslations.image|escape:'html':'UTF-8'}</th>
              <th>{$prestashopInventoryTranslations.product_name|escape:'html':'UTF-8'}</th>
              <th>{$prestashopInventoryTranslations.ean13|escape:'html':'UTF-8'}</th>
              <th class="text-center">{$prestashopInventoryTranslations.displayed|escape:'html':'UTF-8'}</th>
              <th class="text-center">{$prestashopInventoryTranslations.actions|escape:'html':'UTF-8'}</th>
            </tr>
          </thead>
          <tbody>
            {foreach from=$prestashopInventoryIgnoredProducts item=product}
              <tr>
                <td>{$product.id_product|intval}</td>
                <td>
                  {if $product.image_url}
                    <img src="{$product.image_url|escape:'html':'UTF-8'}" alt="" class="img-thumbnail">
                  {else}
                    <span class="text-muted">{$prestashopInventoryTranslations.no_image|escape:'html':'UTF-8'}</span>
                  {/if}
                </td>
                <td>{$product.product_name|escape:'html':'UTF-8'}</td>
                <td>{$product.ean13|escape:'html':'UTF-8'}</td>
                <td class="text-center">
                  <div class="ps-switch ps-switch-sm ps-switch-nolabel ps-switch-center">
                    <input type="radio" name="hidden_product_active_{$product.id_product|intval}" id="hidden_product_active_{$product.id_product|intval}_off" value="0" {if !$product.active}checked{/if} disabled>
                    <label for="hidden_product_active_{$product.id_product|intval}_off">Off</label>
                    <input type="radio" name="hidden_product_active_{$product.id_product|intval}" id="hidden_product_active_{$product.id_product|intval}_on" value="1" {if $product.active}checked{/if} disabled>
                    <label for="hidden_product_active_{$product.id_product|intval}_on">On</label>
                    <span class="slide-button"></span>
                  </div>
                </td>
                <td class="text-center">
                  <form method="post" action="{$prestashopInventoryConfigAction|escape:'html':'UTF-8'}" class="mb-0">
                    <input type="hidden" name="id_product" value="{$product.id_product|intval}">
                    <button type="submit" name="submitPrestashopInventoryRestoreHidden" class="btn btn-link btn-sm p-0" title="{$prestashopInventoryTranslations.restore|escape:'html':'UTF-8'}"><i class="material-icons" style="font-size:18px;color:#25B9D7;">replay</i></button>
                  </form>
                </td>
              </tr>
            {/foreach}
          </tbody>
        </table>
      </div>
    {else}
      <p class="alert alert-info">{$prestashopInventoryTranslations.hidden_products_empty|escape:'html':'UTF-8'}</p>
    {/if}
  </div>
</div>

<div class="card js-grid-panel prestashopinventory-config-list" id="psinvCarrierPanel">
  <div class="card-header js-grid-header">
    <div class="prestashopinventory-order-status-panel-head">
      <h3 class="d-inline-block card-header-title">Przewoźnicy</h3>
      <button type="button" class="btn btn-primary" id="psinvAddCarrierBtn"><i class="material-icons" style="font-size:16px;vertical-align:text-bottom;">add</i> Dodaj przewoźnika</button>
    </div>
  </div>
  <div class="card-body">
    <div class="table-responsive">
      <table class="table mb-0 prestashopinventory-order-status-table" id="psinvCarrierTable">
        <thead class="thead-default">
          <tr>
            <th>Nazwa</th>
            <th class="text-right" style="width:40px;"></th>
          </tr>
        </thead>
        <tbody id="psinvCarrierRows">
          {foreach from=$prestashopInventoryCarriers item=carrier}
            <tr data-psinv-carrier-id="{$carrier.id|intval}">
              <td class="psinv-inline-name-cell">
                <span class="psinv-inline-name-label" tabindex="0" role="button">{$carrier.name|escape:'html':'UTF-8'}</span>
              </td>
              <td class="text-right" style="white-space:nowrap;">
                <button type="button" class="btn btn-link btn-sm p-0 psinv-delete-carrier-btn" title="Usuń"><i class="material-icons" style="font-size:18px;">delete</i></button>
              </td>
            </tr>
          {/foreach}
        </tbody>
      </table>
    </div>
    <div id="psinvCarrierMsg" class="mt-2" style="min-height:1.4em;"></div>
  </div>
</div>

<div class="card js-grid-panel prestashopinventory-config-list" id="psinvDocTypePanel">
  <div class="card-header js-grid-header">
    <div class="prestashopinventory-order-status-panel-head">
      <h3 class="d-inline-block card-header-title">Rodzaje dokumentów</h3>
      <button type="button" class="btn btn-primary" id="psinvAddDocTypeBtn"><i class="material-icons" style="font-size:16px;vertical-align:text-bottom;">add</i> Dodaj rodzaj</button>
    </div>
  </div>
  <div class="card-body">
    <div class="table-responsive">
      <table class="table mb-0 prestashopinventory-order-status-table" id="psinvDocTypeTable">
        <thead class="thead-default">
          <tr>
            <th>Nazwa</th>
            <th class="text-right" style="width:40px;"></th>
          </tr>
        </thead>
        <tbody id="psinvDocTypeRows">
          {foreach from=$prestashopInventoryDocumentTypes item=doctype}
            <tr data-psinv-doctype-id="{$doctype.id|intval}">
              <td class="psinv-inline-name-cell">
                <span class="psinv-inline-name-label" tabindex="0" role="button">{$doctype.name|escape:'html':'UTF-8'}</span>
              </td>
              <td class="text-right" style="white-space:nowrap;">
                <button type="button" class="btn btn-link btn-sm p-0 psinv-delete-doctype-btn" title="Usuń"><i class="material-icons" style="font-size:18px;">delete</i></button>
              </td>
            </tr>
          {/foreach}
        </tbody>
      </table>
    </div>
    <div id="psinvDocTypeMsg" class="mt-2" style="min-height:1.4em;"></div>
  </div>
</div>

<form method="post" action="{$prestashopInventoryConfigAction|escape:'html':'UTF-8'}" class="prestashopinventory-settings-form">
  <div class="card js-grid-panel prestashopinventory-config-list">
    <div class="card-header js-grid-header">
      <h3 class="d-inline-block card-header-title">Ustawienia zamówień</h3>
    </div>
    <div class="card-body">
      <div class="form-group">
        <label for="prestashopInventoryDeliveryAddress">Adres dostawy</label>
        <textarea
          id="prestashopInventoryDeliveryAddress"
          name="prestashopInventoryDeliveryAddress"
          class="form-control"
          rows="5"
          placeholder="Wpisz domyślny adres dostawy dla zamówień"
        >{$prestashopInventoryDeliveryAddress|escape:'html':'UTF-8'}</textarea>
      </div>
      <button type="submit" name="submitPrestashopInventorySaveOrderSettings" class="btn btn-primary">
        Zapisz adres dostawy
      </button>
    </div>
  </div>
</form>

<div class="card js-grid-panel prestashopinventory-config-list" id="psinvStatusPanel">
  <div class="card-header js-grid-header">
    <div class="prestashopinventory-order-status-panel-head">
      <div>
        <h3 class="d-inline-block card-header-title">Statusy zamówień</h3>
        <p class="text-muted mb-0">Kolejność z tej listy będzie używana na osi statusów oraz w zmianie statusu zamówienia.</p>
      </div>
      <button type="button" class="btn btn-primary" id="psinvAddStatusBtn"><i class="material-icons" style="font-size:16px;vertical-align:text-bottom;">add</i> Dodaj status</button>
    </div>
  </div>
  <div class="card-body">
    <div class="table-responsive">
      <table class="table mb-0 prestashopinventory-order-status-table">
        <thead class="thead-default">
          <tr>
            <th>Status</th>
            <th>Kolor</th>
            <th>Podgląd</th>
            <th class="text-right" style="width:40px;"></th>
          </tr>
        </thead>
        <tbody id="psinvStatusRows">
          {foreach from=$prestashopInventoryOrderStatuses item=status}
            <tr data-psinv-status-key="{$status.key|escape:'html':'UTF-8'}">
              <td class="psinv-inline-name-cell">
                <span class="psinv-inline-name-label" tabindex="0" role="button">{$status.label|escape:'html':'UTF-8'}</span>
              </td>
              <td>
                <div class="psinv-status-swatches-row">
                  <span class="psinv-status-swatch{if $status.color == '#E74C3C'} psinv-swatch-active{/if}" data-color="#E74C3C" style="background:#E74C3C" title="Czerwony"></span>
                  <span class="psinv-status-swatch{if $status.color == '#E67E22'} psinv-swatch-active{/if}" data-color="#E67E22" style="background:#E67E22" title="Pomarańczowy"></span>
                  <span class="psinv-status-swatch{if $status.color == '#F1C40F'} psinv-swatch-active{/if}" data-color="#F1C40F" style="background:#F1C40F" title="Żółty"></span>
                  <span class="psinv-status-swatch{if $status.color == '#27AE60'} psinv-swatch-active{/if}" data-color="#27AE60" style="background:#27AE60" title="Zielony"></span>
                  <span class="psinv-status-swatch{if $status.color == '#1ABC9C'} psinv-swatch-active{/if}" data-color="#1ABC9C" style="background:#1ABC9C" title="Turkusowy"></span>
                  <span class="psinv-status-swatch{if $status.color == '#2980B9'} psinv-swatch-active{/if}" data-color="#2980B9" style="background:#2980B9" title="Niebieski"></span>
                  <span class="psinv-status-swatch{if $status.color == '#8E44AD'} psinv-swatch-active{/if}" data-color="#8E44AD" style="background:#8E44AD" title="Fioletowy"></span>
                  <span class="psinv-status-swatch{if $status.color == '#95A5A6'} psinv-swatch-active{/if}" data-color="#95A5A6" style="background:#95A5A6" title="Szary"></span>
                  <span class="psinv-status-swatch{if $status.color == '#2C3E50'} psinv-swatch-active{/if}" data-color="#2C3E50" style="background:#2C3E50" title="Ciemny"></span>
                </div>
              </td>
              <td>
                <span class="badge psinv-status-preview" style="{$status.badge_style|escape:'html':'UTF-8'}">{$status.label|escape:'html':'UTF-8'}</span>
              </td>
              <td class="text-right" style="white-space:nowrap;">
                <button type="button" class="btn btn-link btn-sm p-0 psinv-delete-status-btn" title="Usuń"><i class="material-icons" style="font-size:18px;">delete</i></button>
              </td>
            </tr>
          {/foreach}
        </tbody>
      </table>
    </div>
    <div id="psinvStatusMsg" class="mt-2" style="min-height:1.4em;"></div>
  </div>
</div>
</div>

<style>
  .inventory-module-content {
    padding-top: 60px;
    clear: both;
    position: relative;
  }

  .inventory-module-content--embedded {
    padding-top: 0;
  }

  .inventory-panel-tabs {
    margin: 0;
  }

  .page-head > .inventory-panel-tabs {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 14px;
    min-height: 58px;
    margin: 0;
    padding: 0;
    border-top: 1px solid #eaebec;
    border-bottom: 1px solid #eaebec;
    background: #fff;
    box-shadow: none;
  }

  .page-head > .inventory-panel-tabs .nav.nav-pills {
    display: flex;
    flex: 1 1 auto;
    align-self: stretch;
    gap: 0;
    margin: 0;
    padding: 0;
  }

  .page-head > .inventory-panel-tabs .nav-item {
    display: flex;
    margin: 0;
  }

  .page-head > .inventory-panel-tabs .nav-link {
    position: relative;
    display: inline-flex;
    align-items: center;
    margin: 0;
    min-height: 56px;
    padding: 0 1.6rem;
    border: 0;
    border-radius: 0;
    background: transparent;
    color: #6c868e;
    font-size: 0.95rem;
    font-weight: 400;
    line-height: 1.3;
    transition: color .2s ease, background-color .2s ease;
    box-shadow: none;
  }

  .page-head > .inventory-panel-tabs .inventory-tab-link-content {
    display: inline-flex;
    align-items: center;
    gap: 12px;
  }

  .page-head > .inventory-panel-tabs .inventory-tab-link-content .menu-icon.material-icons {
    width: 22px;
    height: 22px;
    font-size: 22px;
    line-height: 1;
  }

  .page-head > .inventory-panel-tabs .nav-link:hover,
  .page-head > .inventory-panel-tabs .nav-link:focus {
    background: #fff;
    color: #25b9d7;
    box-shadow: none;
  }

  .page-head > .inventory-panel-tabs .nav-link::after {
    content: "";
    position: absolute;
    right: 0;
    bottom: 0;
    left: 0;
    height: 3px;
    background: #25b9d7;
    opacity: 0;
    transition: opacity .2s ease;
  }

  .page-head > .inventory-panel-tabs .nav-link:hover::after,
  .page-head > .inventory-panel-tabs .nav-link:focus::after,
  .page-head > .inventory-panel-tabs .nav-link.active::after,
  .page-head > .inventory-panel-tabs .nav-link[aria-current="page"]::after {
    opacity: 1;
  }

  .page-head > .inventory-panel-tabs .nav-link.active,
  .page-head > .inventory-panel-tabs .nav-link[aria-current="page"] {
    background: #eef8fd;
    color: #363a41;
    font-weight: 400;
    box-shadow: none;
  }

  .page-head > .inventory-panel-tabs .inventory-update-meta {
    display: flex;
    flex: 0 0 260px;
    align-items: center;
    justify-content: center;
    min-height: 56px;
    height: 56px;
    margin: 0 18px 0 0;
    text-align: right;
    overflow: hidden;
  }

  .page-head > .inventory-panel-tabs .inventory-update-meta-status {
    display: block;
    width: 100%;
    margin: 0;
    padding: 0;
    border: 0;
    background: transparent;
    font-size: 11px;
    font-weight: 600;
    color: #7a8f9d;
    line-height: 1.25;
    min-height: 0;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  @media (max-width: 1100px) {
    .page-head > .inventory-panel-tabs .inventory-update-meta {
      flex-basis: 180px;
      margin-right: 12px;
    }
  }

  @media (max-width: 920px) {
    .page-head > .inventory-panel-tabs .inventory-update-meta {
      display: none;
    }
  }

  .prestashopinventory-config-list.card {
    margin-bottom: 1rem;
    margin-top: 0 !important;
  }

  .prestashopinventory-config-list .card-header {
    padding: 1rem 1.25rem;
  }

  .prestashopinventory-config-list .card-body {
    padding: 20px 28px 24px;
  }

  .psinv-info-table {
    border-collapse: collapse;
  }

  .psinv-info-table td {
    padding: 3px 16px 3px 0;
    vertical-align: top;
    font-size: 14px;
    color: #243746;
  }

  .psinv-info-table .psinv-info-label {
    color: #6f8796;
    white-space: nowrap;
  }

  .prestashopinventory-config-list table {
    margin-bottom: 0;
  }

  .prestashopinventory-config-list .table-responsive-row {
    overflow-x: auto;
  }

  .prestashopinventory-config-list .img-thumbnail {
    width: 45px;
    height: 45px;
    object-fit: cover;
    padding: 2px;
  }

  .prestashopinventory-config-list .ps-switch {
    display: inline-block;
  }

  .prestashopinventory-settings-form {
    margin: 0;
  }

  .prestashopinventory-order-status-panel-head {
    display: flex;
    flex-wrap: wrap;
    align-items: flex-start;
    justify-content: space-between;
    gap: 12px;
  }

  .prestashopinventory-settings-subtitle {
    margin: 0 0 4px;
    font-size: 16px;
    font-weight: 600;
    color: #363a41;
  }

  .prestashopinventory-order-status-table th,
  .prestashopinventory-order-status-row td {
    vertical-align: middle;
  }

  .prestashopinventory-status-color-field {
    display: block;
  }

  .prestashopinventory-status-color-line {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    gap: 10px;
  }

  .prestashopinventory-status-color-text {
    width: 110px;
    min-width: 110px;
    text-transform: uppercase;
    letter-spacing: 0.03em;
  }

  .prestashopinventory-status-swatches {
    display: inline-flex;
    flex-wrap: wrap;
    gap: 6px;
  }

  .prestashopinventory-order-status-actions {
    width: 1%;
    text-align: right;
    white-space: nowrap;
  }

  .prestashopinventory-order-status-preview-cell {
    white-space: nowrap;
  }

  .prestashopinventory-status-choice {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    margin: 0;
    cursor: pointer;
  }

  .prestashopinventory-status-choice-input {
    position: absolute;
    opacity: 0;
    pointer-events: none;
  }

  .prestashopinventory-status-swatch {
    width: 22px;
    height: 22px;
    border: 2px solid #d4dde3;
    border-radius: 50%;
    padding: 0;
    box-shadow: none;
    cursor: pointer;
    transition: transform 0.15s ease, border-color 0.15s ease;
  }

  .prestashopinventory-status-swatch:hover,
  .prestashopinventory-status-swatch:focus {
    transform: scale(1.08);
    border-color: #363a41;
    outline: none;
  }

  .prestashopinventory-status-choice-input:checked + .prestashopinventory-status-swatch,
  .prestashopinventory-status-choice-input:checked + .prestashopinventory-status-choice-label {
    border-color: #363a41;
    box-shadow: 0 0 0 2px rgba(54, 58, 65, 0.16);
  }

  .prestashopinventory-status-choice-label {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-width: 42px;
    height: 22px;
    padding: 0 8px;
    border: 2px solid #d4dde3;
    border-radius: 999px;
    background: #fff;
    color: #5d7178;
    font-size: 11px;
    font-weight: 700;
    line-height: 1;
  }

  .psinv-inline-name-label {
    cursor: pointer;
    border-bottom: 1px dashed #aaa;
    display: inline-block;
  }

  .psinv-inline-name-label:hover {
    border-bottom-color: #25B9D7;
    color: #25B9D7;
  }

  .psinv-status-swatches-row {
    display: inline-flex;
    flex-wrap: wrap;
    gap: 5px;
    align-items: center;
  }

  .psinv-status-swatch {
    width: 22px;
    height: 22px;
    border-radius: 50%;
    border: 2px solid transparent;
    cursor: pointer;
    display: inline-block;
    transition: transform 0.13s, border-color 0.13s, box-shadow 0.13s;
    box-sizing: border-box;
  }

  .psinv-status-swatch:hover {
    transform: scale(1.1);
    border-color: #363a41;
  }

  .psinv-status-swatch.psinv-swatch-active {
    border-color: #363a41;
    box-shadow: 0 0 0 2px rgba(54,58,65,0.18);
  }
</style>

<script>
  // Carriers & Document Types + Status AJAX management — legacy status form removed

  (function () {
    var ajaxUrl = '{$prestashopInventoryAjaxUrl|escape:'javascript':'UTF-8'}';

    function showCrudMsg(el, msg, isError) {
      el.textContent = msg;
      el.style.color = isError ? '#c0392b' : '#27ae60';
      setTimeout(function () { el.textContent = ''; }, 3000);
    }

    function saveItem(tr, rowAttr, nameInput, saveAction, responseKey, msgEl, onSuccess) {
      var id = parseInt(tr.getAttribute('data-' + rowAttr) || '0', 10);
      var name = nameInput.value.trim();
      if (name === '') { showCrudMsg(msgEl, 'Nazwa nie może być pusta.', true); nameInput.focus(); return; }
      nameInput.disabled = true;
      var fd = new FormData();
      fd.append('id', String(id));
      fd.append('name', name);
      fetch(ajaxUrl + '&action=' + saveAction, { method: 'POST', body: fd })
        .then(function (r) { return r.json(); })
        .then(function (data) {
          nameInput.disabled = false;
          if (data.ok) {
            var newId = (data[responseKey] && data[responseKey].id) ? data[responseKey].id : id;
            tr.setAttribute('data-' + rowAttr, String(newId));
            showCrudMsg(msgEl, 'Zapisano.', false);
            if (onSuccess) { onSuccess(name); }
          } else {
            showCrudMsg(msgEl, data.error || 'Błąd.', true);
          }
        })
        .catch(function () { nameInput.disabled = false; showCrudMsg(msgEl, 'Błąd sieci.', true); });
    }

    function startInlineEdit(tr, rowAttr, saveAction, responseKey, msgEl) {
      var cell = tr.querySelector('.psinv-inline-name-cell');
      if (!cell || cell.querySelector('input')) { return; }
      var span = cell.querySelector('.psinv-inline-name-label');
      var originalName = span ? span.textContent.trim() : '';
      if (span) { span.style.display = 'none'; }
      var input = document.createElement('input');
      input.type = 'text';
      input.className = 'form-control form-control-sm';
      input.value = originalName;
      input.style.maxWidth = '400px';
      cell.appendChild(input);
      input.focus();
      input.select();

      function commit() {
        saveItem(tr, rowAttr, input, saveAction, responseKey, msgEl, function (name) {
          if (span) { span.textContent = name; }
          closeEdit(true);
        });
      }

      function closeEdit(saved) {
        if (input.parentNode) { input.parentNode.removeChild(input); }
        if (span) { span.style.display = ''; }
        if (!saved && span) { span.textContent = originalName; }
      }

      input.addEventListener('keydown', function (e) {
        if (e.key === 'Enter') { e.preventDefault(); commit(); }
        if (e.key === 'Escape') { closeEdit(false); }
      });

      input.addEventListener('blur', function () {
        window.setTimeout(function () {
          if (document.activeElement !== input && input.parentNode) { closeEdit(false); }
        }, 150);
      });
    }

    function bindCrudPanel(opts) {
      var addBtn = document.getElementById(opts.addBtnId);
      var tbody = document.getElementById(opts.tbodyId);
      var msgEl = document.getElementById(opts.msgId);
      if (!addBtn || !tbody || !msgEl) { return; }

      // Add new row — immediately show input
      addBtn.addEventListener('click', function () {
        var tr = document.createElement('tr');
        tr.setAttribute('data-' + opts.rowAttr, '0');
        tr.innerHTML =
          '<td class="psinv-inline-name-cell">' +
            '<input type="text" class="form-control form-control-sm psinv-new-name-input" placeholder="' + opts.placeholder + '" style="max-width:400px;">' +
          '</td>' +
          '<td class="text-right" style="white-space:nowrap;">' +
            '<button type="button" class="btn btn-link btn-sm p-0 ' + opts.deleteClass + '" title="Usuń"><i class="material-icons" style="font-size:18px;">delete</i></button>' +
          '</td>';
        tbody.appendChild(tr);
        var input = tr.querySelector('.psinv-new-name-input');
        input.focus();

        function commitNew() {
          saveItem(tr, opts.rowAttr, input, opts.saveAction, opts.responseKey, msgEl, function (name) {
            // Replace input with span
            var cell = tr.querySelector('.psinv-inline-name-cell');
            if (input.parentNode) { input.parentNode.removeChild(input); }
            var span = document.createElement('span');
            span.className = 'psinv-inline-name-label';
            span.setAttribute('tabindex', '0');
            span.setAttribute('role', 'button');
            span.textContent = name;
            cell.appendChild(span);
          });
        }

        input.addEventListener('keydown', function (e) {
          if (e.key === 'Enter') { e.preventDefault(); commitNew(); }
          if (e.key === 'Escape') { tr.parentNode && tr.parentNode.removeChild(tr); }
        });
      });

      // Inline edit on span click
      tbody.addEventListener('click', function (e) {
        var span = e.target && e.target.closest ? e.target.closest('.psinv-inline-name-label') : null;
        if (span) {
          var tr = span.closest('tr');
          if (tr) { startInlineEdit(tr, opts.rowAttr, opts.saveAction, opts.responseKey, msgEl); }
          return;
        }

        var deleteBtn = e.target && e.target.closest ? e.target.closest('.' + opts.deleteClass) : null;
        if (deleteBtn) {
          var tr = deleteBtn.closest('tr');
          var id = parseInt(tr.getAttribute('data-' + opts.rowAttr) || '0', 10);
          if (id === 0) { tr.parentNode.removeChild(tr); return; }
          if (!confirm('Usunąć?')) { return; }
          deleteBtn.disabled = true;
          var fd = new FormData();
          fd.append('id', String(id));
          fetch(ajaxUrl + '&action=' + opts.deleteAction, { method: 'POST', body: fd })
            .then(function (r) { return r.json(); })
            .then(function (data) {
              if (data.ok) { tr.parentNode.removeChild(tr); showCrudMsg(msgEl, 'Usunięto.', false); }
              else { deleteBtn.disabled = false; showCrudMsg(msgEl, data.error || 'Błąd.', true); }
            })
            .catch(function () { deleteBtn.disabled = false; showCrudMsg(msgEl, 'Błąd sieci.', true); });
        }
      });

      tbody.addEventListener('keydown', function (e) {
        if (e.key === 'Enter' || e.key === ' ') {
          var span = e.target && e.target.classList && e.target.classList.contains('psinv-inline-name-label') ? e.target : null;
          if (span) {
            e.preventDefault();
            var tr = span.closest('tr');
            if (tr) { startInlineEdit(tr, opts.rowAttr, opts.saveAction, opts.responseKey, msgEl); }
          }
        }
      });
    }

    bindCrudPanel({
      addBtnId: 'psinvAddCarrierBtn',
      tbodyId: 'psinvCarrierRows',
      msgId: 'psinvCarrierMsg',
      rowAttr: 'psinv-carrier-id',
      deleteClass: 'psinv-delete-carrier-btn',
      placeholder: 'Nazwa przewoźnika',
      saveAction: 'SaveCarrier',
      deleteAction: 'DeleteCarrier',
      responseKey: 'carrier',
    });

    bindCrudPanel({
      addBtnId: 'psinvAddDocTypeBtn',
      tbodyId: 'psinvDocTypeRows',
      msgId: 'psinvDocTypeMsg',
      rowAttr: 'psinv-doctype-id',
      deleteClass: 'psinv-delete-doctype-btn',
      placeholder: 'Nazwa rodzaju dokumentu',
      saveAction: 'SaveDocumentType',
      deleteAction: 'DeleteDocumentType',
      responseKey: 'document_type',
    });

    // ── Status panel ─────────────────────────────────────────────────────────
    (function () {
      var addBtn  = document.getElementById('psinvAddStatusBtn');
      var tbody   = document.getElementById('psinvStatusRows');
      var msgEl   = document.getElementById('psinvStatusMsg');
      if (!addBtn || !tbody || !msgEl) { return; }

      var PRESETS = [
        { value: '#E74C3C', title: 'Czerwony' },
        { value: '#E67E22', title: 'Pomarańczowy' },
        { value: '#F1C40F', title: 'Żółty' },
        { value: '#27AE60', title: 'Zielony' },
        { value: '#1ABC9C', title: 'Turkusowy' },
        { value: '#2980B9', title: 'Niebieski' },
        { value: '#8E44AD', title: 'Fioletowy' },
        { value: '#95A5A6', title: 'Szary' },
        { value: '#2C3E50', title: 'Ciemny' },
      ];
      var DEFAULT_COLOR = '#2980B9';

      function escH(s) {
        return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
      }

      function buildSwatchesHtml(activeColor) {
        return PRESETS.map(function (p) {
          var active = p.value.toUpperCase() === (activeColor || '').toUpperCase() ? ' psinv-swatch-active' : '';
          return '<span class="psinv-status-swatch' + active + '" data-color="' + p.value + '" style="background:' + p.value + '" title="' + p.title + '"></span>';
        }).join('');
      }

      function getRowColor(tr) {
        var active = tr.querySelector('.psinv-status-swatch.psinv-swatch-active');
        return active ? active.getAttribute('data-color') : DEFAULT_COLOR;
      }

      function saveStatus(key, label, color, onSuccess) {
        var fd = new FormData();
        fd.append('key', key || '');
        fd.append('label', label);
        fd.append('color', color);
        fetch(ajaxUrl + '&action=SaveOrderStatus', { method: 'POST', body: fd })
          .then(function (r) { return r.json(); })
          .then(function (data) {
            if (data.ok && data.status) {
              onSuccess(data.status);
              showCrudMsg(msgEl, 'Zapisano.', false);
            } else {
              showCrudMsg(msgEl, data.error || 'Błąd.', true);
            }
          })
          .catch(function () { showCrudMsg(msgEl, 'Błąd sieci.', true); });
      }

      function applyStatusToRow(tr, status) {
        tr.setAttribute('data-psinv-status-key', status.key);
        var nameSpan = tr.querySelector('.psinv-inline-name-label');
        if (nameSpan) { nameSpan.textContent = status.label; }
        var swatchesDiv = tr.querySelector('.psinv-status-swatches-row');
        if (swatchesDiv) { swatchesDiv.innerHTML = buildSwatchesHtml(status.color); }
        var preview = tr.querySelector('.psinv-status-preview');
        if (preview) { preview.textContent = status.label; preview.style.cssText = status.badge_style; }
      }

      // Inline label edit
      tbody.addEventListener('click', function (e) {
        var span = e.target.closest('.psinv-inline-name-label');
        if (span) {
          var tr = span.closest('tr');
          if (!tr || tr.querySelector('input.psinv-status-label-input')) { return; }
          var originalName = span.textContent.trim();
          span.style.display = 'none';
          var input = document.createElement('input');
          input.type = 'text';
          input.className = 'form-control form-control-sm psinv-status-label-input';
          input.value = originalName;
          input.style.maxWidth = '300px';
          span.parentNode.appendChild(input);
          input.focus(); input.select();

          function commit() {
            var newLabel = input.value.trim();
            if (!newLabel) { cancel(); return; }
            var key = tr.getAttribute('data-psinv-status-key') || '';
            var color = getRowColor(tr);
            saveStatus(key, newLabel, color, function (status) { applyStatusToRow(tr, status); });
            cancel(true);
          }
          function cancel(saved) {
            if (input.parentNode) { input.parentNode.removeChild(input); }
            span.style.display = '';
            if (!saved) { span.textContent = originalName; }
          }
          input.addEventListener('keydown', function (ev) {
            if (ev.key === 'Enter') { ev.preventDefault(); commit(); }
            if (ev.key === 'Escape') { cancel(); }
          });
          input.addEventListener('blur', function () {
            window.setTimeout(function () { if (input.parentNode) { cancel(); } }, 150);
          });
          return;
        }

        // Swatch click
        var swatch = e.target.closest('.psinv-status-swatch');
        if (swatch) {
          var tr = swatch.closest('tr');
          if (!tr) { return; }
          var color = swatch.getAttribute('data-color') || DEFAULT_COLOR;
          var key = tr.getAttribute('data-psinv-status-key') || '';
          var label = (tr.querySelector('.psinv-inline-name-label') || {}).textContent || '';
          label = label.trim();
          saveStatus(key, label, color, function (status) { applyStatusToRow(tr, status); });
          return;
        }

        // Delete
        var delBtn = e.target.closest('.psinv-delete-status-btn');
        if (delBtn) {
          var tr = delBtn.closest('tr');
          var key = tr ? tr.getAttribute('data-psinv-status-key') : '';
          if (!key) { if (tr && tr.parentNode) { tr.parentNode.removeChild(tr); } return; }
          if (!confirm('Usunąć status?')) { return; }
          delBtn.disabled = true;
          var fd = new FormData();
          fd.append('key', key);
          fetch(ajaxUrl + '&action=DeleteOrderStatus', { method: 'POST', body: fd })
            .then(function (r) { return r.json(); })
            .then(function (data) {
              if (data.ok) { tr.parentNode.removeChild(tr); showCrudMsg(msgEl, 'Usunięto.', false); }
              else { delBtn.disabled = false; showCrudMsg(msgEl, data.error || 'Błąd.', true); }
            })
            .catch(function () { delBtn.disabled = false; showCrudMsg(msgEl, 'Błąd sieci.', true); });
          return;
        }
      });

      // Keyboard support for label spans
      tbody.addEventListener('keydown', function (e) {
        if (e.key === 'Enter' || e.key === ' ') {
          var span = e.target.classList && e.target.classList.contains('psinv-inline-name-label') ? e.target : null;
          if (span) { e.preventDefault(); span.click(); }
        }
      });

      // Add new status
      addBtn.addEventListener('click', function () {
        var color = DEFAULT_COLOR;
        var tr = document.createElement('tr');
        tr.setAttribute('data-psinv-status-key', '');
        tr.innerHTML =
          '<td class="psinv-inline-name-cell">' +
            '<input type="text" class="form-control form-control-sm psinv-new-status-input" placeholder="Nazwa statusu" style="max-width:300px;">' +
          '</td>' +
          '<td><div class="psinv-status-swatches-row">' + buildSwatchesHtml(color) + '</div></td>' +
          '<td><span class="badge psinv-status-preview" style="background-color:' + color + ' !important;color:#fff !important;"></span></td>' +
          '<td class="text-right" style="white-space:nowrap;"><button type="button" class="btn btn-link btn-sm p-0 psinv-delete-status-btn" title="Usuń"><i class="material-icons" style="font-size:18px;">delete</i></button></td>';
        tbody.appendChild(tr);
        var input = tr.querySelector('.psinv-new-status-input');
        input.focus();

        // Local swatch selection before save
        tr.querySelector('.psinv-status-swatches-row').addEventListener('click', function (e2) {
          var sw = e2.target.closest('.psinv-status-swatch');
          if (!sw) { return; }
          color = sw.getAttribute('data-color') || DEFAULT_COLOR;
          tr.querySelectorAll('.psinv-status-swatch').forEach(function (s) { s.classList.remove('psinv-swatch-active'); });
          sw.classList.add('psinv-swatch-active');
          var preview = tr.querySelector('.psinv-status-preview');
          if (preview) { preview.style.cssText = 'background-color:' + color + ' !important;color:#fff !important;'; }
        });

        function commitNew() {
          var label = input.value.trim();
          if (!label) { return; }
          saveStatus('', label, color, function (status) {
            var cell = tr.querySelector('.psinv-inline-name-cell');
            if (input.parentNode) { input.parentNode.removeChild(input); }
            var span = document.createElement('span');
            span.className = 'psinv-inline-name-label';
            span.setAttribute('tabindex', '0');
            span.setAttribute('role', 'button');
            span.textContent = status.label;
            cell.appendChild(span);
            applyStatusToRow(tr, status);
          });
        }
        input.addEventListener('keydown', function (ev) {
          if (ev.key === 'Enter') { ev.preventDefault(); commitNew(); }
          if (ev.key === 'Escape') { if (tr.parentNode) { tr.parentNode.removeChild(tr); } }
        });
      });
    })();

  })();
</script>

{if empty($prestashopInventoryEmbeddedInModernLayout)}
<script>
  (function () {
    function syncBreadcrumb(currentLabel) {
      var breadcrumb = document.querySelector('.header-toolbar .breadcrumb');
      if (!breadcrumb) {
        return;
      }

      while (breadcrumb.firstChild) {
        breadcrumb.removeChild(breadcrumb.firstChild);
      }

      var catalogItem = document.createElement('li');
      catalogItem.className = 'breadcrumb-item';
      var catalogIcon = document.createElement('i');
      catalogIcon.className = 'material-icons';
      catalogIcon.textContent = 'store';
      catalogItem.appendChild(catalogIcon);
      catalogItem.appendChild(document.createTextNode('Katalog'));
      breadcrumb.appendChild(catalogItem);

      var moduleItem = document.createElement('li');
      moduleItem.className = 'breadcrumb-item';
      var moduleLink = document.createElement('a');
      moduleLink.href = '{$prestashopInventoryBackUrl|escape:'javascript'}';
      moduleLink.textContent = 'Inventory';
      moduleItem.appendChild(moduleLink);
      breadcrumb.appendChild(moduleItem);

      var currentItem = document.createElement('li');
      currentItem.className = 'breadcrumb-item active breadcrumb-item--inventory-current';
      var currentSpan = document.createElement('span');
      currentSpan.textContent = currentLabel;
      currentItem.appendChild(currentSpan);
      breadcrumb.appendChild(currentItem);
    }

    function getDirectContainerFluid(headerToolbar) {
      if (!headerToolbar) {
        return null;
      }

      var children = headerToolbar.children || [];
      for (var i = 0; i < children.length; i++) {
        if (children[i].classList && children[i].classList.contains('container-fluid')) {
          return children[i];
        }
      }

      return headerToolbar.querySelector('.container-fluid');
    }

    function mountBoTabs(sourceId, attempt) {
      var source = document.getElementById(sourceId);
      if (!source) {
        return true;
      }

      var pageHead = document.querySelector('.page-head');
      var pageHeadWrapper = pageHead ? pageHead.querySelector('.wrapper.clearfix') : null;
      if (!pageHead) {
        if ((attempt || 0) < 100) {
          window.setTimeout(function () {
            mountBoTabs(sourceId, (attempt || 0) + 1);
          }, 100);
          return false;
        }

        source.hidden = false;
        return false;
      }

      var mounted = document.getElementById('head_tabs');
      if (mounted && mounted !== source && mounted.parentNode) {
        mounted.parentNode.removeChild(mounted);
      }

      if (pageHeadWrapper) {
        if (source.parentNode !== pageHead || source.previousElementSibling !== pageHeadWrapper) {
          pageHeadWrapper.insertAdjacentElement('afterend', source);
        }
      } else if (source.parentNode !== pageHead) {
        pageHead.appendChild(source);
      }

      var contentDiv = document.querySelector('#main-div > .content-div');
      if (contentDiv) {
        contentDiv.classList.add('with-tabs');
      }

      syncBreadcrumb('Ustawienia');

      source.hidden = false;
      return true;
    }


    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', function () {
        mountBoTabs('psinventory-config-head-tabs-source', 0);
      });
    } else {
      mountBoTabs('psinventory-config-head-tabs-source', 0);
    }

    window.addEventListener('load', function () {
      mountBoTabs('psinventory-config-head-tabs-source', 0);
    });

    var mountObserver = new MutationObserver(function () {
      mountBoTabs('psinventory-config-head-tabs-source', 0);
    });
    mountObserver.observe(document.documentElement, {ldelim}childList: true, subtree: true{rdelim});
    window.setTimeout(function () {
      mountObserver.disconnect();
    }, 10000);
  })();
</script>
{/if}
