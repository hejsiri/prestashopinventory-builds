Dodano ikonę edycji produktu w kolumnie Akcje, otwierającą popup z danymi modułowymi.
Lista produktów przekazuje do popupu pełne dane dodatkowe (model modułowy, materiał, HS code, cło, opis, wymiary, waga kartonu).
Poprawiono paginację pod tabelą produktów: usunięto podwójne strzałki i wyśrodkowano pasek.
