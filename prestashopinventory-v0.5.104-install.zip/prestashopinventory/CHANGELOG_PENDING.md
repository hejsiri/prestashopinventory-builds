Poprawiony podgląd PDF w zamówieniach przez ładowanie dokumentu do modala z użyciem blob URL.
Ujednolicony układ formularza dodawania plików: pola i przyciski w jednej linii oraz spójna wysokość inputa i selecta.
Bardziej czytelna, wypełniona ikona PDF w widoku produktów.
