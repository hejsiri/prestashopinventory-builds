<div id="psinventory-head-tabs-source" class="page-head-tabs" role="tablist" aria-label="Nawigacja modułu">
  <ul class="nav nav-pills">
    <li class="nav-item">
      <a href="{$inventoryModuleUrl|escape:'html':'UTF-8'}" class="nav-link active" aria-current="page" role="tab">{$inventoryTranslations.warehouse_tab|escape:'html':'UTF-8'}</a>
    </li>
    <li class="nav-item">
      <a href="{$inventoryConfigUrl|escape:'html':'UTF-8'}" class="nav-link" role="tab">{$inventoryTranslations.settings_tab|escape:'html':'UTF-8'}</a>
    </li>
  </ul>
</div>

<div class="inventory-module-content">
<div class="panel prestashop-inventory">

  <div class="inventory-toolbar">
    <div class="inventory-actions">
      <div class="inventory-actions-menu inventory-filters-menu">
        <button class="inventory-actions-toggle inventory-filter-toggle" type="button" aria-haspopup="true" aria-expanded="false" aria-label="Filtry">
          <i class="icon-tasks"></i>
          <span id="filterActiveCount" class="inventory-filter-badge">0</span>
        </button>
        <div class="inventory-actions-dropdown inventory-filter-dropdown">
          <label class="inventory-switch-row inventory-filter-row">
            <span class="ios-switch">
              <input type="checkbox" id="activeOnly">
              <span class="slider"></span>
            </span>
            <span id="activeOnlyLabel"></span>
          </label>

          <label class="inventory-switch-row inventory-filter-row">
            <span class="ios-switch">
              <input type="checkbox" id="onlyAvailable">
              <span class="slider"></span>
            </span>
            <span id="onlyAvailableLabel"></span>
          </label>

          <label class="inventory-switch-row inventory-filter-row">
            <span class="ios-switch">
              <input type="checkbox" id="missingPurchasePriceOnly">
              <span class="slider"></span>
            </span>
            <span id="missingPurchasePriceOnlyLabel"></span>
          </label>

          <label class="inventory-switch-row inventory-filter-row">
            <span class="ios-switch">
              <input type="checkbox" id="showWeight" checked>
              <span class="slider"></span>
            </span>
            <span id="showWeightLabel"></span>
          </label>

          <label class="inventory-switch-row inventory-filter-row">
            <span class="ios-switch">
              <input type="checkbox" id="missingWeightOnly">
              <span class="slider"></span>
            </span>
            <span id="missingWeightOnlyLabel"></span>
          </label>

          <label class="inventory-switch-row inventory-filter-row">
            <span class="ios-switch">
              <input type="checkbox" id="showBrutto" checked>
              <span class="slider"></span>
            </span>
            <span id="showBruttoLabel"></span>
          </label>
        </div>
      </div>

      <button id="btnPdf" class="inventory-toolbar-btn" type="button">
        <i class="icon-file-pdf-o"></i> PDF
      </button>
    </div>
  </div>

  <div class="inventory-search">
    <div class="inventory-search-wrap">
      <div id="searchBox" class="inventory-tagbox">
        <div id="searchTags" class="inventory-tags"></div>
        <input type="text" id="searchInput" class="inventory-tag-input" autocomplete="off">
      </div>
      <button id="clearSearch" type="button" class="inventory-clear" aria-label="Clear">&times;</button>
    </div>
  </div>

  <div class="table-responsive-row clearfix">
    <table id="productsTable" class="table">
      <thead>
        <tr>
          <th id="thNo" class="inventory-sortable" data-sort-field="id_product"><button type="button" class="inventory-sort-button"><span class="inventory-head-title">ID</span><span class="inventory-sort-indicator"></span></button></th>
          <th id="thPicture">{$inventoryTranslations.image|escape:'html':'UTF-8'}</th>
          <th id="thName" class="inventory-sortable" data-sort-field="product_name"><button type="button" class="inventory-sort-button"><span><span class="inventory-head-title">{$inventoryTranslations.product_name|escape:'html':'UTF-8'}</span><span class="inventory-head-subtitle">EAN13</span></span><span class="inventory-sort-indicator"></span></button></th>
          <th id="thActive" class="text-center inventory-sortable" data-sort-field="active"><button type="button" class="inventory-sort-button inventory-sort-button-center"><span class="inventory-head-title">{$inventoryTranslations.active|escape:'html':'UTF-8'}</span><span class="inventory-sort-indicator"></span></button></th>
          <th id="thWeight" class="text-center inventory-sortable" data-sort-field="weight"><button type="button" class="inventory-sort-button inventory-sort-button-center"><span class="inventory-head-title">{$inventoryTranslations.product_weight|escape:'html':'UTF-8'}</span><span class="inventory-sort-indicator"></span></button></th>
          <th id="thPrice" class="text-center inventory-sortable" data-sort-field="purchase_price"><button type="button" class="inventory-sort-button inventory-sort-button-center"><span class="inventory-head-title">{$inventoryTranslations.purchase_price_net|escape:'html':'UTF-8'}</span><span class="inventory-sort-indicator"></span></button></th>
          <th id="thPriceBrutto" class="text-center inventory-sortable" data-sort-field="retail_price"><button type="button" class="inventory-sort-button inventory-sort-button-center"><span class="inventory-head-title">{$inventoryTranslations.retail_price_gross|escape:'html':'UTF-8'}</span><span class="inventory-sort-indicator"></span></button></th>
          <th id="thQty" class="text-center inventory-sortable" data-sort-field="quantity"><button type="button" class="inventory-sort-button inventory-sort-button-center"><span class="inventory-head-title">{$inventoryTranslations.available_quantity|escape:'html':'UTF-8'}</span><span class="inventory-sort-indicator"></span></button></th>
          <th id="thValue" class="text-center">{$inventoryTranslations.purchase_value_net|escape:'html':'UTF-8'}</th>
          <th id="thValueBrutto" class="text-center">{$inventoryTranslations.retail_value_gross|escape:'html':'UTF-8'}</th>
          <th id="thActions" class="text-center">{$inventoryTranslations.actions|escape:'html':'UTF-8'}</th>
        </tr>
      </thead>
      <tbody></tbody>
    </table>
  </div>

  <div id="inventoryPagination" class="inventory-pagination"></div>
</div>
</div>

<style>
  .inventory-module-content {
    margin-top: 16px;
  }

  .prestashop-inventory.panel {
    border: 1px solid #e5e5e5;
    box-shadow: none;
    padding: 28px 32px 24px;
  }

  .prestashop-inventory .inventory-toolbar {
    display: flex;
    justify-content: flex-end;
    gap: 16px;
    margin-bottom: 20px;
    align-items: center;
    flex-wrap: wrap;
  }

  .prestashop-inventory .inventory-actions {
    display: flex;
    gap: 16px;
    align-items: center;
    flex-wrap: wrap;
  }

  .prestashop-inventory .inventory-search {
    margin-bottom: 24px;
  }

  .prestashop-inventory .inventory-toolbar-btn {
    height: 38px;
    padding: 0 14px;
    border: 1px solid #111;
    border-radius: 0;
    background: #111;
    color: #fff;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    font-size: 14px;
    line-height: 1;
    text-decoration: none;
    box-shadow: none;
  }

  .prestashop-inventory .inventory-toolbar-btn:hover,
  .prestashop-inventory .inventory-toolbar-btn:focus {
    background: #111;
    color: #fff;
    text-decoration: none;
    opacity: .92;
  }

  .prestashop-inventory .inventory-toolbar-btn i {
    font-size: 14px;
    line-height: 1;
  }

  .prestashop-inventory .inventory-search-wrap {
    max-width: 720px;
    position: relative;
  }

  .prestashop-inventory .inventory-tagbox {
    min-height: 42px;
    padding: 6px 34px 6px 8px;
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    gap: 6px;
    cursor: text;
    border: 1px solid #bbcdd2;
    border-radius: 4px;
    background: #fff;
    box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
  }

  .prestashop-inventory .inventory-tagbox:focus-within {
    border-color: #25b9d7;
    box-shadow: 0 0 0 1px rgba(37, 185, 215, 0.2);
  }

  .prestashop-inventory .inventory-tags {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    gap: 6px;
  }

  .prestashop-inventory .inventory-tag {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 7px 12px;
    background: #f3f3f3;
    border-radius: 2px;
    font-weight: 600;
  }

  .prestashop-inventory .inventory-tag-remove {
    border: 0;
    background: transparent;
    padding: 0;
    line-height: 1;
    font-size: 24px;
    color: #333;
  }

  .prestashop-inventory .inventory-tag-input {
    flex: 1 1 140px;
    min-width: 120px;
    border: 0 !important;
    outline: none !important;
    box-shadow: none !important;
    -webkit-box-shadow: none !important;
    padding: 4px 0;
    margin: 0;
    background: transparent !important;
    appearance: none;
    -webkit-appearance: none;
    border-radius: 0;
  }

  .prestashop-inventory .inventory-tag-input:focus,
  .prestashop-inventory .inventory-tag-input:hover,
  .prestashop-inventory .inventory-tag-input:active {
    border: 0 !important;
    outline: none !important;
    box-shadow: none !important;
    -webkit-box-shadow: none !important;
    background: transparent !important;
  }

  .prestashop-inventory .inventory-clear {
    position: absolute;
    top: 50%;
    right: 8px;
    transform: translateY(-50%);
    border: 0;
    background: transparent;
    color: #888;
    font-size: 22px;
    line-height: 1;
    padding: 0;
  }

  .prestashop-inventory .ios-switch {
    position: relative;
    display: inline-block;
    width: 28px;
    height: 16px;
  }

  .prestashop-inventory .ios-switch input {
    opacity: 0;
    width: 0;
    height: 0;
  }

  .prestashop-inventory .slider {
    position: absolute;
    inset: 0;
    cursor: pointer;
    background-color: #ccc;
    border-radius: 25px;
    transition: .4s;
  }

  .prestashop-inventory .slider:before {
    content: "";
    position: absolute;
    width: 12px;
    height: 12px;
    top: 2px;
    left: 2px;
    background: #fff;
    border-radius: 50%;
    box-shadow: 0 1px 2px rgba(0, 0, 0, 0.18);
    transition: .2s ease;
  }

  .prestashop-inventory input:checked + .slider {
    background: #4f955d;
  }

  .prestashop-inventory input:checked + .slider:before {
    transform: translateX(12px);
  }

  .prestashop-inventory .inventory-switch-row {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    margin: 0;
    font-weight: 400;
  }

  .prestashop-inventory .inventory-filters-menu {
    position: relative;
  }

  .prestashop-inventory .inventory-filter-toggle {
    position: relative;
    width: 42px;
    height: 42px;
    border: 0;
    border-radius: 4px;
    background: transparent;
    color: #1f1f1f;
    font-size: 22px;
    transition: color .15s ease, transform .15s ease;
  }

  .prestashop-inventory .inventory-filter-toggle:hover,
  .prestashop-inventory .inventory-filter-toggle:focus {
    color: #111;
    transform: scale(1.04);
    outline: none;
  }

  .prestashop-inventory .inventory-filter-toggle i {
    display: block;
    line-height: 1;
  }

  .prestashop-inventory .inventory-filter-badge {
    position: absolute;
    top: -6px;
    right: -6px;
    min-width: 18px;
    height: 18px;
    padding: 0 4px;
    border-radius: 999px;
    background: #d93025;
    color: #fff;
    font-size: 11px;
    font-weight: 700;
    line-height: 18px;
    text-align: center;
  }

  .prestashop-inventory .inventory-filter-dropdown {
    width: max-content;
    min-width: 0;
    max-width: calc(100vw - 32px);
    padding: 8px 0;
  }

  .prestashop-inventory .inventory-filter-row {
    display: flex;
    width: 100%;
    padding: 10px 16px;
    gap: 12px;
    cursor: pointer;
  }

  .prestashop-inventory .inventory-filter-row > span:last-child {
    flex: 1 1 auto;
    line-height: 1.3;
    white-space: nowrap;
  }

  .prestashop-inventory .inventory-filter-row:hover {
    background: #f5f7fa;
  }

  .prestashop-inventory img.img-thumbnail {
    width: 45px;
    height: 45px;
    object-fit: cover;
    border: 1px solid #ddd;
    border-radius: 0;
    background: #fff;
    padding: 2px;
  }

  .prestashop-inventory .product-preview {
    position: relative;
    display: inline-flex;
    align-items: center;
    outline: none;
  }

  .prestashop-inventory .product-preview-card {
    position: absolute;
    left: calc(100% + 12px);
    top: 50%;
    z-index: 1000;
    display: none;
    min-width: 260px;
    padding: 14px 16px;
    background-color: #fff;
    color: #111;
    border-radius: 14px;
    box-shadow: 0 12px 28px rgba(0, 0, 0, 0.18), 0 4px 10px rgba(0, 0, 0, 0.12);
    transform: translateY(-50%);
    white-space: normal;
  }

  .prestashop-inventory .product-preview:hover .product-preview-card,
  .prestashop-inventory .product-preview:focus .product-preview-card,
  .prestashop-inventory .product-preview:focus-within .product-preview-card {
    display: block;
  }

  .prestashop-inventory .product-preview-title,
  .prestashop-inventory .product-preview-subtitle {
    display: block;
    line-height: 1.35;
  }

  .prestashop-inventory .product-preview-title {
    font-weight: 600;
  }

  .prestashop-inventory .product-preview-subtitle {
    margin-top: 4px;
    color: #666;
  }

  .prestashop-inventory .product-preview-image {
    display: block;
    width: 240px;
    max-width: min(240px, 70vw);
    height: auto;
    border-radius: 10px;
    margin-top: 10px;
  }

  .prestashop-inventory #productsTable {
    margin-bottom: 0;
    background: #fff;
  }

  .prestashop-inventory .inventory-pagination {
    margin-top: 18px;
    overflow-x: auto;
    overflow-y: hidden;
    padding-bottom: 4px;
  }

  .prestashop-inventory .inventory-pagination-inner {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 16px;
    flex-wrap: nowrap;
    min-width: max-content;
  }

  .prestashop-inventory .inventory-pagination-pages {
    display: flex;
    align-items: center;
    flex: 0 0 auto;
  }

  .prestashop-inventory .inventory-pagination-pages .pagination {
    display: flex;
    align-items: center;
    margin: 0;
    gap: 0;
  }

  .prestashop-inventory .inventory-pagination-pages .page-item {
    display: flex;
    align-items: center;
  }

  .prestashop-inventory .inventory-pagination-pages .page-item.current,
  .prestashop-inventory .inventory-pagination-pages .page-item.current.active {
    flex: 0 0 auto;
    width: auto;
    background: transparent;
    border: 0;
  }

  .prestashop-inventory .inventory-pagination-pages .page-item.current label {
    margin: 0;
    display: block;
    width: 48px !important;
    min-width: 48px !important;
    max-width: 48px !important;
    flex: 0 0 48px !important;
  }

  .prestashop-inventory .inventory-pagination-pages .page-item.current .jump-to-page,
  .prestashop-inventory .inventory-page-current {
    width: 48px !important;
    min-width: 48px !important;
    max-width: 48px !important;
    flex: 0 0 48px !important;
    height: 50px;
    border: 1px solid #d7d7d7;
    background: #fff;
    font-weight: 700;
    font-size: 16px;
    line-height: 1;
    padding: 0 4px;
    text-align: center;
    box-shadow: none;
    -webkit-appearance: none;
    -moz-appearance: none;
    appearance: none;
    border-radius: 0;
  }

  .prestashop-inventory .inventory-pagination-pages .page-link.previous,
  .prestashop-inventory .inventory-pagination-pages .page-link.next {
    min-width: 28px;
    height: 28px;
    padding: 0;
    border: 0;
    background: transparent;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    font-size: 34px;
    font-weight: 300;
    line-height: 1;
    color: #7a7a7a;
  }

  .prestashop-inventory .inventory-pagination-pages .page-link.previous span[aria-hidden="true"],
  .prestashop-inventory .inventory-pagination-pages .page-link.next span[aria-hidden="true"] {
    display: inline-block;
    transform: translateY(-1px);
  }

  .prestashop-inventory .inventory-page-current::-webkit-outer-spin-button,
  .prestashop-inventory .inventory-page-current::-webkit-inner-spin-button {
    -webkit-appearance: none;
    margin: 0;
  }

  .prestashop-inventory .inventory-pagination-pages .page-link {
    box-shadow: none;
  }

  .prestashop-inventory .inventory-pagination-pages .page-item.previous.disabled .page-link,
  .prestashop-inventory .inventory-pagination-pages .page-item.next.disabled .page-link {
    color: #cfcfcf;
    cursor: default;
  }

  .prestashop-inventory .inventory-pagination-status {
    font-size: 16px;
    color: #2b2b2b;
    white-space: nowrap;
    flex: 0 0 auto;
  }

  .prestashop-inventory .inventory-per-page {
    display: inline-flex;
    align-items: center;
    gap: 10px;
    margin: 0;
    font-weight: 400;
    font-size: 16px;
    white-space: nowrap;
    flex: 0 0 auto;
  }

  .prestashop-inventory .inventory-per-page-label {
    white-space: nowrap;
  }

  .prestashop-inventory .inventory-per-page-select {
    min-width: 74px;
    height: 50px;
    padding: 0 28px 0 14px;
    border: 1px solid #d7d7d7;
    border-radius: 0;
    background-color: #fff;
    font-size: 15px;
    box-shadow: none;
  }

  .prestashop-inventory #productsTable thead th {
    padding: 10px 14px;
    border: 0;
    border-bottom: 2px solid #1f1f1f;
    font-size: 13px;
    font-weight: 700;
    color: #1f1f1f;
    background: transparent;
    white-space: normal;
    line-height: 1.15;
  }

  .prestashop-inventory .inventory-sort-button {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 8px;
    width: 100%;
    padding: 0;
    border: 0;
    background: transparent;
    text-align: left;
    font: inherit;
    color: inherit;
  }

  .prestashop-inventory .inventory-sort-button-center {
    justify-content: center;
  }

  .prestashop-inventory .inventory-sort-indicator {
    width: 11px;
    min-width: 11px;
    height: 11px;
    position: relative;
    opacity: .72;
    display: inline-block;
  }

  .prestashop-inventory .inventory-sort-indicator:before {
    content: "";
    position: absolute;
    top: 2px;
    left: 2px;
    width: 6px;
    height: 6px;
    border-right: 2px solid #2f2f2f;
    border-bottom: 2px solid #2f2f2f;
    transform: rotate(45deg);
  }

  .prestashop-inventory .inventory-sortable.is-active .inventory-sort-indicator {
    opacity: 1;
  }

  .prestashop-inventory .inventory-sortable.sort-asc .inventory-sort-indicator:before {
    top: 3px;
    transform: rotate(225deg);
  }

  .prestashop-inventory #productsTable tbody td {
    padding: 8px 14px;
    border: 0;
    border-bottom: 1px solid #ececec;
    vertical-align: middle;
    font-size: 13px;
    color: #2b2b2b;
    background: #fff;
    transition: background-color .15s ease;
  }

  .prestashop-inventory #productsTable tbody tr:hover td {
    background: #f4f8fb;
  }

  .prestashop-inventory .inventory-col-id {
    width: 92px;
    font-weight: 400;
  }

  .prestashop-inventory .inventory-col-image {
    width: 86px;
  }

  .prestashop-inventory .inventory-col-name {
    min-width: 360px;
  }

  .prestashop-inventory .inventory-col-price,
  .prestashop-inventory .inventory-col-active,
  .prestashop-inventory .inventory-col-qty,
  .prestashop-inventory .inventory-col-value {
    white-space: nowrap;
    font-variant-numeric: tabular-nums;
  }

  .prestashop-inventory .inventory-col-actions {
    width: 88px;
  }

  .prestashop-inventory .inventory-col-active {
    width: 110px;
  }

  .prestashop-inventory .inventory-product-name {
    font-size: 13px;
    font-weight: 500;
    line-height: 1.2;
  }

  .prestashop-inventory .inventory-product-link {
    color: #2b2b2b;
    text-decoration: none;
  }

  .prestashop-inventory .inventory-product-link:hover,
  .prestashop-inventory .inventory-product-link:focus {
    color: #25b9d7;
    text-decoration: none;
    outline: none;
  }

  .prestashop-inventory .inventory-product-meta {
    margin-top: 2px;
    color: #a0a0a0;
    font-size: 11px;
    line-height: 1.15;
  }

  .prestashop-inventory .inventory-product-ean {
    margin-top: 2px;
    color: #6f6f6f;
    font-size: 11px;
    line-height: 1.15;
    font-variant-numeric: tabular-nums;
    border: 0;
    background: transparent;
    padding: 0;
    text-align: left;
    cursor: pointer;
  }

  .prestashop-inventory .inventory-product-ean:hover,
  .prestashop-inventory .inventory-product-ean:focus {
    color: #25b9d7;
    outline: none;
  }

  .prestashop-inventory .inventory-product-ean.is-copied {
    color: #4f955d;
  }

  .prestashop-inventory .inventory-no-image {
    color: #777;
  }

  .prestashop-inventory .inventory-summary-row td {
    background: #fafafa !important;
    font-weight: 700;
  }

  .prestashop-inventory .inventory-head-title,
  .prestashop-inventory .inventory-head-subtitle {
    display: block;
  }

  .prestashop-inventory .inventory-head-subtitle {
    margin-top: 2px;
  }

  .prestashop-inventory .inventory-row-switch {
    position: relative;
    display: inline-block;
    width: 28px;
    height: 16px;
    margin: 0;
  }

  .prestashop-inventory .inventory-row-switch input {
    opacity: 0;
    width: 0;
    height: 0;
  }

  .prestashop-inventory .inventory-row-slider {
    position: absolute;
    inset: 0;
    border-radius: 999px;
    background: #d3d3d3;
    transition: .2s ease;
    cursor: pointer;
  }

  .prestashop-inventory .inventory-row-slider:before {
    content: "";
    position: absolute;
    top: 2px;
    left: 2px;
    width: 12px;
    height: 12px;
    border-radius: 50%;
    background: #fff;
    box-shadow: 0 1px 2px rgba(0, 0, 0, 0.18);
    transition: .2s ease;
  }

  .prestashop-inventory .inventory-row-switch input:checked + .inventory-row-slider {
    background: #4f955d;
  }

  .prestashop-inventory .inventory-row-switch input:checked + .inventory-row-slider:before {
    transform: translateX(12px);
  }

  .prestashop-inventory .inventory-row-switch input:disabled + .inventory-row-slider {
    opacity: .65;
    cursor: progress;
  }

  .prestashop-inventory .inventory-actions-menu {
    position: relative;
    display: inline-flex;
    justify-content: center;
  }

  .prestashop-inventory .inventory-actions-toggle {
    width: 34px;
    height: 34px;
    border: 0;
    background: transparent;
    color: #1f1f1f;
    font-size: 26px;
    line-height: 1;
    padding: 0;
  }

  .prestashop-inventory .inventory-actions-dropdown {
    position: absolute;
    top: calc(100% + 8px);
    right: 0;
    z-index: 30;
    min-width: 220px;
    padding: 8px 0;
    border: 1px solid #e3e3e3;
    background: #fff;
    box-shadow: 0 8px 18px rgba(0, 0, 0, 0.12);
    display: none;
    text-align: left;
  }

  .prestashop-inventory .inventory-actions-menu.is-open .inventory-actions-dropdown {
    display: block;
  }

  .prestashop-inventory .inventory-actions-dropdown button {
    width: 100%;
    padding: 12px 16px;
    border: 0;
    background: transparent;
    display: flex;
    align-items: center;
    gap: 12px;
    font-size: 15px;
    color: #222;
    text-align: left;
  }

  .prestashop-inventory .inventory-actions-dropdown button:hover {
    background: #f5f7fa;
  }

  .prestashop-inventory .inventory-actions-dropdown i {
    width: 18px;
    color: #8a8a8a;
    text-align: center;
  }
</style>

<script>
  (function () {
    function getDirectContainerFluid(headerToolbar) {
      if (!headerToolbar) {
        return null;
      }

      var children = headerToolbar.children || [];
      for (var i = 0; i < children.length; i++) {
        if (children[i].classList && children[i].classList.contains('container-fluid')) {
          return children[i];
        }
      }

      return headerToolbar.querySelector('.container-fluid');
    }

    function mountBoTabs(sourceId, attempt) {
      var source = document.getElementById(sourceId);
      if (!source) {
        return true;
      }

      var headerToolbar = document.querySelector('.header-toolbar.d-print-none, body > .header-toolbar, #main-div > .header-toolbar, .content-div > .header-toolbar, .header-toolbar');
      var headerContainer = getDirectContainerFluid(headerToolbar);
      if (!headerToolbar || !headerContainer) {
        if ((attempt || 0) < 100) {
          window.setTimeout(function () {
            mountBoTabs(sourceId, (attempt || 0) + 1);
          }, 100);
          return false;
        }

        source.hidden = false;
        return false;
      }

      var mounted = document.getElementById('head_tabs');
      if (!mounted) {
        mounted = source.cloneNode(true);
        mounted.id = 'head_tabs';
        mounted.hidden = false;
      }

      if (mounted.parentNode !== headerToolbar || mounted.previousElementSibling !== headerContainer) {
        headerContainer.insertAdjacentElement('afterend', mounted);
      }

      var contentDiv = document.querySelector('#main-div > .content-div');
      if (contentDiv) {
        contentDiv.classList.add('with-tabs');
      }

      source.hidden = true;
      return true;
    }

    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', function () {
        mountBoTabs('psinventory-head-tabs-source', 0);
      });
    } else {
      mountBoTabs('psinventory-head-tabs-source', 0);
    }

    window.addEventListener('load', function () {
      mountBoTabs('psinventory-head-tabs-source', 0);
    });

    var mountObserver = new MutationObserver(function () {
      mountBoTabs('psinventory-head-tabs-source', 0);
    });
    mountObserver.observe(document.documentElement, {ldelim}childList: true, subtree: true{rdelim});
    window.setTimeout(function () {
      mountObserver.disconnect();
    }, 10000);
  })();

  window.prestashopInventoryConfig = {
    ajaxUrl: '{$inventoryAjaxUrl|escape:'javascript'}',
    exportUrl: '{$inventoryExportUrl|escape:'javascript'}',
    canEdit: {$inventoryCanEdit|intval}
  };

  (function () {
    var sourceTranslations = {$inventoryTranslationsJson nofilter};
    var translations = {
      no: sourceTranslations.id,
      title: sourceTranslations.report_title,
      activeOnly: sourceTranslations.show_only_active_products,
      onlyAvailable: sourceTranslations.show_only_available_in_stock,
      missingPurchasePriceOnly: sourceTranslations.show_only_missing_purchase_price,
      showWeight: sourceTranslations.show_product_weight,
      missingWeightOnly: sourceTranslations.show_only_missing_weight,
      showBrutto: sourceTranslations.show_retail_prices_gross,
      searchPlaceholder: sourceTranslations.search_placeholder,
      picture: sourceTranslations.image,
      name: sourceTranslations.product_name,
      active: sourceTranslations.active,
      weight: sourceTranslations.product_weight,
      price: sourceTranslations.purchase_price_net,
      priceBrutto: sourceTranslations.retail_price_gross,
      qty: sourceTranslations.available_quantity,
      value: sourceTranslations.purchase_value_net,
      valueBrutto: sourceTranslations.retail_value_gross,
      save: sourceTranslations.save,
      cancel: sourceTranslations.cancel,
      enterQty: sourceTranslations.enter_qty,
      enterPrice: sourceTranslations.enter_price,
      enterRetailPrice: sourceTranslations.enter_retail_price,
      enterWeight: sourceTranslations.enter_weight,
      errorSave: sourceTranslations.error_save,
      errorNetwork: sourceTranslations.error_network,
      errorQtySave: sourceTranslations.error_qty_save,
      errorWeightSave: sourceTranslations.error_weight_save,
      errorHide: sourceTranslations.error_hide,
      hideForever: sourceTranslations.hide_forever,
      typeQty: sourceTranslations.type_qty,
      typePrice: sourceTranslations.type_price,
      typeWeight: sourceTranslations.type_weight,
      errorToggle: sourceTranslations.error_toggle,
      copied: sourceTranslations.copied,
      copyError: sourceTranslations.copy_error,
      loadError: sourceTranslations.load_error
    };

    var LS_QUERY = 'ps_inventory_query';
    var LS_ACTIVE_ONLY = 'ps_inventory_activeOnly';
    var LS_ONLY = 'ps_inventory_onlyAvailable';
    var LS_MISSING_PURCHASE = 'ps_inventory_missingPurchasePriceOnly';
    var LS_SHOW_WEIGHT = 'ps_inventory_showWeight';
    var LS_MISSING_WEIGHT = 'ps_inventory_missingWeightOnly';
    var LS_BRUTTO = 'ps_inventory_showBrutto';
    var LS_PAGE = 'ps_inventory_page';
    var LS_PER_PAGE = 'ps_inventory_per_page';
    var LS_SORT_FIELD = 'ps_inventory_sort_field';
    var LS_SORT_DIR = 'ps_inventory_sort_dir';
    var currentPage = Math.max(parseInt(localStorage.getItem(LS_PAGE) || '1', 10), 1);
    var currentPerPage = parseInt(localStorage.getItem(LS_PER_PAGE) || '20', 10);
    if ([20, 50, 100, 200].indexOf(currentPerPage) === -1) {
      currentPerPage = 20;
    }
    var currentSortField = localStorage.getItem(LS_SORT_FIELD) || 'product_name';
    var currentSortDir = localStorage.getItem(LS_SORT_DIR) || 'ASC';

    function t(key) {
      return translations[key] ? translations[key] : key;
    }

    function parseKeywords(raw) {
      return (raw || '').trim().split(/[,\s]+/g).map(function (item) {
        return item.trim();
      }).filter(Boolean);
    }

    function applyLanguage() {
      document.querySelector('#thNo .inventory-head-title').textContent = t('no');
      document.getElementById('activeOnlyLabel').textContent = t('activeOnly');
      document.getElementById('onlyAvailableLabel').textContent = t('onlyAvailable');
      document.getElementById('missingPurchasePriceOnlyLabel').textContent = t('missingPurchasePriceOnly');
      document.getElementById('showWeightLabel').textContent = t('showWeight');
      document.getElementById('missingWeightOnlyLabel').textContent = t('missingWeightOnly');
      document.getElementById('showBruttoLabel').textContent = t('showBrutto');
      document.getElementById('searchInput').setAttribute('placeholder', t('searchPlaceholder'));
      document.getElementById('thPicture').textContent = t('picture');
      document.querySelector('#thName .inventory-head-title').textContent = t('name');
      document.querySelector('#thActive .inventory-head-title').textContent = t('active');
      document.querySelector('#thWeight .inventory-head-title').textContent = t('weight');
      document.querySelector('#thPrice .inventory-head-title').textContent = t('price');
      document.querySelector('#thPriceBrutto .inventory-head-title').textContent = t('priceBrutto');
      document.querySelector('#thQty .inventory-head-title').textContent = t('qty');
      document.getElementById('thValue').textContent = t('value');
      document.getElementById('thValueBrutto').textContent = t('valueBrutto');
      renderSortState();
    }

    function toggleWeightColumns(show, shouldReload) {
      document.getElementById('thWeight').style.display = show ? '' : 'none';
      if (shouldReload === false) {
        return;
      }

      currentPage = 1;
      localStorage.setItem(LS_PAGE, String(currentPage));
      loadTable(getSearchQuery(), document.getElementById('activeOnly').checked, document.getElementById('onlyAvailable').checked, document.getElementById('missingPurchasePriceOnly').checked, document.getElementById('missingWeightOnly').checked);
    }

    function toggleBruttoColumns(show, shouldReload) {
      var display = show ? '' : 'none';
      document.getElementById('thPriceBrutto').style.display = display;
      document.getElementById('thValueBrutto').style.display = display;
      if (shouldReload === false) {
        return;
      }

      currentPage = 1;
      localStorage.setItem(LS_PAGE, String(currentPage));
      loadTable(getSearchQuery(), document.getElementById('activeOnly').checked, document.getElementById('onlyAvailable').checked, document.getElementById('missingPurchasePriceOnly').checked, document.getElementById('missingWeightOnly').checked);
    }

    function normalizeKeywords(value) {
      return (value || []).map(function (item) {
        return item.trim();
      }).filter(Boolean);
    }

    function getSearchKeywords() {
      return normalizeKeywords($('#searchTags').data('keywords') || []);
    }

    function setSearchKeywords(keywords) {
      $('#searchTags').data('keywords', normalizeKeywords(keywords));
      renderSearchTags();
    }

    function getSearchQuery() {
      return getSearchKeywords().join(' ');
    }

    function renderSearchTags() {
      var keywords = getSearchKeywords();
      var $tags = $('#searchTags');

      $tags.empty();
      keywords.forEach(function (keyword, index) {
        var $tag = $('<span class="inventory-tag"></span>');
        $tag.append($('<span></span>').text(keyword));
        $tag.append($('<button type="button" class="inventory-tag-remove" aria-label="Remove">&times;</button>').attr('data-index', index));
        $tags.append($tag);
      });
    }

    function persistAndLoadKeywords(keywords) {
      setSearchKeywords(keywords);
      localStorage.setItem(LS_QUERY, getSearchQuery());
      currentPage = 1;
      localStorage.setItem(LS_PAGE, String(currentPage));
      loadTable(getSearchQuery(), $('#activeOnly').is(':checked'), $('#onlyAvailable').is(':checked'), $('#missingPurchasePriceOnly').is(':checked'), $('#missingWeightOnly').is(':checked'));
    }

    function appendKeywordsFromInput() {
      var current = $('#searchInput').val();
      var inputKeywords = parseKeywords(current);
      if (!inputKeywords.length) {
        return false;
      }

      var merged = getSearchKeywords().concat(inputKeywords);
      persistAndLoadKeywords(merged);
      $('#searchInput').val('');

      return true;
    }

    function loadTable(query, activeOnly, onlyAvailable, missingPurchasePriceOnly, missingWeightOnly) {
      var keywords = parseKeywords(query);
      var showWeight = document.getElementById('showWeight').checked;
      var showBrutto = document.getElementById('showBrutto').checked;

      $.post(window.prestashopInventoryConfig.ajaxUrl + '&action=FetchProducts', {
        query: query || '',
        keywords: keywords,
        activeOnly: activeOnly ? 1 : 0,
        onlyAvailable: onlyAvailable ? 1 : 0,
        missingPurchasePriceOnly: missingPurchasePriceOnly ? 1 : 0,
        missingWeightOnly: missingWeightOnly ? 1 : 0,
        showWeight: showWeight ? 1 : 0,
        showBrutto: showBrutto ? 1 : 0,
        lang: 'pl',
        sort_field: currentSortField,
        sort_dir: currentSortDir,
        page: currentPage,
        per_page: currentPerPage
      }, null, 'json').done(function (resp) {
        $('#productsTable tbody').html(resp && resp.tbody ? resp.tbody : '');
        $('#inventoryPagination').html(resp && resp.pagination ? resp.pagination : '');
        if (resp && resp.meta) {
          currentPage = Math.max(parseInt(resp.meta.current_page || 1, 10), 1);
          currentPerPage = parseInt(resp.meta.per_page || currentPerPage, 10);
          localStorage.setItem(LS_PAGE, String(currentPage));
          localStorage.setItem(LS_PER_PAGE, String(currentPerPage));
        }
      }).fail(function () {
        var colspan = (document.getElementById('showWeight').checked ? 9 : 8) + (document.getElementById('showBrutto').checked ? 2 : 0);
        $('#productsTable tbody').html('<tr><td colspan="' + colspan + '" class="text-center text-danger">' + t('loadError') + '</td></tr>');
        $('#inventoryPagination').empty();
      });
    }

    function renderSortState() {
      $('.inventory-sortable').removeClass('is-active sort-asc sort-desc');
      var $active = $('.inventory-sortable[data-sort-field="' + currentSortField + '"]');
      $active.addClass('is-active ' + (currentSortDir === 'DESC' ? 'sort-desc' : 'sort-asc'));
    }

    function updateFilterBadge() {
      var count = 0;
      ['activeOnly', 'onlyAvailable', 'missingPurchasePriceOnly', 'showWeight', 'missingWeightOnly', 'showBrutto'].forEach(function (id) {
        var input = document.getElementById(id);
        if (input && input.checked) {
          count += 1;
        }
      });

      var badge = document.getElementById('filterActiveCount');
      if (badge) {
        badge.textContent = String(count);
      }
    }

    function copyTextToClipboard(text) {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        return navigator.clipboard.writeText(text);
      }

      return new Promise(function (resolve, reject) {
        var input = document.createElement('textarea');
        input.value = text;
        input.setAttribute('readonly', '');
        input.style.position = 'absolute';
        input.style.left = '-9999px';
        document.body.appendChild(input);
        input.select();

        try {
          document.execCommand('copy');
          document.body.removeChild(input);
          resolve();
        } catch (error) {
          document.body.removeChild(input);
          reject(error);
        }
      });
    }

    $(document).ready(function () {
      var savedQuery = localStorage.getItem(LS_QUERY) || '';
      var savedActiveOnly = localStorage.getItem(LS_ACTIVE_ONLY) === '1';
      var savedOnly = localStorage.getItem(LS_ONLY) === '1';
      var savedMissingPurchaseOnly = localStorage.getItem(LS_MISSING_PURCHASE) === '1';
      var savedShowWeight = localStorage.getItem(LS_SHOW_WEIGHT) !== '0';
      var savedMissingWeightOnly = localStorage.getItem(LS_MISSING_WEIGHT) === '1';
      var savedBrutto = localStorage.getItem(LS_BRUTTO) !== '0';

      applyLanguage();
      renderSortState();

      setSearchKeywords(parseKeywords(savedQuery));
      $('#activeOnly').prop('checked', savedActiveOnly);
      $('#onlyAvailable').prop('checked', savedOnly);
      $('#missingPurchasePriceOnly').prop('checked', savedMissingPurchaseOnly);
      $('#showWeight').prop('checked', savedShowWeight);
      $('#missingWeightOnly').prop('checked', savedMissingWeightOnly);
      $('#showBrutto').prop('checked', savedBrutto);
      updateFilterBadge();
      toggleWeightColumns(savedShowWeight, false);
      toggleBruttoColumns(savedBrutto, false);

      $('#searchBox').on('click', function () {
        $('#searchInput').trigger('focus');
      });

      $('#searchInput').on('keydown', function (e) {
        if (e.key === 'Enter') {
          e.preventDefault();
          appendKeywordsFromInput();
          return;
        }

        if (e.key === 'Backspace' && !this.value) {
          var keywords = getSearchKeywords();
          if (keywords.length) {
            keywords.pop();
            persistAndLoadKeywords(keywords);
          }
        }
      });

      $('#activeOnly').on('change', function () {
        localStorage.setItem(LS_ACTIVE_ONLY, this.checked ? '1' : '0');
        updateFilterBadge();
        currentPage = 1;
        localStorage.setItem(LS_PAGE, String(currentPage));
        loadTable(getSearchQuery(), this.checked, $('#onlyAvailable').is(':checked'), $('#missingPurchasePriceOnly').is(':checked'), $('#missingWeightOnly').is(':checked'));
      });

      $('#onlyAvailable').on('change', function () {
        localStorage.setItem(LS_ONLY, this.checked ? '1' : '0');
        updateFilterBadge();
        currentPage = 1;
        localStorage.setItem(LS_PAGE, String(currentPage));
        loadTable(getSearchQuery(), $('#activeOnly').is(':checked'), this.checked, $('#missingPurchasePriceOnly').is(':checked'), $('#missingWeightOnly').is(':checked'));
      });

      $('#missingPurchasePriceOnly').on('change', function () {
        localStorage.setItem(LS_MISSING_PURCHASE, this.checked ? '1' : '0');
        updateFilterBadge();
        currentPage = 1;
        localStorage.setItem(LS_PAGE, String(currentPage));
        loadTable(getSearchQuery(), $('#activeOnly').is(':checked'), $('#onlyAvailable').is(':checked'), this.checked, $('#missingWeightOnly').is(':checked'));
      });

      $('#showWeight').on('change', function () {
        localStorage.setItem(LS_SHOW_WEIGHT, this.checked ? '1' : '0');
        updateFilterBadge();
        toggleWeightColumns(this.checked);
      });

      $('#missingWeightOnly').on('change', function () {
        localStorage.setItem(LS_MISSING_WEIGHT, this.checked ? '1' : '0');
        updateFilterBadge();
        currentPage = 1;
        localStorage.setItem(LS_PAGE, String(currentPage));
        loadTable(getSearchQuery(), $('#activeOnly').is(':checked'), $('#onlyAvailable').is(':checked'), $('#missingPurchasePriceOnly').is(':checked'), this.checked);
      });

      $('#showBrutto').on('change', function () {
        localStorage.setItem(LS_BRUTTO, this.checked ? '1' : '0');
        updateFilterBadge();
        toggleBruttoColumns(this.checked);
      });

      $(document).on('click', '.inventory-sortable .inventory-sort-button', function () {
        var field = $(this).closest('.inventory-sortable').data('sort-field');
        if (!field) {
          return;
        }

        if (currentSortField === field) {
          currentSortDir = currentSortDir === 'ASC' ? 'DESC' : 'ASC';
        } else {
          currentSortField = field;
          currentSortDir = 'ASC';
        }

        localStorage.setItem(LS_SORT_FIELD, currentSortField);
        localStorage.setItem(LS_SORT_DIR, currentSortDir);
        renderSortState();
        loadTable(getSearchQuery(), $('#activeOnly').is(':checked'), $('#onlyAvailable').is(':checked'), $('#missingPurchasePriceOnly').is(':checked'), $('#missingWeightOnly').is(':checked'));
      });

      $(document).on('click', '.inventory-tag-remove', function () {
        var keywords = getSearchKeywords();
        var index = Number($(this).attr('data-index'));
        keywords.splice(index, 1);
        persistAndLoadKeywords(keywords);
      });

      $('#clearSearch').on('click', function () {
        $('#searchInput').val('');
        setSearchKeywords([]);
        localStorage.setItem(LS_QUERY, '');
        currentPage = 1;
        localStorage.setItem(LS_PAGE, String(currentPage));
        loadTable('', $('#activeOnly').is(':checked'), $('#onlyAvailable').is(':checked'), $('#missingPurchasePriceOnly').is(':checked'), $('#missingWeightOnly').is(':checked'));
      });

      $('#btnPdf').on('click', function () {
        appendKeywordsFromInput();
        var q = getSearchQuery();
        var activeOnly = $('#activeOnly').is(':checked') ? '1' : '0';
        var only = $('#onlyAvailable').is(':checked') ? '1' : '0';
        var missingPurchasePriceOnly = $('#missingPurchasePriceOnly').is(':checked') ? '1' : '0';
        var showWeight = $('#showWeight').is(':checked') ? '1' : '0';
        var missingWeightOnly = $('#missingWeightOnly').is(':checked') ? '1' : '0';
        var showBrutto = $('#showBrutto').is(':checked') ? '1' : '0';
        window.location.href = window.prestashopInventoryConfig.exportUrl + '&lang=pl&activeOnly=' + encodeURIComponent(activeOnly) + '&onlyAvailable=' + encodeURIComponent(only) + '&missingPurchasePriceOnly=' + encodeURIComponent(missingPurchasePriceOnly) + '&showWeight=' + encodeURIComponent(showWeight) + '&missingWeightOnly=' + encodeURIComponent(missingWeightOnly) + '&showBrutto=' + encodeURIComponent(showBrutto) + '&query=' + encodeURIComponent(q);
      });

      $(document).on('click', '.editable-price', function () {
        if (!window.prestashopInventoryConfig.canEdit) {
          return;
        }

        var $el = $(this);
        var current = ($el.data('current-price') || '').toString();

        if ($el.closest('td').find('.price-editor').length) {
          return;
        }

        var editorHtml = '<div class="price-editor form-inline"><input type="text" class="form-control input-sm price-input" style="width:120px" placeholder="' + t('enterPrice') + '" value="' + current + '"> <button class="btn btn-primary btn-sm save-price">' + t('save') + '</button> <button class="btn btn-default btn-sm cancel-price">' + t('cancel') + '</button></div>';
        $el.hide().after(editorHtml);
        $el.closest('td').find('.price-input').focus().select();
      });

      $(document).on('click', '.editable-retail-price', function () {
        if (!window.prestashopInventoryConfig.canEdit) {
          return;
        }

        var $el = $(this);
        var current = ($el.data('current-price') || '').toString();

        if ($el.closest('td').find('.price-editor').length) {
          return;
        }

        var editorHtml = '<div class="price-editor form-inline"><input type="text" class="form-control input-sm price-input" style="width:120px" placeholder="' + t('enterRetailPrice') + '" value="' + current + '"> <button class="btn btn-primary btn-sm save-retail-price">' + t('save') + '</button> <button class="btn btn-default btn-sm cancel-price">' + t('cancel') + '</button></div>';
        $el.hide().after(editorHtml);
        $el.closest('td').find('.price-input').focus().select();
      });

      $(document).on('click', '.editable-quantity', function () {
        if (!window.prestashopInventoryConfig.canEdit) {
          return;
        }

        var $el = $(this);
        var current = ($el.data('current-qty') || '').toString();

        if ($el.closest('td').find('.qty-editor').length) {
          return;
        }

        var editorHtml = '<div class="qty-editor form-inline"><input type="number" step="1" class="form-control input-sm qty-input" style="width:100px" placeholder="' + t('enterQty') + '" value="' + current + '"> <button class="btn btn-primary btn-sm save-quantity">' + t('save') + '</button> <button class="btn btn-default btn-sm cancel-price">' + t('cancel') + '</button></div>';
        $el.hide().after(editorHtml);
        $el.closest('td').find('.qty-input').focus().select();
      });

      $(document).on('click', '.editable-weight', function () {
        if (!window.prestashopInventoryConfig.canEdit) {
          return;
        }

        var $el = $(this);
        var current = ($el.data('current-weight') || '').toString();

        if ($el.closest('td').find('.weight-editor').length) {
          return;
        }

        var editorHtml = '<div class="weight-editor form-inline"><input type="number" step="0.001" min="0" class="form-control input-sm weight-input" style="width:110px" placeholder="' + t('enterWeight') + '" value="' + current + '"> <button class="btn btn-primary btn-sm save-weight">' + t('save') + '</button> <button class="btn btn-default btn-sm cancel-price">' + t('cancel') + '</button></div>';
        $el.hide().after(editorHtml);
        $el.closest('td').find('.weight-input').focus().select();
      });

      $(document).on('click', '.cancel-price', function () {
        var $td = $(this).closest('td');
        $td.find('.price-editor, .qty-editor, .weight-editor').remove();
        $td.find('.editable-price, .editable-retail-price, .editable-quantity, .editable-weight').show();
      });

      $(document).on('keydown', '.price-input, .qty-input, .weight-input', function (e) {
        if (e.key === 'Enter') {
          e.preventDefault();
          if ($(this).hasClass('qty-input')) {
            $(this).closest('.qty-editor').find('.save-quantity').click();
          } else if ($(this).hasClass('weight-input')) {
            $(this).closest('.weight-editor').find('.save-weight').click();
          } else if ($(this).closest('.price-editor').find('.save-retail-price').length) {
            $(this).closest('.price-editor').find('.save-retail-price').click();
          } else {
            $(this).closest('.price-editor').find('.save-price').click();
          }
        }
        if (e.key === 'Escape') {
          e.preventDefault();
          $(this).closest('.price-editor, .qty-editor, .weight-editor').find('.cancel-price').click();
        }
      });

      $(document).on('click', '.save-price', function () {
        var $btn = $(this);
        var $td = $btn.closest('td');
        var $el = $td.find('.editable-price');
        var priceVal = $td.find('.price-input').val().trim();

        if (!priceVal) {
          alert(t('typePrice'));
          return;
        }

        $btn.prop('disabled', true);

        $.post(window.prestashopInventoryConfig.ajaxUrl + '&action=SavePrice', {
          id_product: $el.data('id-product'),
          id_product_attribute: $el.data('id-attr'),
          price: priceVal
        }, null, 'json').done(function (resp) {
          if (!resp || !resp.ok) {
            alert(resp && resp.error ? resp.error : t('errorSave'));
            $btn.prop('disabled', false);
            return;
          }

          var priceNumber = Number(resp.price || 0);
          $el.text(priceNumber.toFixed(2).replace('.', ',') + ' zł').removeClass('text-danger').attr('data-current-price', priceNumber.toFixed(2));
          $td.find('.price-editor').remove();
          $el.show();
          loadTable(getSearchQuery(), $('#activeOnly').is(':checked'), $('#onlyAvailable').is(':checked'), $('#missingPurchasePriceOnly').is(':checked'), $('#missingWeightOnly').is(':checked'));
      }).fail(function (xhr) {
          var error = xhr.responseJSON && xhr.responseJSON.error ? xhr.responseJSON.error : t('errorNetwork');
          alert(error);
          $btn.prop('disabled', false);
        });
      });

      $(document).on('click', '.save-retail-price', function () {
        var $btn = $(this);
        var $td = $btn.closest('td');
        var $el = $td.find('.editable-retail-price');
        var priceVal = $td.find('.price-input').val().trim();

        if (!priceVal) {
          alert(t('typePrice'));
          return;
        }

        $btn.prop('disabled', true);

        $.post(window.prestashopInventoryConfig.ajaxUrl + '&action=SaveRetailPrice', {
          id_product: $el.data('id-product'),
          id_product_attribute: $el.data('id-attr'),
          price: priceVal
        }, null, 'json').done(function (resp) {
          if (!resp || !resp.ok) {
            alert(resp && resp.error ? resp.error : t('errorSave'));
            $btn.prop('disabled', false);
            return;
          }

          var priceNumber = Number(resp.price || 0);
          $el.text(priceNumber.toFixed(2).replace('.', ',') + ' zł').removeClass('text-danger').attr('data-current-price', priceNumber.toFixed(2));
          $td.find('.price-editor').remove();
          $el.show();
          loadTable(getSearchQuery(), $('#activeOnly').is(':checked'), $('#onlyAvailable').is(':checked'), $('#missingPurchasePriceOnly').is(':checked'), $('#missingWeightOnly').is(':checked'));
        }).fail(function (xhr) {
          var error = xhr.responseJSON && xhr.responseJSON.error ? xhr.responseJSON.error : t('errorNetwork');
          alert(error);
          $btn.prop('disabled', false);
        });
      });

      $(document).on('click', '.save-quantity', function () {
        var $btn = $(this);
        var $td = $btn.closest('td');
        var $el = $td.find('.editable-quantity');
        var quantityVal = $td.find('.qty-input').val().trim();

        if (!/^-?\d+$/.test(quantityVal)) {
          alert(t('typeQty'));
          return;
        }

        $btn.prop('disabled', true);

        $.post(window.prestashopInventoryConfig.ajaxUrl + '&action=SaveQuantity', {
          id_product: $el.data('id-product'),
          id_product_attribute: $el.data('id-attr'),
          quantity: quantityVal
        }, null, 'json').done(function (resp) {
          if (!resp || !resp.ok) {
            alert(resp && resp.error ? resp.error : t('errorQtySave'));
            $btn.prop('disabled', false);
            return;
          }

          var quantityNumber = parseInt(resp.quantity, 10) || 0;
          $el.text(String(quantityNumber)).attr('data-current-qty', String(quantityNumber));
          $td.find('.qty-editor').remove();
          $el.show();
          loadTable(getSearchQuery(), $('#activeOnly').is(':checked'), $('#onlyAvailable').is(':checked'), $('#missingPurchasePriceOnly').is(':checked'), $('#missingWeightOnly').is(':checked'));
        }).fail(function (xhr) {
          var error = xhr.responseJSON && xhr.responseJSON.error ? xhr.responseJSON.error : t('errorQtySave');
          alert(error);
          $btn.prop('disabled', false);
        });
      });

      $(document).on('click', '.save-weight', function () {
        var $btn = $(this);
        var $td = $btn.closest('td');
        var $el = $td.find('.editable-weight');
        var weightVal = $td.find('.weight-input').val().trim();

        if (!weightVal || isNaN(Number(weightVal)) || Number(weightVal) < 0) {
          alert(t('typeWeight'));
          return;
        }

        $btn.prop('disabled', true);

        $.post(window.prestashopInventoryConfig.ajaxUrl + '&action=SaveWeight', {
          id_product: $el.data('id-product'),
          id_product_attribute: $el.data('id-attr'),
          weight: weightVal
        }, null, 'json').done(function (resp) {
          if (!resp || !resp.ok) {
            alert(resp && resp.error ? resp.error : t('errorWeightSave'));
            $btn.prop('disabled', false);
            return;
          }

          var weightNumber = Number(resp.weight || 0);
          var weightText = weightNumber > 0 ? weightNumber.toFixed(3).replace('.', ',') + ' kg' : '—';
          $el.text(weightText).attr('data-current-weight', weightNumber.toFixed(3)).toggleClass('text-danger', weightNumber <= 0);
          $td.find('.weight-editor').remove();
          $el.show();
          loadTable(getSearchQuery(), $('#activeOnly').is(':checked'), $('#onlyAvailable').is(':checked'), $('#missingPurchasePriceOnly').is(':checked'), $('#missingWeightOnly').is(':checked'));
        }).fail(function (xhr) {
          var error = xhr.responseJSON && xhr.responseJSON.error ? xhr.responseJSON.error : t('errorWeightSave');
          alert(error);
          $btn.prop('disabled', false);
        });
      });

      $(document).on('change', '.toggle-product-active', function () {
        if (!window.prestashopInventoryConfig.canEdit) {
          this.checked = !this.checked;
          return;
        }

        var checkbox = this;
        var $checkbox = $(checkbox);
        var nextValue = checkbox.checked ? 1 : 0;

        $checkbox.prop('disabled', true);

        $.post(window.prestashopInventoryConfig.ajaxUrl + '&action=ToggleProductActive', {
          id_product: $checkbox.data('id-product'),
          active: nextValue
        }, null, 'json').done(function (resp) {
          if (!resp || !resp.ok) {
            checkbox.checked = !checkbox.checked;
            alert(resp && resp.error ? resp.error : t('errorToggle'));
          } else {
            checkbox.checked = Number(resp.active) === 1;
          }
        }).fail(function (xhr) {
          checkbox.checked = !checkbox.checked;
          var error = xhr.responseJSON && xhr.responseJSON.error ? xhr.responseJSON.error : t('errorToggle');
          alert(error);
        }).always(function () {
          $checkbox.prop('disabled', false);
        });
      });

      $(document).on('click', '.copy-ean-btn', function () {
        var button = this;
        var $button = $(button);
        var ean = String($button.data('ean') || '');
        var originalText = $button.text();

        copyTextToClipboard(ean).then(function () {
          $button.addClass('is-copied').text(t('copied'));
          window.setTimeout(function () {
            $button.removeClass('is-copied').text(originalText);
          }, 900);
        }).catch(function () {
          alert(t('copyError'));
        });
      });

      $(document).on('click', '.inventory-actions-toggle', function (e) {
        e.preventDefault();
        e.stopPropagation();

        var $menu = $(this).closest('.inventory-actions-menu');
        $('.inventory-actions-menu').not($menu).removeClass('is-open').find('.inventory-actions-toggle').attr('aria-expanded', 'false');
        $menu.toggleClass('is-open');
        $(this).attr('aria-expanded', $menu.hasClass('is-open') ? 'true' : 'false');
      });

      $(document).on('click', function () {
        $('.inventory-actions-menu').removeClass('is-open').find('.inventory-actions-toggle').attr('aria-expanded', 'false');
      });

      $(document).on('click', '.inventory-actions-dropdown', function (e) {
        e.stopPropagation();
      });

      $(document).on('click', '.inventory-hide-product', function () {
        if (!window.prestashopInventoryConfig.canEdit) {
          return;
        }

        var $btn = $(this);
        var idProduct = parseInt($btn.data('id-product') || '0', 10);
        if (!idProduct) {
          return;
        }

        $btn.prop('disabled', true);

        $.post(window.prestashopInventoryConfig.ajaxUrl + '&action=HideProduct', {
          id_product: idProduct
        }, null, 'json').done(function (resp) {
          if (!resp || !resp.ok) {
            alert(resp && resp.error ? resp.error : t('errorHide'));
            $btn.prop('disabled', false);
            return;
          }

          loadTable(getSearchQuery(), $('#activeOnly').is(':checked'), $('#onlyAvailable').is(':checked'), $('#missingPurchasePriceOnly').is(':checked'), $('#missingWeightOnly').is(':checked'));
        }).fail(function (xhr) {
          var error = xhr.responseJSON && xhr.responseJSON.error ? xhr.responseJSON.error : t('errorHide');
          alert(error);
          $btn.prop('disabled', false);
        });
      });

      $(document).on('click', '.inventory-page-edge, .inventory-page-nav', function () {
        if (this.disabled) {
          return;
        }

        var page = parseInt($(this).attr('data-page') || '1', 10);
        currentPage = page > 0 ? page : 1;
        localStorage.setItem(LS_PAGE, String(currentPage));
        loadTable(getSearchQuery(), $('#activeOnly').is(':checked'), $('#onlyAvailable').is(':checked'), $('#missingPurchasePriceOnly').is(':checked'), $('#missingWeightOnly').is(':checked'));
      });

      $(document).on('change', '.inventory-per-page-select', function () {
        var perPage = parseInt(this.value || '20', 10);
        currentPerPage = [20, 50, 100, 200].indexOf(perPage) !== -1 ? perPage : 20;
        currentPage = 1;
        localStorage.setItem(LS_PER_PAGE, String(currentPerPage));
        localStorage.setItem(LS_PAGE, String(currentPage));
        loadTable(getSearchQuery(), $('#activeOnly').is(':checked'), $('#onlyAvailable').is(':checked'), $('#missingPurchasePriceOnly').is(':checked'), $('#missingWeightOnly').is(':checked'));
      });

      function applyCurrentPageInput(input) {
        var min = parseInt(input.getAttribute('min') || '1', 10);
        var max = parseInt(input.getAttribute('max') || '1', 10);
        var page = parseInt(input.value || String(currentPage), 10);

        if (isNaN(page)) {
          page = currentPage;
        }

        page = Math.max(min, Math.min(max, page));
        input.value = String(page);

        if (page === currentPage) {
          return;
        }

        currentPage = page;
        localStorage.setItem(LS_PAGE, String(currentPage));
        loadTable(getSearchQuery(), $('#activeOnly').is(':checked'), $('#onlyAvailable').is(':checked'), $('#missingPurchasePriceOnly').is(':checked'), $('#missingWeightOnly').is(':checked'));
      }

      $(document).on('keydown', '.inventory-page-current', function (e) {
        if (e.key === 'Enter') {
          e.preventDefault();
          applyCurrentPageInput(this);
        }
      });

      $(document).on('change', '.inventory-page-current', function () {
        applyCurrentPageInput(this);
      });

      loadTable(getSearchQuery(), savedActiveOnly, savedOnly, savedMissingPurchaseOnly, savedMissingWeightOnly);
    });
  })();
</script>
