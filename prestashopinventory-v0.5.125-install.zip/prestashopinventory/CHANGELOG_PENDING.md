# Wpisz tu zmiany do następnego release (jedna linia = jeden bullet)
# Przykład:
# Poprawa walidacji wymiarów w modalu produktu.
# Usunięcie znaku % z nagłówka kolumny Cło.
Naprawione ładowanie listy produktów przez przeniesienie sprawdzania zamówień poza główne zapytanie tabeli.
