<div id="psinventory-head-tabs-source" class="page-head-tabs" role="tablist" aria-label="{$inventoryTranslations.module_navigation|escape:'html':'UTF-8'}">
  <ul class="nav nav-pills">
    <li class="nav-item">
      <a href="{$inventoryModuleUrl|escape:'html':'UTF-8'}" class="nav-link active" aria-current="page" role="tab">{$inventoryTranslations.warehouse_tab|escape:'html':'UTF-8'}</a>
    </li>
    <li class="nav-item">
      <a href="{$inventoryConfigUrl|escape:'html':'UTF-8'}" class="nav-link" role="tab">{$inventoryTranslations.settings_tab|escape:'html':'UTF-8'}</a>
    </li>
  </ul>
</div>

<div class="inventory-module-content">
<div class="panel prestashop-inventory">

  <div class="inventory-toolbar">
    <div class="inventory-actions">
      <div class="inventory-actions-menu inventory-filters-menu">
        <button class="inventory-actions-toggle inventory-filter-toggle" type="button" aria-haspopup="true" aria-expanded="false" aria-label="{$inventoryTranslations.filters|escape:'html':'UTF-8'}">
          <i class="icon-tasks"></i>
          <span id="filterActiveCount" class="inventory-filter-badge">0</span>
        </button>
        <div class="inventory-actions-dropdown inventory-filter-dropdown">
          <label class="inventory-switch-row inventory-filter-row">
            <span class="ios-switch">
              <input type="checkbox" id="activeOnly">
              <span class="slider"></span>
            </span>
            <span id="activeOnlyLabel"></span>
          </label>

          <label class="inventory-switch-row inventory-filter-row">
            <span class="ios-switch">
              <input type="checkbox" id="onlyAvailable">
              <span class="slider"></span>
            </span>
            <span id="onlyAvailableLabel"></span>
          </label>

          <label class="inventory-switch-row inventory-filter-row">
            <span class="ios-switch">
              <input type="checkbox" id="missingPurchasePriceOnly">
              <span class="slider"></span>
            </span>
            <span id="missingPurchasePriceOnlyLabel"></span>
          </label>

          <label class="inventory-switch-row inventory-filter-row">
            <span class="ios-switch">
              <input type="checkbox" id="showWeight" checked>
              <span class="slider"></span>
            </span>
            <span id="showWeightLabel"></span>
          </label>

          <label class="inventory-switch-row inventory-filter-row">
            <span class="ios-switch">
              <input type="checkbox" id="missingWeightOnly">
              <span class="slider"></span>
            </span>
            <span id="missingWeightOnlyLabel"></span>
          </label>

          <label class="inventory-switch-row inventory-filter-row">
            <span class="ios-switch">
              <input type="checkbox" id="showBrutto" checked>
              <span class="slider"></span>
            </span>
            <span id="showBruttoLabel"></span>
          </label>
        </div>
      </div>

      <button id="btnPdf" class="btn btn-primary inventory-toolbar-btn" type="button">
        <i class="icon-file-pdf-o"></i> PDF
      </button>
    </div>
  </div>

  <div class="inventory-search">
    <div class="inventory-search-wrap">
      <div id="searchBox" class="inventory-tagbox">
        <div id="searchTags" class="inventory-tags"></div>
        <input type="text" id="searchInput" class="inventory-tag-input" autocomplete="off">
      </div>
      <button id="clearSearch" type="button" class="inventory-clear" aria-label="{$inventoryTranslations.clear|escape:'html':'UTF-8'}">&times;</button>
    </div>
  </div>

  <div class="table-responsive-row clearfix">
    <table id="productsTable" class="table">
      <thead>
        <tr>
          <th id="thNo" class="inventory-sortable" data-sort-field="id_product"><button type="button" class="inventory-sort-button"><span class="inventory-head-title">ID</span><span class="inventory-sort-indicator"></span></button></th>
          <th id="thPicture">{$inventoryTranslations.image|escape:'html':'UTF-8'}</th>
          <th id="thName" class="inventory-sortable" data-sort-field="product_name"><button type="button" class="inventory-sort-button"><span><span class="inventory-head-title">{$inventoryTranslations.product_name|escape:'html':'UTF-8'}</span><span class="inventory-head-subtitle">{$inventoryTranslations.ean13|escape:'html':'UTF-8'}</span></span><span class="inventory-sort-indicator"></span></button></th>
          <th id="thActive" class="text-center inventory-sortable" data-sort-field="active"><button type="button" class="inventory-sort-button inventory-sort-button-center"><span class="inventory-head-title">{$inventoryTranslations.active|escape:'html':'UTF-8'}</span><span class="inventory-sort-indicator"></span></button></th>
          <th id="thWeight" class="text-center inventory-sortable" data-sort-field="weight"><button type="button" class="inventory-sort-button inventory-sort-button-center"><span class="inventory-head-title">{$inventoryTranslations.product_weight|escape:'html':'UTF-8'}</span><span class="inventory-sort-indicator"></span></button></th>
          <th id="thPrice" class="text-center inventory-sortable" data-sort-field="purchase_price"><button type="button" class="inventory-sort-button inventory-sort-button-center"><span class="inventory-head-title">{$inventoryTranslations.purchase_price_net|escape:'html':'UTF-8'}</span><span class="inventory-sort-indicator"></span></button></th>
          <th id="thPriceBrutto" class="text-center inventory-sortable" data-sort-field="retail_price"><button type="button" class="inventory-sort-button inventory-sort-button-center"><span class="inventory-head-title">{$inventoryTranslations.retail_price_gross|escape:'html':'UTF-8'}</span><span class="inventory-sort-indicator"></span></button></th>
          <th id="thQty" class="text-center inventory-sortable" data-sort-field="quantity"><button type="button" class="inventory-sort-button inventory-sort-button-center"><span class="inventory-head-title">{$inventoryTranslations.available_quantity|escape:'html':'UTF-8'}</span><span class="inventory-sort-indicator"></span></button></th>
          <th id="thValue" class="text-center">{$inventoryTranslations.purchase_value_net|escape:'html':'UTF-8'}</th>
          <th id="thValueBrutto" class="text-center">{$inventoryTranslations.retail_value_gross|escape:'html':'UTF-8'}</th>
          <th id="thActions" class="text-center">{$inventoryTranslations.actions|escape:'html':'UTF-8'}</th>
        </tr>
      </thead>
      <tbody></tbody>
    </table>
  </div>

  <div id="inventoryPagination" class="inventory-pagination"></div>
</div>
</div>

<div id="inventorySalesModal" class="inventory-sales-modal" aria-hidden="true">
  <div class="inventory-sales-modal-backdrop"></div>
  <div class="inventory-sales-modal-dialog" role="dialog" aria-modal="true" aria-labelledby="inventorySalesModalTitle">
    <button type="button" class="inventory-sales-modal-close" aria-label="Close">&times;</button>
    <div class="inventory-sales-modal-head">
      <div class="inventory-sales-modal-media">
        <div class="inventory-sales-modal-thumb-wrap">
          <img id="inventorySalesModalImage" class="inventory-sales-modal-thumb" src="" alt="">
          <div id="inventorySalesModalImageFallback" class="inventory-sales-modal-thumb-fallback"></div>
        </div>
        <div class="inventory-sales-modal-copy">
          <div id="inventorySalesModalTitle" class="inventory-sales-modal-title"></div>
          <div id="inventorySalesModalSubtitle" class="inventory-sales-modal-subtitle"></div>
        </div>
      </div>
    </div>
    <div id="inventorySalesModalState" class="inventory-sales-modal-state"></div>
    <div id="inventorySalesModalContent" class="inventory-sales-modal-content"></div>
  </div>
</div>

<style>
  .inventory-module-content {
    margin-top: 16px;
  }

  .prestashop-inventory.panel {
    border: 1px solid #e5e5e5;
    box-shadow: none;
    padding: 28px 32px 24px;
  }

  .prestashop-inventory .inventory-toolbar {
    display: flex;
    justify-content: flex-end;
    gap: 16px;
    margin-bottom: 20px;
    align-items: center;
    flex-wrap: wrap;
  }

  .prestashop-inventory .inventory-actions {
    display: flex;
    gap: 16px;
    align-items: center;
    flex-wrap: wrap;
  }

  .prestashop-inventory .inventory-search {
    margin-bottom: 24px;
  }

  .prestashop-inventory .inventory-toolbar-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    min-height: 38px;
  }

  .prestashop-inventory .inventory-toolbar-btn:hover,
  .prestashop-inventory .inventory-toolbar-btn:focus {
    text-decoration: none;
  }

  .prestashop-inventory .inventory-toolbar-btn i {
    font-size: 14px;
    line-height: 1;
  }

  .prestashop-inventory .inventory-search-wrap {
    max-width: 720px;
    position: relative;
  }

  .prestashop-inventory .inventory-tagbox {
    min-height: 42px;
    padding: 6px 34px 6px 8px;
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    gap: 6px;
    cursor: text;
    border: 1px solid #bbcdd2;
    border-radius: 4px;
    background: #fff;
    box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
  }

  .prestashop-inventory .inventory-tagbox:focus-within {
    border-color: #25b9d7;
    box-shadow: 0 0 0 1px rgba(37, 185, 215, 0.2);
  }

  .prestashop-inventory .inventory-tags {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    gap: 6px;
  }

  .prestashop-inventory .inventory-tag {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 7px 12px;
    background: #f3f3f3;
    border-radius: 2px;
    font-weight: 600;
  }

  .prestashop-inventory .inventory-tag-remove {
    border: 0;
    background: transparent;
    padding: 0;
    line-height: 1;
    font-size: 24px;
    color: #333;
  }

  .prestashop-inventory .inventory-tag-input {
    flex: 1 1 140px;
    min-width: 120px;
    border: 0 !important;
    outline: none !important;
    box-shadow: none !important;
    -webkit-box-shadow: none !important;
    padding: 4px 0;
    margin: 0;
    background: transparent !important;
    appearance: none;
    -webkit-appearance: none;
    border-radius: 0;
  }

  .prestashop-inventory .inventory-tag-input:focus,
  .prestashop-inventory .inventory-tag-input:hover,
  .prestashop-inventory .inventory-tag-input:active {
    border: 0 !important;
    outline: none !important;
    box-shadow: none !important;
    -webkit-box-shadow: none !important;
    background: transparent !important;
  }

  .prestashop-inventory .inventory-clear {
    position: absolute;
    top: 50%;
    right: 8px;
    transform: translateY(-50%);
    border: 0;
    background: transparent;
    color: #888;
    font-size: 22px;
    line-height: 1;
    padding: 0;
  }

  .prestashop-inventory .ios-switch {
    position: relative;
    display: inline-block;
    width: 28px;
    height: 16px;
  }

  .prestashop-inventory .ios-switch input {
    opacity: 0;
    width: 0;
    height: 0;
  }

  .prestashop-inventory .slider {
    position: absolute;
    inset: 0;
    cursor: pointer;
    background-color: #ccc;
    border-radius: 25px;
    transition: .4s;
  }

  .prestashop-inventory .slider:before {
    content: "";
    position: absolute;
    width: 12px;
    height: 12px;
    top: 2px;
    left: 2px;
    background: #fff;
    border-radius: 50%;
    box-shadow: 0 1px 2px rgba(0, 0, 0, 0.18);
    transition: .2s ease;
  }

  .prestashop-inventory input:checked + .slider {
    background: #4f955d;
  }

  .prestashop-inventory input:checked + .slider:before {
    transform: translateX(12px);
  }

  .prestashop-inventory .inventory-switch-row {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    margin: 0;
    font-weight: 400;
  }

  .prestashop-inventory .inventory-filters-menu {
    position: relative;
  }

  .prestashop-inventory .inventory-filter-toggle {
    position: relative;
    width: 42px;
    height: 42px;
    border: 0;
    border-radius: 4px;
    background: transparent;
    color: #1f1f1f;
    font-size: 22px;
    transition: color .15s ease, transform .15s ease;
  }

  .prestashop-inventory .inventory-filter-toggle:hover,
  .prestashop-inventory .inventory-filter-toggle:focus {
    color: #111;
    transform: scale(1.04);
    outline: none;
  }

  .prestashop-inventory .inventory-filter-toggle i {
    display: block;
    line-height: 1;
  }

  .prestashop-inventory .inventory-filter-badge {
    position: absolute;
    top: -6px;
    right: -6px;
    min-width: 18px;
    height: 18px;
    padding: 0 4px;
    border-radius: 999px;
    background: #d93025;
    color: #fff;
    font-size: 11px;
    font-weight: 700;
    line-height: 18px;
    text-align: center;
  }

  .prestashop-inventory .inventory-filter-dropdown {
    width: max-content;
    min-width: 0;
    max-width: calc(100vw - 32px);
    padding: 8px 0;
  }

  .prestashop-inventory .inventory-filter-row {
    display: flex;
    width: 100%;
    padding: 10px 16px;
    gap: 12px;
    cursor: pointer;
  }

  .prestashop-inventory .inventory-filter-row > span:last-child {
    flex: 1 1 auto;
    line-height: 1.3;
    white-space: nowrap;
  }

  .prestashop-inventory .inventory-filter-row:hover {
    background: #f5f7fa;
  }

  .prestashop-inventory img.img-thumbnail {
    width: 45px;
    height: 45px;
    object-fit: cover;
    border: 1px solid #ddd;
    border-radius: 8px;
    background: #fff;
    padding: 2px;
  }

  .prestashop-inventory .product-preview {
    position: relative;
    display: inline-flex;
    align-items: center;
    outline: none;
  }

  .prestashop-inventory .product-preview-card {
    position: absolute;
    left: calc(100% + 12px);
    top: 50%;
    z-index: 1000;
    display: none;
    min-width: 260px;
    padding: 14px 16px;
    background-color: #fff;
    color: #111;
    border-radius: 14px;
    box-shadow: 0 12px 28px rgba(0, 0, 0, 0.18), 0 4px 10px rgba(0, 0, 0, 0.12);
    transform: translateY(-50%);
    white-space: normal;
  }

  .prestashop-inventory .product-preview:hover .product-preview-card,
  .prestashop-inventory .product-preview:focus .product-preview-card,
  .prestashop-inventory .product-preview:focus-within .product-preview-card {
    display: block;
  }

  .prestashop-inventory .product-preview-title,
  .prestashop-inventory .product-preview-subtitle {
    display: block;
    line-height: 1.35;
  }

  .prestashop-inventory .product-preview-title {
    font-weight: 600;
  }

  .prestashop-inventory .product-preview-subtitle {
    margin-top: 4px;
    color: #666;
  }

  .prestashop-inventory .product-preview-image {
    display: block;
    width: 240px;
    max-width: min(240px, 70vw);
    height: auto;
    border-radius: 10px;
    margin-top: 10px;
  }

  .prestashop-inventory #productsTable {
    margin-bottom: 0;
    background: #fff;
  }

  .prestashop-inventory .inventory-pagination {
    margin-top: 18px;
    overflow-x: auto;
    overflow-y: hidden;
    padding-bottom: 4px;
  }

  .prestashop-inventory .inventory-pagination-inner {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 16px;
    flex-wrap: nowrap;
    min-width: max-content;
  }

  .prestashop-inventory .inventory-pagination-pages {
    display: flex;
    align-items: center;
    flex: 0 0 auto;
  }

  .prestashop-inventory .inventory-pagination-pages .pagination {
    display: flex;
    align-items: center;
    margin: 0;
    gap: 0;
  }

  .prestashop-inventory .inventory-pagination-pages .page-item {
    display: flex;
    align-items: center;
  }

  .prestashop-inventory .inventory-pagination-pages .page-item.current,
  .prestashop-inventory .inventory-pagination-pages .page-item.current.active {
    flex: 0 0 auto;
    width: auto;
    background: transparent;
    border: 0;
  }

  .prestashop-inventory .inventory-pagination-pages .page-item.current label {
    margin: 0;
    display: block;
    width: 48px !important;
    min-width: 48px !important;
    max-width: 48px !important;
    flex: 0 0 48px !important;
  }

  .prestashop-inventory .inventory-pagination-pages .page-item.current .jump-to-page,
  .prestashop-inventory .inventory-page-current {
    width: 48px !important;
    min-width: 48px !important;
    max-width: 48px !important;
    flex: 0 0 48px !important;
    height: 50px;
    border: 1px solid #d7d7d7;
    background: #fff;
    font-weight: 700;
    font-size: 16px;
    line-height: 1;
    padding: 0 4px;
    text-align: center;
    box-shadow: none;
    -webkit-appearance: none;
    -moz-appearance: none;
    appearance: none;
    border-radius: 0;
  }

  .prestashop-inventory .inventory-pagination-pages .page-link.previous,
  .prestashop-inventory .inventory-pagination-pages .page-link.next {
    min-width: 28px;
    height: 28px;
    padding: 0;
    border: 0;
    background: transparent;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    font-size: 34px;
    font-weight: 300;
    line-height: 1;
    color: #7a7a7a;
  }

  .prestashop-inventory .inventory-pagination-pages .page-link.previous span[aria-hidden="true"],
  .prestashop-inventory .inventory-pagination-pages .page-link.next span[aria-hidden="true"] {
    display: inline-block;
    transform: translateY(-1px);
  }

  .prestashop-inventory .inventory-page-current::-webkit-outer-spin-button,
  .prestashop-inventory .inventory-page-current::-webkit-inner-spin-button {
    -webkit-appearance: none;
    margin: 0;
  }

  .prestashop-inventory .inventory-pagination-pages .page-link {
    box-shadow: none;
  }

  .prestashop-inventory .inventory-pagination-pages .page-item.previous.disabled .page-link,
  .prestashop-inventory .inventory-pagination-pages .page-item.next.disabled .page-link {
    color: #cfcfcf;
    cursor: default;
  }

  .prestashop-inventory .inventory-pagination-status {
    font-size: 16px;
    color: #2b2b2b;
    white-space: nowrap;
    flex: 0 0 auto;
  }

  .prestashop-inventory .inventory-per-page {
    display: inline-flex;
    align-items: center;
    gap: 10px;
    margin: 0;
    font-weight: 400;
    font-size: 16px;
    white-space: nowrap;
    flex: 0 0 auto;
  }

  .prestashop-inventory .inventory-per-page-label {
    white-space: nowrap;
  }

  .prestashop-inventory .inventory-per-page-select {
    min-width: 74px;
    height: 50px;
    padding: 0 28px 0 14px;
    border: 1px solid #d7d7d7;
    border-radius: 0;
    background-color: #fff;
    font-size: 15px;
    box-shadow: none;
  }

  .prestashop-inventory #productsTable thead th {
    padding: 10px 14px;
    border: 0;
    border-bottom: 2px solid #1f1f1f;
    font-size: 13px;
    font-weight: 700;
    color: #1f1f1f;
    background: transparent;
    white-space: normal;
    line-height: 1.15;
  }

  .prestashop-inventory .inventory-sort-button {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 8px;
    width: 100%;
    padding: 0;
    border: 0;
    background: transparent;
    text-align: left;
    font: inherit;
    color: inherit;
  }

  .prestashop-inventory .inventory-sort-button-center {
    justify-content: center;
  }

  .prestashop-inventory .inventory-sort-indicator {
    width: 11px;
    min-width: 11px;
    height: 11px;
    position: relative;
    opacity: .72;
    display: inline-block;
  }

  .prestashop-inventory .inventory-sort-indicator:before {
    content: "";
    position: absolute;
    top: 2px;
    left: 2px;
    width: 6px;
    height: 6px;
    border-right: 2px solid #2f2f2f;
    border-bottom: 2px solid #2f2f2f;
    transform: rotate(45deg);
  }

  .prestashop-inventory .inventory-sortable.is-active .inventory-sort-indicator {
    opacity: 1;
  }

  .prestashop-inventory .inventory-sortable.sort-asc .inventory-sort-indicator:before {
    top: 3px;
    transform: rotate(225deg);
  }

  .prestashop-inventory #productsTable tbody td {
    padding: 8px 14px;
    border: 0;
    border-bottom: 1px solid #ececec;
    vertical-align: middle;
    font-size: 13px;
    color: #2b2b2b;
    background: #fff;
    transition: background-color .15s ease;
  }

  .prestashop-inventory #productsTable tbody tr:hover td {
    background: #f4f8fb;
  }

  .prestashop-inventory .inventory-col-id {
    width: 92px;
    font-weight: 400;
  }

  .prestashop-inventory .inventory-col-image {
    width: 86px;
  }

  .prestashop-inventory .inventory-col-name {
    min-width: 360px;
  }

  .prestashop-inventory .inventory-col-price,
  .prestashop-inventory .inventory-col-active,
  .prestashop-inventory .inventory-col-qty,
  .prestashop-inventory .inventory-col-value {
    white-space: nowrap;
    font-variant-numeric: tabular-nums;
  }

  .prestashop-inventory .inventory-col-actions {
    width: 88px;
  }

  .prestashop-inventory .inventory-col-active {
    width: 110px;
  }

  .prestashop-inventory .inventory-product-name {
    font-size: 13px;
    font-weight: 500;
    line-height: 1.2;
  }

  .prestashop-inventory .inventory-product-link {
    color: #2b2b2b;
    text-decoration: none;
  }

  .prestashop-inventory .inventory-product-link:hover,
  .prestashop-inventory .inventory-product-link:focus {
    color: #25b9d7;
    text-decoration: none;
    outline: none;
  }

  .prestashop-inventory .inventory-product-meta {
    margin-top: 2px;
    color: #a0a0a0;
    font-size: 11px;
    line-height: 1.15;
  }

  .prestashop-inventory .inventory-product-ean {
    margin-top: 2px;
    color: #6f6f6f;
    font-size: 11px;
    line-height: 1.15;
    font-variant-numeric: tabular-nums;
    border: 0;
    background: transparent;
    padding: 0;
    text-align: left;
    cursor: pointer;
  }

  .prestashop-inventory .inventory-product-ean:hover,
  .prestashop-inventory .inventory-product-ean:focus {
    color: #25b9d7;
    outline: none;
  }

  .prestashop-inventory .inventory-product-ean.is-copied {
    color: #4f955d;
  }

  .prestashop-inventory .inventory-no-image {
    color: #777;
  }

  .prestashop-inventory .inline-editor {
    display: inline-flex;
    flex-direction: column;
    align-items: center;
    gap: 8px;
  }

  .prestashop-inventory .inline-editor-input {
    width: 96px !important;
    min-width: 96px;
    text-align: center;
    margin: 0 auto;
  }

  .prestashop-inventory .inline-editor-actions {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    flex-wrap: nowrap;
  }

  .prestashop-inventory .inline-editor-actions .btn {
    min-width: 88px;
    margin: 0;
  }

  .prestashop-inventory .weight-editor .inline-editor-actions {
    gap: 6px;
  }

  .prestashop-inventory .weight-editor .inline-editor-actions .btn {
    min-width: 0;
    padding: 6px 12px;
    line-height: 1.2;
  }

  .prestashop-inventory .weight-editor .save-weight {
    min-width: 38px;
    padding: 6px 10px;
  }

  .prestashop-inventory .save-price,
  .prestashop-inventory .save-retail-price,
  .prestashop-inventory .save-quantity {
    min-width: 38px;
    padding: 6px 10px;
  }

  .prestashop-inventory .inventory-summary-row td {
    background: #fafafa !important;
    font-weight: 700;
  }

  .prestashop-inventory .inventory-head-title,
  .prestashop-inventory .inventory-head-subtitle {
    display: block;
  }

  .prestashop-inventory .inventory-head-subtitle {
    margin-top: 2px;
  }

  .prestashop-inventory .inventory-row-switch {
    position: relative;
    display: inline-block;
    width: 28px;
    height: 16px;
    margin: 0;
  }

  .prestashop-inventory .inventory-row-switch input {
    opacity: 0;
    width: 0;
    height: 0;
  }

  .prestashop-inventory .inventory-row-slider {
    position: absolute;
    inset: 0;
    border-radius: 999px;
    background: #d3d3d3;
    transition: .2s ease;
    cursor: pointer;
  }

  .prestashop-inventory .inventory-row-slider:before {
    content: "";
    position: absolute;
    top: 2px;
    left: 2px;
    width: 12px;
    height: 12px;
    border-radius: 50%;
    background: #fff;
    box-shadow: 0 1px 2px rgba(0, 0, 0, 0.18);
    transition: .2s ease;
  }

  .prestashop-inventory .inventory-row-switch input:checked + .inventory-row-slider {
    background: #4f955d;
  }

  .prestashop-inventory .inventory-row-switch input:checked + .inventory-row-slider:before {
    transform: translateX(12px);
  }

  .prestashop-inventory .inventory-row-switch input:disabled + .inventory-row-slider {
    opacity: .65;
    cursor: progress;
  }

  .prestashop-inventory .inventory-actions-menu {
    position: relative;
    display: inline-flex;
    justify-content: center;
  }

  .prestashop-inventory .inventory-actions-toggle {
    width: 34px;
    height: 34px;
    border: 0;
    background: transparent;
    color: #1f1f1f;
    font-size: 26px;
    line-height: 1;
    padding: 0;
  }

  .prestashop-inventory .inventory-actions-dropdown {
    position: absolute;
    top: calc(100% + 8px);
    right: 0;
    z-index: 30;
    min-width: 220px;
    padding: 8px 0;
    border: 1px solid #e3e3e3;
    background: #fff;
    box-shadow: 0 8px 18px rgba(0, 0, 0, 0.12);
    display: none;
    text-align: left;
  }

  .prestashop-inventory .inventory-actions-menu.is-open .inventory-actions-dropdown {
    display: block;
  }

  .prestashop-inventory .inventory-actions-dropdown button {
    width: 100%;
    padding: 12px 16px;
    border: 0;
    background: transparent;
    display: flex;
    align-items: center;
    gap: 12px;
    font-size: 15px;
    color: #222;
    text-align: left;
  }

  .prestashop-inventory .inventory-actions-dropdown button:hover {
    background: #f5f7fa;
  }

  .prestashop-inventory .inventory-actions-dropdown i {
    width: 18px;
    color: #8a8a8a;
    text-align: center;
  }

  .prestashop-inventory .inventory-row-actions {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 4px;
  }

  .prestashop-inventory .inventory-sales-trigger {
    width: 34px;
    height: 34px;
    border: 1px solid #d7e0ea;
    border-radius: 10px;
    background: linear-gradient(180deg, #ffffff 0%, #f5f8fb 100%);
    color: #0f6b8a;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    padding: 0;
    box-shadow: 0 6px 14px rgba(15, 107, 138, 0.08);
    transition: transform .18s ease, box-shadow .18s ease, border-color .18s ease;
  }

  .prestashop-inventory .inventory-sales-trigger:hover,
  .prestashop-inventory .inventory-sales-trigger:focus {
    border-color: #9bc8d8;
    box-shadow: 0 10px 22px rgba(15, 107, 138, 0.16);
    transform: translateY(-1px);
    text-decoration: none;
  }

  .prestashop-inventory .inventory-sales-trigger i {
    font-size: 15px;
    line-height: 1;
  }

  .inventory-sales-modal {
    position: fixed;
    inset: 0;
    z-index: 1050;
    display: none;
  }

  .inventory-sales-modal.is-open {
    display: block;
  }

  .inventory-sales-modal-backdrop {
    position: absolute;
    inset: 0;
    background: rgba(11, 20, 28, 0.58);
    backdrop-filter: blur(6px);
  }

  .inventory-sales-modal-dialog {
    position: relative;
    width: min(1120px, calc(100vw - 40px));
    margin: 34px auto;
    border-radius: 32px;
    background:
      radial-gradient(circle at top left, rgba(29, 141, 177, 0.08), transparent 24%),
      linear-gradient(180deg, #ffffff 0%, #f6f9fc 100%);
    box-shadow: 0 34px 90px rgba(11, 20, 28, 0.24);
    padding: 34px 32px 30px;
    overflow: hidden;
  }

  .inventory-sales-modal-dialog::before {
    content: "";
    position: absolute;
    inset: 0 0 auto 0;
    height: 6px;
    background: linear-gradient(90deg, #1d8db1 0%, #62c2b2 50%, #f2c14e 100%);
  }

  .inventory-sales-modal-close {
    position: absolute;
    top: 18px;
    right: 18px;
    width: 52px;
    height: 52px;
    border: 0;
    border-radius: 999px;
    background: linear-gradient(180deg, rgba(12, 32, 44, 0.05) 0%, rgba(12, 32, 44, 0.09) 100%);
    color: #123040;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    font-size: 52px;
    font-family: Arial, sans-serif;
    font-weight: 700;
    line-height: .8;
    padding: 0;
    box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.85);
    transition: transform .18s ease, box-shadow .18s ease, background .18s ease;
  }

  .inventory-sales-modal-close:hover,
  .inventory-sales-modal-close:focus {
    background: linear-gradient(180deg, rgba(12, 32, 44, 0.09) 0%, rgba(12, 32, 44, 0.13) 100%);
    box-shadow: 0 10px 20px rgba(18, 48, 64, 0.12);
    transform: translateY(-1px);
  }

  .inventory-sales-modal-head {
    margin-bottom: 16px;
    padding: 10px 86px 8px 4px;
    border-bottom: 0;
  }

  .inventory-sales-modal-media {
    display: flex;
    align-items: flex-start;
    gap: 18px;
    min-width: 0;
  }

  .inventory-sales-modal-thumb-wrap {
    width: 84px;
    height: 84px;
    flex: 0 0 84px;
    position: relative;
    padding: 6px;
    border-radius: 22px;
    background: #ffffff;
    border: 1px solid rgba(198, 214, 227, 0.9);
    box-shadow: 0 14px 28px rgba(22, 52, 71, 0.08);
  }

  .inventory-sales-modal-thumb,
  .inventory-sales-modal-thumb-fallback {
    width: 100%;
    height: 100%;
    border-radius: 16px;
    display: block;
  }

  .inventory-sales-modal-thumb {
    object-fit: cover;
    background: #eef4f8;
  }

  .inventory-sales-modal-thumb.is-hidden {
    display: none;
  }

  .inventory-sales-modal-thumb-fallback {
    display: none;
    background: linear-gradient(135deg, #173548 0%, #2b6a84 100%);
  }

  .inventory-sales-modal-thumb-fallback.is-visible {
    display: block;
  }

  .inventory-sales-modal-copy {
    min-width: 0;
    padding-top: 4px;
    background: transparent;
  }

  .inventory-sales-modal-title {
    margin: 0;
    max-width: 860px;
    padding: 0 !important;
    font-size: clamp(16px, 1.15vw, 20px);
    line-height: 1.35;
    letter-spacing: -.01em;
    color: #60798a;
    font-weight: 600;
    word-break: break-word;
    text-wrap: pretty;
    text-decoration: none;
    background: transparent;
    border: 0 !important;
    border-bottom: 0 !important;
    box-shadow: none !important;
    outline: 0;
  }

  .inventory-sales-modal-subtitle {
    margin-top: 6px;
    font-size: clamp(16px, 1.15vw, 20px);
    line-height: 1.35;
    color: #60798a;
    font-weight: 600;
    word-break: break-word;
    text-wrap: pretty;
  }

  .inventory-sales-modal-subtitle:empty {
    display: none;
  }

  .inventory-sales-modal-state {
    display: none;
    padding: 24px;
    border-radius: 18px;
    background: #f4f7fa;
    color: #51606d;
    text-align: center;
    font-size: 15px;
    font-weight: 600;
  }

  .inventory-sales-modal-state.is-visible {
    display: block;
  }

  .inventory-sales-modal-content {
    display: none;
  }

  .inventory-sales-modal-content.is-visible {
    display: block;
  }

  .inventory-sales-summary {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 12px;
    margin-bottom: 14px;
  }

  .inventory-sales-summary-card {
    min-height: 0;
    border-radius: 22px;
    padding: 14px 16px 12px;
    background:
      radial-gradient(circle at top right, rgba(29, 141, 177, 0.07), transparent 34%),
      linear-gradient(180deg, #ffffff 0%, #f8fbfd 100%);
    border: 1px solid rgba(208, 222, 234, 0.95);
    box-shadow: 0 10px 24px rgba(17, 33, 45, 0.05);
  }

  .inventory-sales-summary-label {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-height: 30px;
    padding: 0 11px;
    border-radius: 10px;
    background: linear-gradient(135deg, #173548 0%, #234b62 100%);
    color: #f5fbff;
    font-size: 13px;
    font-weight: 800;
    text-transform: uppercase;
    letter-spacing: .12em;
  }

  .inventory-sales-summary-value {
    display: flex;
    align-items: center;
    gap: 10px;
    max-width: 100%;
    font-size: clamp(15px, 1.02vw, 18px);
    line-height: 1.2;
    font-weight: 800;
    letter-spacing: -.025em;
    color: #12232f;
  }

  .inventory-sales-summary-text {
    min-width: 0;
  }

  .inventory-sales-summary-note {
    margin-top: 10px;
  }

  .inventory-sales-summary-note strong {
    color: #12232f;
    font-weight: 800;
  }

  .inventory-sales-summary-lines {
    display: grid;
    gap: 4px;
  }

  .inventory-sales-summary-line {
    display: flex;
    align-items: baseline;
    justify-content: space-between;
    gap: 12px;
    color: #5d7687;
    font-size: 12px;
    line-height: 1.32;
    padding-top: 5px;
    border-top: 1px solid rgba(208, 222, 234, 0.7);
  }

  .inventory-sales-summary-line-label {
    text-transform: uppercase;
    letter-spacing: .08em;
    font-size: 11px;
    color: #7b8f9e;
    flex: 0 0 auto;
  }

  .inventory-sales-summary-line-value {
    text-align: right;
  }

  .inventory-sales-chart {
    border-radius: 24px;
    padding: 14px 14px;
    background:
      radial-gradient(circle at top right, rgba(61, 198, 228, 0.12), transparent 28%),
      radial-gradient(circle at bottom left, rgba(245, 197, 92, 0.12), transparent 24%),
      linear-gradient(180deg, #f9fcff 0%, #eef5fb 100%);
    color: #19374a;
    box-shadow: 0 16px 32px rgba(24, 50, 68, 0.08);
  }

  .inventory-sales-chart-layout {
    display: grid;
    grid-template-columns: 42px minmax(0, 1fr) 42px;
    gap: 8px;
    align-items: center;
  }

  .inventory-sales-chart-panel {
    min-width: 0;
  }

  .inventory-sales-chart-meta {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 16px;
    margin-bottom: 8px;
  }

  .inventory-sales-chart-range {
    font-size: 13px;
    text-transform: uppercase;
    letter-spacing: .12em;
    line-height: 1.3;
    color: rgba(56, 97, 121, 0.72);
  }

  .inventory-sales-chart-year {
    font-size: 15px;
    line-height: 1;
    font-weight: 800;
    letter-spacing: .02em;
    color: #1c3f52;
  }

  .inventory-sales-chart-surface {
    border-radius: 18px;
    background:
      linear-gradient(180deg, rgba(255, 255, 255, 0.98) 0%, rgba(244, 249, 253, 0.98) 100%);
    padding: 10px 10px 8px;
    box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.92), 0 8px 18px rgba(27, 59, 77, 0.04);
    border: 1px solid rgba(194, 214, 229, 0.78);
  }

  .inventory-sales-chart-canvas {
    width: 100%;
    height: 220px;
    position: relative;
  }

  .inventory-sales-chart-canvas canvas {
    width: 100% !important;
    height: 100% !important;
    display: block;
  }

  .inventory-sales-chart-footnote {
    display: none;
  }

  .inventory-sales-nav {
    align-self: center;
    width: 48px;
    height: 48px;
    border: 0;
    border-radius: 999px;
    background: rgba(255, 255, 255, 0.94);
    color: #18384a;
    box-shadow: 0 12px 24px rgba(12, 32, 44, 0.18);
    display: inline-flex;
    align-items: center;
    justify-content: center;
    font-size: 22px;
    font-weight: 600;
    line-height: 1;
    transition: transform .18s ease, box-shadow .18s ease, opacity .18s ease;
  }

  .inventory-sales-nav span[aria-hidden="true"] {
    display: block;
    font-size: 42px;
    font-family: Arial, sans-serif;
    font-weight: 700;
    line-height: .7;
    transform: translateY(-1px);
  }

  .inventory-sales-nav:hover,
  .inventory-sales-nav:focus {
    transform: translateY(-1px) scale(1.02);
    box-shadow: 0 16px 30px rgba(12, 32, 44, 0.22);
  }

  .inventory-sales-nav.is-disabled {
    opacity: .35;
    pointer-events: none;
  }

  @media (max-width: 900px) {
    .inventory-sales-summary {
      grid-template-columns: 1fr;
    }

    .inventory-sales-chart-layout {
      grid-template-columns: 1fr;
      gap: 10px;
    }

    .inventory-sales-modal-dialog {
      width: calc(100vw - 20px);
      margin: 24px auto;
      padding: 26px 18px 18px;
    }

    .inventory-sales-modal-head {
      padding: 4px 56px 8px 0;
    }

    .inventory-sales-modal-title {
      font-size: 18px;
    }

    .inventory-sales-modal-thumb-wrap {
      width: 64px;
      height: 64px;
    }

    .inventory-sales-nav {
      width: 42px;
      height: 42px;
      justify-self: center;
    }

    .inventory-sales-summary-line {
      flex-direction: column;
      align-items: flex-start;
      gap: 4px;
    }

    .inventory-sales-summary-line-value {
      text-align: left;
    }

    .inventory-sales-chart {
      padding: 12px 10px;
    }

    .inventory-sales-chart-canvas {
      height: 190px;
    }
  }
</style>

<script src="{$inventoryModuleBaseUrl|escape:'html':'UTF-8'}views/js/chart.umd.min.js"></script>
<script>
  (function () {
    function getDirectContainerFluid(headerToolbar) {
      if (!headerToolbar) {
        return null;
      }

      var children = headerToolbar.children || [];
      for (var i = 0; i < children.length; i++) {
        if (children[i].classList && children[i].classList.contains('container-fluid')) {
          return children[i];
        }
      }

      return headerToolbar.querySelector('.container-fluid');
    }

    function mountBoTabs(sourceId, attempt) {
      var source = document.getElementById(sourceId);
      if (!source) {
        return true;
      }

      var headerToolbar = document.querySelector('.header-toolbar.d-print-none, body > .header-toolbar, #main-div > .header-toolbar, .content-div > .header-toolbar, .header-toolbar');
      var headerContainer = getDirectContainerFluid(headerToolbar);
      if (!headerToolbar || !headerContainer) {
        if ((attempt || 0) < 100) {
          window.setTimeout(function () {
            mountBoTabs(sourceId, (attempt || 0) + 1);
          }, 100);
          return false;
        }

        source.hidden = false;
        return false;
      }

      var mounted = document.getElementById('head_tabs');
      if (!mounted) {
        mounted = source.cloneNode(true);
        mounted.id = 'head_tabs';
        mounted.hidden = false;
      }

      if (mounted.parentNode !== headerToolbar || mounted.previousElementSibling !== headerContainer) {
        headerContainer.insertAdjacentElement('afterend', mounted);
      }

      var contentDiv = document.querySelector('#main-div > .content-div');
      if (contentDiv) {
        contentDiv.classList.add('with-tabs');
      }

      source.hidden = true;
      return true;
    }

    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', function () {
        mountBoTabs('psinventory-head-tabs-source', 0);
      });
    } else {
      mountBoTabs('psinventory-head-tabs-source', 0);
    }

    window.addEventListener('load', function () {
      mountBoTabs('psinventory-head-tabs-source', 0);
    });

    var mountObserver = new MutationObserver(function () {
      mountBoTabs('psinventory-head-tabs-source', 0);
    });
    mountObserver.observe(document.documentElement, {ldelim}childList: true, subtree: true{rdelim});
    window.setTimeout(function () {
      mountObserver.disconnect();
    }, 10000);
  })();

  window.prestashopInventoryConfig = {
    ajaxUrl: '{$inventoryAjaxUrl|escape:'javascript'}',
    exportUrl: '{$inventoryExportUrl|escape:'javascript'}',
    languageIso: '{$inventoryLanguageIso|escape:'javascript'}',
    canEdit: {$inventoryCanEdit|intval}
  };

  (function () {
    var sourceTranslations = {$inventoryTranslationsJson nofilter};
    var translations = {
      no: sourceTranslations.id,
      title: sourceTranslations.report_title,
      activeOnly: sourceTranslations.show_only_active_products,
      onlyAvailable: sourceTranslations.show_only_available_in_stock,
      missingPurchasePriceOnly: sourceTranslations.show_only_missing_purchase_price,
      showWeight: sourceTranslations.show_product_weight,
      missingWeightOnly: sourceTranslations.show_only_missing_weight,
      showBrutto: sourceTranslations.show_retail_prices_gross,
      searchPlaceholder: sourceTranslations.search_placeholder,
      picture: sourceTranslations.image,
      name: sourceTranslations.product_name,
      active: sourceTranslations.active,
      weight: sourceTranslations.product_weight,
      price: sourceTranslations.purchase_price_net,
      priceBrutto: sourceTranslations.retail_price_gross,
      qty: sourceTranslations.available_quantity,
      value: sourceTranslations.purchase_value_net,
      valueBrutto: sourceTranslations.retail_value_gross,
      save: sourceTranslations.save,
      cancel: sourceTranslations.cancel,
      enterQty: sourceTranslations.enter_qty,
      enterPrice: sourceTranslations.enter_price,
      enterRetailPrice: sourceTranslations.enter_retail_price,
      enterWeight: sourceTranslations.enter_weight,
      errorSave: sourceTranslations.error_save,
      errorNetwork: sourceTranslations.error_network,
      errorQtySave: sourceTranslations.error_qty_save,
      errorWeightSave: sourceTranslations.error_weight_save,
      errorHide: sourceTranslations.error_hide,
      hideForever: sourceTranslations.hide_forever,
      typeQty: sourceTranslations.type_qty,
      typePrice: sourceTranslations.type_price,
      typeWeight: sourceTranslations.type_weight,
      errorToggle: sourceTranslations.error_toggle,
      copied: sourceTranslations.copied,
      copyError: sourceTranslations.copy_error,
      loadError: sourceTranslations.load_error,
      salesChart: sourceTranslations.sales_chart,
      salesStatsTitle: sourceTranslations.sales_stats_title,
      salesStatsLoading: sourceTranslations.sales_stats_loading,
      salesStatsEmpty: sourceTranslations.sales_stats_empty,
      salesMonthsRange: sourceTranslations.sales_months_range,
      salesTotalSold: sourceTranslations.sales_total_sold,
      salesBestMonth: sourceTranslations.sales_best_month,
      salesMonthsCount: sourceTranslations.sales_months_count,
      salesUnits: sourceTranslations.sales_units,
      year: sourceTranslations.year,
      errorSalesStats: sourceTranslations.error_sales_stats,
      close: sourceTranslations.close,
      previousYear: sourceTranslations.previous_year,
      nextYear: sourceTranslations.next_year
    };

    var LS_QUERY = 'ps_inventory_query';
    var LS_ACTIVE_ONLY = 'ps_inventory_activeOnly';
    var LS_ONLY = 'ps_inventory_onlyAvailable';
    var LS_MISSING_PURCHASE = 'ps_inventory_missingPurchasePriceOnly';
    var LS_SHOW_WEIGHT = 'ps_inventory_showWeight';
    var LS_MISSING_WEIGHT = 'ps_inventory_missingWeightOnly';
    var LS_BRUTTO = 'ps_inventory_showBrutto';
    var LS_PAGE = 'ps_inventory_page';
    var LS_PER_PAGE = 'ps_inventory_per_page';
    var LS_SORT_FIELD = 'ps_inventory_sort_field';
    var LS_SORT_DIR = 'ps_inventory_sort_dir';
    var currentPage = Math.max(parseInt(localStorage.getItem(LS_PAGE) || '1', 10), 1);
    var currentPerPage = parseInt(localStorage.getItem(LS_PER_PAGE) || '20', 10);
    if ([20, 50, 100, 200].indexOf(currentPerPage) === -1) {
      currentPerPage = 20;
    }
    var currentSortField = localStorage.getItem(LS_SORT_FIELD) || 'product_name';
    var currentSortDir = localStorage.getItem(LS_SORT_DIR) || 'ASC';
    var salesModalState = {
      productId: 0,
      productAttributeId: 0,
      productName: '',
      combinationName: '',
      imageSrc: '',
      months: 12,
      offsetMonths: 0
    };
    var salesChartInstance = null;

    function t(key) {
      return translations[key] ? translations[key] : key;
    }

    function parseKeywords(raw) {
      return (raw || '').trim().split(/[,\s]+/g).map(function (item) {
        return item.trim();
      }).filter(Boolean);
    }

    function applyLanguage() {
      document.querySelector('#thNo .inventory-head-title').textContent = t('no');
      document.getElementById('activeOnlyLabel').textContent = t('activeOnly');
      document.getElementById('onlyAvailableLabel').textContent = t('onlyAvailable');
      document.getElementById('missingPurchasePriceOnlyLabel').textContent = t('missingPurchasePriceOnly');
      document.getElementById('showWeightLabel').textContent = t('showWeight');
      document.getElementById('missingWeightOnlyLabel').textContent = t('missingWeightOnly');
      document.getElementById('showBruttoLabel').textContent = t('showBrutto');
      document.getElementById('searchInput').setAttribute('placeholder', t('searchPlaceholder'));
      document.getElementById('thPicture').textContent = t('picture');
      document.querySelector('#thName .inventory-head-title').textContent = t('name');
      document.querySelector('#thActive .inventory-head-title').textContent = t('active');
      document.querySelector('#thWeight .inventory-head-title').textContent = t('weight');
      document.querySelector('#thPrice .inventory-head-title').textContent = t('price');
      document.querySelector('#thPriceBrutto .inventory-head-title').textContent = t('priceBrutto');
      document.querySelector('#thQty .inventory-head-title').textContent = t('qty');
      document.getElementById('thValue').textContent = t('value');
      document.getElementById('thValueBrutto').textContent = t('valueBrutto');
      renderSortState();
    }

    function toggleWeightColumns(show, shouldReload) {
      document.getElementById('thWeight').style.display = show ? '' : 'none';
      if (shouldReload === false) {
        return;
      }

      currentPage = 1;
      localStorage.setItem(LS_PAGE, String(currentPage));
      loadTable(getSearchQuery(), document.getElementById('activeOnly').checked, document.getElementById('onlyAvailable').checked, document.getElementById('missingPurchasePriceOnly').checked, document.getElementById('missingWeightOnly').checked);
    }

    function toggleBruttoColumns(show, shouldReload) {
      var display = show ? '' : 'none';
      document.getElementById('thPriceBrutto').style.display = display;
      document.getElementById('thValueBrutto').style.display = display;
      if (shouldReload === false) {
        return;
      }

      currentPage = 1;
      localStorage.setItem(LS_PAGE, String(currentPage));
      loadTable(getSearchQuery(), document.getElementById('activeOnly').checked, document.getElementById('onlyAvailable').checked, document.getElementById('missingPurchasePriceOnly').checked, document.getElementById('missingWeightOnly').checked);
    }

    function normalizeKeywords(value) {
      return (value || []).map(function (item) {
        return item.trim();
      }).filter(Boolean);
    }

    function getSearchKeywords() {
      return normalizeKeywords($('#searchTags').data('keywords') || []);
    }

    function setSearchKeywords(keywords) {
      $('#searchTags').data('keywords', normalizeKeywords(keywords));
      renderSearchTags();
    }

    function getSearchQuery() {
      return getSearchKeywords().join(' ');
    }

    function renderSearchTags() {
      var keywords = getSearchKeywords();
      var $tags = $('#searchTags');

      $tags.empty();
      keywords.forEach(function (keyword, index) {
        var $tag = $('<span class="inventory-tag"></span>');
        $tag.append($('<span></span>').text(keyword));
        $tag.append($('<button type="button" class="inventory-tag-remove" aria-label="Remove">&times;</button>').attr('data-index', index));
        $tags.append($tag);
      });
    }

    function persistAndLoadKeywords(keywords) {
      setSearchKeywords(keywords);
      localStorage.setItem(LS_QUERY, getSearchQuery());
      currentPage = 1;
      localStorage.setItem(LS_PAGE, String(currentPage));
      loadTable(getSearchQuery(), $('#activeOnly').is(':checked'), $('#onlyAvailable').is(':checked'), $('#missingPurchasePriceOnly').is(':checked'), $('#missingWeightOnly').is(':checked'));
    }

    function appendKeywordsFromInput() {
      var current = $('#searchInput').val();
      var inputKeywords = parseKeywords(current);
      if (!inputKeywords.length) {
        return false;
      }

      var merged = getSearchKeywords().concat(inputKeywords);
      persistAndLoadKeywords(merged);
      $('#searchInput').val('');

      return true;
    }

    function loadTable(query, activeOnly, onlyAvailable, missingPurchasePriceOnly, missingWeightOnly) {
      var keywords = parseKeywords(query);
      var showWeight = document.getElementById('showWeight').checked;
      var showBrutto = document.getElementById('showBrutto').checked;

      $.post(window.prestashopInventoryConfig.ajaxUrl + '&action=FetchProducts', {
        query: query || '',
        keywords: keywords,
        activeOnly: activeOnly ? 1 : 0,
        onlyAvailable: onlyAvailable ? 1 : 0,
        missingPurchasePriceOnly: missingPurchasePriceOnly ? 1 : 0,
        missingWeightOnly: missingWeightOnly ? 1 : 0,
        showWeight: showWeight ? 1 : 0,
        showBrutto: showBrutto ? 1 : 0,
        lang: window.prestashopInventoryConfig.languageIso || 'en',
        sort_field: currentSortField,
        sort_dir: currentSortDir,
        page: currentPage,
        per_page: currentPerPage
      }, null, 'json').done(function (resp) {
        $('#productsTable tbody').html(resp && resp.tbody ? resp.tbody : '');
        $('#inventoryPagination').html(resp && resp.pagination ? resp.pagination : '');
        if (resp && resp.meta) {
          currentPage = Math.max(parseInt(resp.meta.current_page || 1, 10), 1);
          currentPerPage = parseInt(resp.meta.per_page || currentPerPage, 10);
          localStorage.setItem(LS_PAGE, String(currentPage));
          localStorage.setItem(LS_PER_PAGE, String(currentPerPage));
        }
      }).fail(function () {
        var colspan = (document.getElementById('showWeight').checked ? 9 : 8) + (document.getElementById('showBrutto').checked ? 2 : 0);
        $('#productsTable tbody').html('<tr><td colspan="' + colspan + '" class="text-center text-danger">' + t('loadError') + '</td></tr>');
        $('#inventoryPagination').empty();
      });
    }

    function renderSortState() {
      $('.inventory-sortable').removeClass('is-active sort-asc sort-desc');
      var $active = $('.inventory-sortable[data-sort-field="' + currentSortField + '"]');
      $active.addClass('is-active ' + (currentSortDir === 'DESC' ? 'sort-desc' : 'sort-asc'));
    }

    function updateFilterBadge() {
      var count = 0;
      ['activeOnly', 'onlyAvailable', 'missingPurchasePriceOnly', 'showWeight', 'missingWeightOnly', 'showBrutto'].forEach(function (id) {
        var input = document.getElementById(id);
        if (input && input.checked) {
          count += 1;
        }
      });

      var badge = document.getElementById('filterActiveCount');
      if (badge) {
        badge.textContent = String(count);
      }
    }

    function copyTextToClipboard(text) {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        return navigator.clipboard.writeText(text);
      }

      return new Promise(function (resolve, reject) {
        var input = document.createElement('textarea');
        input.value = text;
        input.setAttribute('readonly', '');
        input.style.position = 'absolute';
        input.style.left = '-9999px';
        document.body.appendChild(input);
        input.select();

        try {
          document.execCommand('copy');
          document.body.removeChild(input);
          resolve();
        } catch (error) {
          document.body.removeChild(input);
          reject(error);
        }
      });
    }

    function escapeHtml(value) {
      return String(value == null ? '' : value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
    }

    function formatSalesMonth(monthDate) {
      var date = new Date(monthDate + 'T00:00:00');

      try {
        return new Intl.DateTimeFormat(window.prestashopInventoryConfig.languageIso || 'en', {
          month: 'short',
          year: 'numeric'
        }).format(date);
      } catch (error) {
        return monthDate;
      }
    }

    function formatSalesMonthShort(monthDate) {
      var date = new Date(monthDate + 'T00:00:00');

      try {
        return new Intl.DateTimeFormat(window.prestashopInventoryConfig.languageIso || 'en', {
          month: 'short'
        }).format(date);
      } catch (error) {
        return monthDate;
      }
    }

    function formatSalesMonthName(monthDate, grammaticalCase) {
      var date = new Date(monthDate + 'T00:00:00');
      var iso = String(window.prestashopInventoryConfig.languageIso || 'en').toLowerCase();
      var monthIndex = date.getMonth();

      if (iso.indexOf('pl') === 0) {
        var polishMonthsStandalone = ['styczeń', 'luty', 'marzec', 'kwiecień', 'maj', 'czerwiec', 'lipiec', 'sierpień', 'wrzesień', 'październik', 'listopad', 'grudzień'];
        var polishMonthsLocative = ['styczniu', 'lutym', 'marcu', 'kwietniu', 'maju', 'czerwcu', 'lipcu', 'sierpniu', 'wrześniu', 'październiku', 'listopadzie', 'grudniu'];

        return grammaticalCase === 'locative'
          ? polishMonthsLocative[monthIndex]
          : polishMonthsStandalone[monthIndex];
      }

      try {
        return new Intl.DateTimeFormat(window.prestashopInventoryConfig.languageIso || 'en', {
          month: 'long'
        }).format(date);
      } catch (error) {
        return monthDate;
      }
    }

    function buildYearSummary(year, quantities) {
      var today = new Date();
      var currentYear = today.getFullYear();
      var currentMonthIndex = today.getMonth();
      var currentDay = today.getDate();
      var daysInCurrentMonth = new Date(currentYear, currentMonthIndex + 1, 0).getDate();
      var lastIncludedMonthIndex = year === currentYear ? Math.min(currentMonthIndex, quantities.length - 1) : (quantities.length - 1);
      var elapsedMonthUnits = quantities.length;
      var total = 0;
      var minValue = null;
      var maxValue = null;
      var minMonthIndex = 0;
      var maxMonthIndex = 0;

      quantities.forEach(function (qty, index) {
        if (index > lastIncludedMonthIndex) {
          return;
        }

        var value = Number(qty || 0);
        total += value;

        if (minValue === null || value < minValue) {
          minValue = value;
          minMonthIndex = index;
        }

        if (maxValue === null || value > maxValue) {
          maxValue = value;
          maxMonthIndex = index;
        }
      });

      if (year === currentYear) {
        elapsedMonthUnits = currentMonthIndex + (daysInCurrentMonth > 0 ? (currentDay / daysInCurrentMonth) : 0);
      }

      if (!isFinite(elapsedMonthUnits) || elapsedMonthUnits <= 0) {
        elapsedMonthUnits = Math.max(lastIncludedMonthIndex + 1, 1);
      }

      return {
        year: year,
        total: total,
        average: total / elapsedMonthUnits,
        minValue: minValue === null ? 0 : minValue,
        maxValue: maxValue === null ? 0 : maxValue,
        minMonthDate: year + '-' + String(minMonthIndex + 1).padStart(2, '0') + '-01',
        maxMonthDate: year + '-' + String(maxMonthIndex + 1).padStart(2, '0') + '-01'
      };
    }

    function renderYearSummaryCard(summary) {
      var averageLabel = Number(summary.average || 0).toFixed(1).replace(/\.0$/, '');
      var title = 'łącznie sprzedano ' + summary.total + ' ' + t('salesUnits');
      var minLine = '<span class="inventory-sales-summary-line-label">Min</span><span class="inventory-sales-summary-line-value"><strong>' + summary.minValue + ' ' + escapeHtml(t('salesUnits')) + '</strong> w ' + escapeHtml(formatSalesMonthName(summary.minMonthDate, 'locative')) + '</span>';
      var maxLine = '<span class="inventory-sales-summary-line-label">Max</span><span class="inventory-sales-summary-line-value"><strong>' + summary.maxValue + ' ' + escapeHtml(t('salesUnits')) + '</strong> w ' + escapeHtml(formatSalesMonthName(summary.maxMonthDate, 'locative')) + '</span>';
      var avgLine = '<span class="inventory-sales-summary-line-label">Średnio</span><span class="inventory-sales-summary-line-value"><strong>' + escapeHtml(averageLabel) + ' ' + escapeHtml(t('salesUnits')) + '</strong> w miesiącu</span>';

      return '' +
        '<div class="inventory-sales-summary-card">' +
          '<div class="inventory-sales-summary-value"><span class="inventory-sales-summary-label">' + escapeHtml(String(summary.year)) + '</span><span class="inventory-sales-summary-text">' + escapeHtml(title) + '</span></div>' +
          '<div class="inventory-sales-summary-note inventory-sales-summary-lines">' +
            '<div class="inventory-sales-summary-line">' + minLine + '</div>' +
            '<div class="inventory-sales-summary-line">' + maxLine + '</div>' +
            '<div class="inventory-sales-summary-line">' + avgLine + '</div>' +
          '</div>' +
        '</div>';
    }

    function destroySalesChart() {
      if (salesChartInstance && typeof salesChartInstance.destroy === 'function') {
        salesChartInstance.destroy();
      }

      salesChartInstance = null;
    }

    function renderSalesChart(months) {
      var canvas = document.getElementById('inventorySalesChartCanvas');
      if (!canvas || typeof Chart === 'undefined') {
        return;
      }

      destroySalesChart();

      var ctx = canvas.getContext('2d');
      var currentGradient = ctx.createLinearGradient(0, 0, 0, canvas.height || 220);
      currentGradient.addColorStop(0, 'rgba(66, 191, 220, 0.52)');
      currentGradient.addColorStop(0.5, 'rgba(66, 191, 220, 0.22)');
      currentGradient.addColorStop(1, 'rgba(66, 191, 220, 0.05)');
      var previousGradient = ctx.createLinearGradient(0, 0, 0, canvas.height || 220);
      previousGradient.addColorStop(0, 'rgba(224, 170, 40, 0.42)');
      previousGradient.addColorStop(0.5, 'rgba(224, 170, 40, 0.18)');
      previousGradient.addColorStop(1, 'rgba(224, 170, 40, 0.05)');

      salesChartInstance = new Chart(ctx, {
        type: 'line',
        data: {
          labels: months.map(function (item) {
            return formatSalesMonthShort(item.month_date || item.month);
          }),
          datasets: [{
            label: String(salesModalState.previousYear || ''),
            data: months.map(function (item) {
              return Number(item.previous_quantity || 0);
            }),
            borderColor: 'rgba(224, 170, 40, 0.96)',
            backgroundColor: previousGradient,
            borderWidth: 2.5,
            fill: true,
            tension: 0.34,
            pointRadius: 3,
            pointHoverRadius: 4,
            pointBackgroundColor: '#ffffff',
            pointBorderColor: 'rgba(224, 170, 40, 0.96)',
            pointBorderWidth: 3,
            pointHoverBackgroundColor: '#ffffff',
            pointHoverBorderColor: 'rgba(255, 216, 128, 1)'
          }, {
            label: String(salesModalState.selectedYear || ''),
            data: months.map(function (item) {
              return Number(item.quantity || 0);
            }),
            borderColor: '#42bfdc',
            backgroundColor: currentGradient,
            borderWidth: 3,
            fill: true,
            tension: 0.38,
            pointRadius: 3.5,
            pointHoverRadius: 4.5,
            pointBackgroundColor: '#ffffff',
            pointBorderColor: '#42bfdc',
            pointBorderWidth: 3,
            pointHoverBackgroundColor: '#ffffff',
            pointHoverBorderColor: '#42bfdc'
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          animation: {
            duration: 380,
            easing: 'easeOutCubic'
          },
          interaction: {
            mode: 'index',
            intersect: false
          },
          plugins: {
            legend: {
              display: true,
              position: 'top',
              align: 'start',
              labels: {
                color: 'rgba(28, 63, 82, 0.78)',
                usePointStyle: true,
                pointStyle: 'circle',
                boxWidth: 10,
                boxHeight: 10,
                padding: 20,
                font: {
                  size: 13,
                  weight: '700'
                }
              }
            },
            tooltip: {
              displayColors: false,
              backgroundColor: 'rgba(255, 255, 255, 0.98)',
              titleColor: '#1b3b4d',
              bodyColor: '#35586b',
              borderColor: 'rgba(194, 214, 229, 0.9)',
              borderWidth: 1,
              padding: 12,
              callbacks: {
                title: function () {
                  return '';
                },
                label: function (context) {
                  var item = months[context.dataIndex] || {};
                  var monthDate = context.datasetIndex === 0
                    ? String(salesModalState.previousYear || '') + '-' + String(context.dataIndex + 1).padStart(2, '0') + '-01'
                    : (item.month_date || item.month || (String(salesModalState.selectedYear || '') + '-' + String(context.dataIndex + 1).padStart(2, '0') + '-01'));

                  return formatSalesMonth(monthDate) + ': ' + String(context.parsed.y || 0) + ' ' + t('salesUnits');
                }
              }
            }
          },
          scales: {
            x: {
              grid: {
                color: 'rgba(188, 210, 225, 0.3)',
                drawTicks: false
              },
              border: {
                display: false
              },
              ticks: {
                color: 'rgba(70, 103, 123, 0.8)',
                maxRotation: 0,
                autoSkip: false,
                font: {
                  size: 10,
                  weight: '600'
                }
              }
            },
            y: {
              beginAtZero: true,
              grace: '10%',
              border: {
                display: false
              },
              grid: {
                color: 'rgba(188, 210, 225, 0.58)',
                drawTicks: false
              },
              ticks: {
                precision: 0,
                color: 'rgba(82, 113, 131, 0.78)',
                font: {
                  size: 9,
                  weight: '600'
                }
              }
            }
          }
        }
      });
    }

    function setSalesModalState(message, visible) {
      var state = document.getElementById('inventorySalesModalState');
      state.textContent = message || '';
      state.classList.toggle('is-visible', !!visible);
    }

    function setSalesModalContent(html, visible) {
      var content = document.getElementById('inventorySalesModalContent');
      content.innerHTML = html || '';
      content.classList.toggle('is-visible', !!visible);
    }

    function updateSalesModalNav() {
      var prev = document.querySelector('.inventory-sales-nav-prev');
      var next = document.querySelector('.inventory-sales-nav-next');
      if (!prev || !next) {
        return;
      }

      prev.classList.toggle('is-disabled', false);
      next.classList.toggle('is-disabled', salesModalState.offsetMonths <= 0);
    }

    function updateSalesModalHeading() {
      document.getElementById('inventorySalesModalTitle').textContent = salesModalState.productName || '';
      document.getElementById('inventorySalesModalSubtitle').textContent = salesModalState.combinationName || '';
    }

    function closeSalesModal() {
      var modal = document.getElementById('inventorySalesModal');
      var modalImage = document.getElementById('inventorySalesModalImage');
      var modalFallback = document.getElementById('inventorySalesModalImageFallback');
      document.getElementById('inventorySalesModalTitle').textContent = '';
      document.getElementById('inventorySalesModalSubtitle').textContent = '';
      destroySalesChart();
      modalImage.setAttribute('src', '');
      modalImage.classList.remove('is-hidden');
      modalFallback.classList.remove('is-visible');
      modal.classList.remove('is-open');
      modal.setAttribute('aria-hidden', 'true');
      setSalesModalState('', false);
      setSalesModalContent('', false);
    }

    function openSalesModal() {
      var modal = document.getElementById('inventorySalesModal');
      var modalImage = document.getElementById('inventorySalesModalImage');
      var modalFallback = document.getElementById('inventorySalesModalImageFallback');
      updateSalesModalHeading();
      if (salesModalState.imageSrc) {
        modalImage.setAttribute('src', salesModalState.imageSrc);
        modalImage.classList.remove('is-hidden');
        modalFallback.classList.remove('is-visible');
      } else {
        modalImage.setAttribute('src', '');
        modalImage.classList.add('is-hidden');
        modalFallback.classList.add('is-visible');
      }
      modal.classList.add('is-open');
      modal.setAttribute('aria-hidden', 'false');
      updateSalesModalNav();
      setSalesModalState(t('salesStatsLoading'), true);
      setSalesModalContent('', false);
    }

    function fetchSalesStats() {
      openSalesModal();

      $.post(window.prestashopInventoryConfig.ajaxUrl + '&action=GetSalesStats', {
        id_product: salesModalState.productId,
        id_product_attribute: salesModalState.productAttributeId,
        months: salesModalState.months,
        offset_months: salesModalState.offsetMonths
      }, null, 'json').done(function (resp) {
        if (!resp || !resp.ok || !resp.stats) {
          setSalesModalState(resp && resp.error ? resp.error : t('errorSalesStats'), true);
          setSalesModalContent('', false);
          return;
        }

        renderSalesStats(salesModalState.productName, resp.stats);
        updateSalesModalNav();
      }).fail(function (xhr) {
        var error = xhr.responseJSON && xhr.responseJSON.error ? xhr.responseJSON.error : t('errorSalesStats');
        setSalesModalState(error, true);
        setSalesModalContent('', false);
      });
    }

    function renderSalesStats(productName, stats) {
      var months = stats && stats.months ? stats.months : [];
      var comparison = stats && stats.comparison ? stats.comparison : {};
      var rangeLabel = '—';
      var yearLabel = '—';

      if (!months.length) {
        setSalesModalState(t('salesStatsEmpty'), true);
        setSalesModalContent('', false);
        return;
      }

      salesModalState.selectedYear = Number(comparison.current_year || 0);
      salesModalState.previousYear = Number(comparison.previous_year || 0);
      rangeLabel = 'Porównanie roczne';
      yearLabel = String(comparison.current_year || '—') + ' / ' + String(comparison.previous_year || '—');
      var currentSummary = buildYearSummary(salesModalState.selectedYear, months.map(function (item) {
        return Number(item.quantity || 0);
      }));
      var previousSummary = buildYearSummary(salesModalState.previousYear, months.map(function (item) {
        return Number(item.previous_quantity || 0);
      }));

      var html = '' +
        '<div class="inventory-sales-summary">' +
          renderYearSummaryCard(previousSummary) +
          renderYearSummaryCard(currentSummary) +
        '</div>' +
        '<div class="inventory-sales-chart">' +
          '<div class="inventory-sales-chart-layout">' +
            '<button type="button" class="inventory-sales-nav inventory-sales-nav-prev" aria-label="' + escapeHtml(t('previousYear')) + '" title="' + escapeHtml(t('previousYear')) + '">' +
              '<span aria-hidden="true">&#8249;</span>' +
            '</button>' +
            '<div class="inventory-sales-chart-panel">' +
              '<div class="inventory-sales-chart-meta">' +
                '<div class="inventory-sales-chart-range">' + escapeHtml(rangeLabel) + '</div>' +
                '<div class="inventory-sales-chart-year">' + escapeHtml(yearLabel) + '</div>' +
              '</div>' +
              '<div class="inventory-sales-chart-surface">' +
                '<div class="inventory-sales-chart-canvas"><canvas id="inventorySalesChartCanvas"></canvas></div>' +
                '<div class="inventory-sales-chart-footnote">' + escapeHtml(productName) + '</div>' +
              '</div>' +
            '</div>' +
            '<button type="button" class="inventory-sales-nav inventory-sales-nav-next" aria-label="' + escapeHtml(t('nextYear')) + '" title="' + escapeHtml(t('nextYear')) + '">' +
              '<span aria-hidden="true">&#8250;</span>' +
            '</button>' +
          '</div>' +
        '</div>';

      updateSalesModalHeading();
      setSalesModalState('', false);
      setSalesModalContent(html, true);
      renderSalesChart(months);
    }

    $(document).ready(function () {
      var savedQuery = localStorage.getItem(LS_QUERY) || '';
      var savedActiveOnly = localStorage.getItem(LS_ACTIVE_ONLY) === '1';
      var savedOnly = localStorage.getItem(LS_ONLY) === '1';
      var savedMissingPurchaseOnly = localStorage.getItem(LS_MISSING_PURCHASE) === '1';
      var savedShowWeight = localStorage.getItem(LS_SHOW_WEIGHT) !== '0';
      var savedMissingWeightOnly = localStorage.getItem(LS_MISSING_WEIGHT) === '1';
      var savedBrutto = localStorage.getItem(LS_BRUTTO) !== '0';

      applyLanguage();
      renderSortState();

      setSearchKeywords(parseKeywords(savedQuery));
      $('#activeOnly').prop('checked', savedActiveOnly);
      $('#onlyAvailable').prop('checked', savedOnly);
      $('#missingPurchasePriceOnly').prop('checked', savedMissingPurchaseOnly);
      $('#showWeight').prop('checked', savedShowWeight);
      $('#missingWeightOnly').prop('checked', savedMissingWeightOnly);
      $('#showBrutto').prop('checked', savedBrutto);
      updateFilterBadge();
      toggleWeightColumns(savedShowWeight, false);
      toggleBruttoColumns(savedBrutto, false);
      $('.inventory-sales-modal-close').attr('aria-label', t('close'));

      $('#searchBox').on('click', function () {
        $('#searchInput').trigger('focus');
      });

      $('#searchInput').on('keydown', function (e) {
        if (e.key === 'Enter') {
          e.preventDefault();
          appendKeywordsFromInput();
          return;
        }

        if (e.key === 'Backspace' && !this.value) {
          var keywords = getSearchKeywords();
          if (keywords.length) {
            keywords.pop();
            persistAndLoadKeywords(keywords);
          }
        }
      });

      $('#activeOnly').on('change', function () {
        localStorage.setItem(LS_ACTIVE_ONLY, this.checked ? '1' : '0');
        updateFilterBadge();
        currentPage = 1;
        localStorage.setItem(LS_PAGE, String(currentPage));
        loadTable(getSearchQuery(), this.checked, $('#onlyAvailable').is(':checked'), $('#missingPurchasePriceOnly').is(':checked'), $('#missingWeightOnly').is(':checked'));
      });

      $('#onlyAvailable').on('change', function () {
        localStorage.setItem(LS_ONLY, this.checked ? '1' : '0');
        updateFilterBadge();
        currentPage = 1;
        localStorage.setItem(LS_PAGE, String(currentPage));
        loadTable(getSearchQuery(), $('#activeOnly').is(':checked'), this.checked, $('#missingPurchasePriceOnly').is(':checked'), $('#missingWeightOnly').is(':checked'));
      });

      $('#missingPurchasePriceOnly').on('change', function () {
        localStorage.setItem(LS_MISSING_PURCHASE, this.checked ? '1' : '0');
        updateFilterBadge();
        currentPage = 1;
        localStorage.setItem(LS_PAGE, String(currentPage));
        loadTable(getSearchQuery(), $('#activeOnly').is(':checked'), $('#onlyAvailable').is(':checked'), this.checked, $('#missingWeightOnly').is(':checked'));
      });

      $('#showWeight').on('change', function () {
        localStorage.setItem(LS_SHOW_WEIGHT, this.checked ? '1' : '0');
        updateFilterBadge();
        toggleWeightColumns(this.checked);
      });

      $('#missingWeightOnly').on('change', function () {
        localStorage.setItem(LS_MISSING_WEIGHT, this.checked ? '1' : '0');
        updateFilterBadge();
        currentPage = 1;
        localStorage.setItem(LS_PAGE, String(currentPage));
        loadTable(getSearchQuery(), $('#activeOnly').is(':checked'), $('#onlyAvailable').is(':checked'), $('#missingPurchasePriceOnly').is(':checked'), this.checked);
      });

      $('#showBrutto').on('change', function () {
        localStorage.setItem(LS_BRUTTO, this.checked ? '1' : '0');
        updateFilterBadge();
        toggleBruttoColumns(this.checked);
      });

      $(document).on('click', '.inventory-sortable .inventory-sort-button', function () {
        var field = $(this).closest('.inventory-sortable').data('sort-field');
        if (!field) {
          return;
        }

        if (currentSortField === field) {
          currentSortDir = currentSortDir === 'ASC' ? 'DESC' : 'ASC';
        } else {
          currentSortField = field;
          currentSortDir = 'ASC';
        }

        localStorage.setItem(LS_SORT_FIELD, currentSortField);
        localStorage.setItem(LS_SORT_DIR, currentSortDir);
        renderSortState();
        loadTable(getSearchQuery(), $('#activeOnly').is(':checked'), $('#onlyAvailable').is(':checked'), $('#missingPurchasePriceOnly').is(':checked'), $('#missingWeightOnly').is(':checked'));
      });

      $(document).on('click', '.inventory-tag-remove', function () {
        var keywords = getSearchKeywords();
        var index = Number($(this).attr('data-index'));
        keywords.splice(index, 1);
        persistAndLoadKeywords(keywords);
      });

      $('#clearSearch').on('click', function () {
        $('#searchInput').val('');
        setSearchKeywords([]);
        localStorage.setItem(LS_QUERY, '');
        currentPage = 1;
        localStorage.setItem(LS_PAGE, String(currentPage));
        loadTable('', $('#activeOnly').is(':checked'), $('#onlyAvailable').is(':checked'), $('#missingPurchasePriceOnly').is(':checked'), $('#missingWeightOnly').is(':checked'));
      });

      $('#btnPdf').on('click', function () {
        appendKeywordsFromInput();
        var q = getSearchQuery();
        var activeOnly = $('#activeOnly').is(':checked') ? '1' : '0';
        var only = $('#onlyAvailable').is(':checked') ? '1' : '0';
        var missingPurchasePriceOnly = $('#missingPurchasePriceOnly').is(':checked') ? '1' : '0';
        var showWeight = $('#showWeight').is(':checked') ? '1' : '0';
        var missingWeightOnly = $('#missingWeightOnly').is(':checked') ? '1' : '0';
        var showBrutto = $('#showBrutto').is(':checked') ? '1' : '0';
        window.location.href = window.prestashopInventoryConfig.exportUrl + '&lang=' + encodeURIComponent(window.prestashopInventoryConfig.languageIso || 'en') + '&activeOnly=' + encodeURIComponent(activeOnly) + '&onlyAvailable=' + encodeURIComponent(only) + '&missingPurchasePriceOnly=' + encodeURIComponent(missingPurchasePriceOnly) + '&showWeight=' + encodeURIComponent(showWeight) + '&missingWeightOnly=' + encodeURIComponent(missingWeightOnly) + '&showBrutto=' + encodeURIComponent(showBrutto) + '&query=' + encodeURIComponent(q);
      });

      function closeInlineEditor($td) {
        $td.find('.price-editor, .qty-editor, .weight-editor').remove();
        $td.find('.editable-price, .editable-retail-price, .editable-quantity, .editable-weight').show();
      }

      function focusEditorInput($td, selector) {
        window.setTimeout(function () {
          var $input = $td.find(selector).first();
          if ($input.length) {
            $input.trigger('focus');
            $input.select();
          }
        }, 0);
      }

      function startInlineEditor($el, editorClass, inputHtml) {
        var $td = $el.closest('td');
        if ($td.find('.price-editor, .qty-editor, .weight-editor').length) {
          return;
        }

        $el.hide().after('<div class="' + editorClass + ' inline-editor">' + inputHtml + '</div>');
      }

      function submitPrice($input, isRetail) {
        var $td = $input.closest('td');
        var $editor = $input.closest('.price-editor');
        var $el = $td.find(isRetail ? '.editable-retail-price' : '.editable-price');
        var priceVal = $input.val().trim();

        if ($editor.data('isSubmitting')) {
          return;
        }

        if (!priceVal) {
          alert(t('typePrice'));
          focusEditorInput($td, '.price-input');
          return;
        }

        $editor.data('isSubmitting', true);
        $input.prop('disabled', true);

        $.post(window.prestashopInventoryConfig.ajaxUrl + '&action=' + (isRetail ? 'SaveRetailPrice' : 'SavePrice'), {
          id_product: $el.data('id-product'),
          id_product_attribute: $el.data('id-attr'),
          price: priceVal
        }, null, 'json').done(function (resp) {
          if (!resp || !resp.ok) {
            alert(resp && resp.error ? resp.error : t('errorSave'));
            $editor.data('isSubmitting', false);
            $input.prop('disabled', false);
            focusEditorInput($td, '.price-input');
            return;
          }

          var priceNumber = Number(resp.price || 0);
          $el.text(priceNumber.toFixed(2).replace('.', ',') + ' zł').removeClass('text-danger').attr('data-current-price', priceNumber.toFixed(2));
          closeInlineEditor($td);
          loadTable(getSearchQuery(), $('#activeOnly').is(':checked'), $('#onlyAvailable').is(':checked'), $('#missingPurchasePriceOnly').is(':checked'), $('#missingWeightOnly').is(':checked'));
        }).fail(function (xhr) {
          var error = xhr.responseJSON && xhr.responseJSON.error ? xhr.responseJSON.error : t('errorNetwork');
          alert(error);
          $editor.data('isSubmitting', false);
          $input.prop('disabled', false);
          focusEditorInput($td, '.price-input');
        });
      }

      function submitQuantity($input) {
        var $td = $input.closest('td');
        var $editor = $input.closest('.qty-editor');
        var $el = $td.find('.editable-quantity');
        var quantityVal = $input.val().trim();

        if ($editor.data('isSubmitting')) {
          return;
        }

        if (!/^-?\d+$/.test(quantityVal)) {
          alert(t('typeQty'));
          focusEditorInput($td, '.qty-input');
          return;
        }

        $editor.data('isSubmitting', true);
        $input.prop('disabled', true);

        $.post(window.prestashopInventoryConfig.ajaxUrl + '&action=SaveQuantity', {
          id_product: $el.data('id-product'),
          id_product_attribute: $el.data('id-attr'),
          quantity: quantityVal
        }, null, 'json').done(function (resp) {
          if (!resp || !resp.ok) {
            alert(resp && resp.error ? resp.error : t('errorQtySave'));
            $editor.data('isSubmitting', false);
            $input.prop('disabled', false);
            focusEditorInput($td, '.qty-input');
            return;
          }

          var quantityNumber = parseInt(resp.quantity, 10) || 0;
          $el.text(String(quantityNumber)).attr('data-current-qty', String(quantityNumber));
          closeInlineEditor($td);
          loadTable(getSearchQuery(), $('#activeOnly').is(':checked'), $('#onlyAvailable').is(':checked'), $('#missingPurchasePriceOnly').is(':checked'), $('#missingWeightOnly').is(':checked'));
        }).fail(function (xhr) {
          var error = xhr.responseJSON && xhr.responseJSON.error ? xhr.responseJSON.error : t('errorQtySave');
          alert(error);
          $editor.data('isSubmitting', false);
          $input.prop('disabled', false);
          focusEditorInput($td, '.qty-input');
        });
      }

      function submitWeight($input) {
        var $td = $input.closest('td');
        var $editor = $input.closest('.weight-editor');
        var $el = $td.find('.editable-weight');
        var weightVal = $input.val().trim();

        if ($editor.data('isSubmitting')) {
          return;
        }

        if (!weightVal || isNaN(Number(weightVal)) || Number(weightVal) < 0) {
          alert(t('typeWeight'));
          focusEditorInput($td, '.weight-input');
          return;
        }

        $editor.data('isSubmitting', true);
        $input.prop('disabled', true);

        $.post(window.prestashopInventoryConfig.ajaxUrl + '&action=SaveWeight', {
          id_product: $el.data('id-product'),
          id_product_attribute: $el.data('id-attr'),
          weight: weightVal
        }, null, 'json').done(function (resp) {
          if (!resp || !resp.ok) {
            alert(resp && resp.error ? resp.error : t('errorWeightSave'));
            $editor.data('isSubmitting', false);
            $input.prop('disabled', false);
            focusEditorInput($td, '.weight-input');
            return;
          }

          var weightNumber = Number(resp.weight || 0);
          var weightText = weightNumber > 0 ? weightNumber.toFixed(3).replace('.', ',') + ' kg' : '—';
          $el.text(weightText).attr('data-current-weight', weightNumber.toFixed(3)).toggleClass('text-danger', weightNumber <= 0);
          closeInlineEditor($td);
          loadTable(getSearchQuery(), $('#activeOnly').is(':checked'), $('#onlyAvailable').is(':checked'), $('#missingPurchasePriceOnly').is(':checked'), $('#missingWeightOnly').is(':checked'));
        }).fail(function (xhr) {
          var error = xhr.responseJSON && xhr.responseJSON.error ? xhr.responseJSON.error : t('errorWeightSave');
          alert(error);
          $editor.data('isSubmitting', false);
          $input.prop('disabled', false);
          focusEditorInput($td, '.weight-input');
        });
      }

      function submitInlineEditor($input) {
        if ($input.hasClass('qty-input')) {
          submitQuantity($input);
          return;
        }

        if ($input.hasClass('weight-input')) {
          submitWeight($input);
          return;
        }

        submitPrice($input, $input.closest('td').find('.editable-retail-price:hidden').length > 0);
      }

      $(document).on('click', '.editable-price', function () {
        if (!window.prestashopInventoryConfig.canEdit) {
          return;
        }

        var $el = $(this);
        startInlineEditor($el, 'price-editor', '<input type="text" class="form-control input-sm price-input inline-editor-input" placeholder="' + t('enterPrice') + '" value="' + (($el.data('current-price') || '').toString()) + '">');
        focusEditorInput($el.closest('td'), '.price-input');
      });

      $(document).on('click', '.editable-retail-price', function () {
        if (!window.prestashopInventoryConfig.canEdit) {
          return;
        }

        var $el = $(this);
        startInlineEditor($el, 'price-editor', '<input type="text" class="form-control input-sm price-input inline-editor-input" placeholder="' + t('enterRetailPrice') + '" value="' + (($el.data('current-price') || '').toString()) + '">');
        focusEditorInput($el.closest('td'), '.price-input');
      });

      $(document).on('click', '.editable-quantity', function () {
        if (!window.prestashopInventoryConfig.canEdit) {
          return;
        }

        var $el = $(this);
        startInlineEditor($el, 'qty-editor', '<input type="number" step="1" class="form-control input-sm qty-input inline-editor-input" placeholder="' + t('enterQty') + '" value="' + (($el.data('current-qty') || '').toString()) + '">');
        focusEditorInput($el.closest('td'), '.qty-input');
      });

      $(document).on('click', '.editable-weight', function () {
        if (!window.prestashopInventoryConfig.canEdit) {
          return;
        }

        var $el = $(this);
        startInlineEditor($el, 'weight-editor', '<input type="number" step="0.001" min="0" class="form-control input-sm weight-input inline-editor-input" placeholder="' + t('enterWeight') + '" value="' + (($el.data('current-weight') || '').toString()) + '">');
        focusEditorInput($el.closest('td'), '.weight-input');
      });

      $(document).on('keydown', '.price-input, .qty-input, .weight-input', function (e) {
        if (e.key === 'Enter') {
          e.preventDefault();
          $(this).data('skipBlurSubmit', true);
          submitInlineEditor($(this));
          return;
        }

        if (e.key === 'Escape') {
          e.preventDefault();
          $(this).data('skipBlurSubmit', true);
          closeInlineEditor($(this).closest('td'));
        }
      });

      $(document).on('blur', '.price-input, .qty-input, .weight-input', function () {
        var $input = $(this);

        if ($input.data('skipBlurSubmit')) {
          $input.removeData('skipBlurSubmit');
          return;
        }

        window.setTimeout(function () {
          if (!$input.closest('body').length || !$input.is(':visible')) {
            return;
          }

          submitInlineEditor($input);
        }, 0);
      });

      $(document).on('change', '.toggle-product-active', function () {
        if (!window.prestashopInventoryConfig.canEdit) {
          this.checked = !this.checked;
          return;
        }

        var checkbox = this;
        var $checkbox = $(checkbox);
        var nextValue = checkbox.checked ? 1 : 0;

        $checkbox.prop('disabled', true);

        $.post(window.prestashopInventoryConfig.ajaxUrl + '&action=ToggleProductActive', {
          id_product: $checkbox.data('id-product'),
          active: nextValue
        }, null, 'json').done(function (resp) {
          if (!resp || !resp.ok) {
            checkbox.checked = !checkbox.checked;
            alert(resp && resp.error ? resp.error : t('errorToggle'));
          } else {
            checkbox.checked = Number(resp.active) === 1;
          }
        }).fail(function (xhr) {
          checkbox.checked = !checkbox.checked;
          var error = xhr.responseJSON && xhr.responseJSON.error ? xhr.responseJSON.error : t('errorToggle');
          alert(error);
        }).always(function () {
          $checkbox.prop('disabled', false);
        });
      });

      $(document).on('click', '.copy-ean-btn', function () {
        var button = this;
        var $button = $(button);
        var ean = String($button.data('ean') || '');
        var originalText = $button.text();

        copyTextToClipboard(ean).then(function () {
          $button.addClass('is-copied').text(t('copied'));
          window.setTimeout(function () {
            $button.removeClass('is-copied').text(originalText);
          }, 900);
        }).catch(function () {
          alert(t('copyError'));
        });
      });

      $(document).on('click', '.inventory-sales-trigger', function (e) {
        e.preventDefault();
        e.stopPropagation();

        var $button = $(this);
        salesModalState.productId = parseInt($button.data('id-product') || '0', 10);
        salesModalState.productAttributeId = parseInt($button.data('id-attr') || '0', 10);
        salesModalState.productName = String($button.data('product-name') || t('salesStatsTitle'));
        salesModalState.combinationName = String($button.data('combination-name') || '');
        salesModalState.imageSrc = String($button.data('image-src') || '');
        salesModalState.months = 12;
        salesModalState.offsetMonths = 0;

        fetchSalesStats();
      });

      $(document).on('click', '.inventory-sales-nav-prev', function () {
        salesModalState.offsetMonths += 12;
        fetchSalesStats();
      });

      $(document).on('click', '.inventory-sales-nav-next', function () {
        if (salesModalState.offsetMonths <= 0) {
          return;
        }

        salesModalState.offsetMonths = Math.max(0, salesModalState.offsetMonths - 12);
        fetchSalesStats();
      });

      $(document).on('click', '.inventory-sales-modal-close, .inventory-sales-modal-backdrop', function () {
        closeSalesModal();
      });

      $(document).on('keydown', function (e) {
        if (e.key === 'Escape' && $('#inventorySalesModal').hasClass('is-open')) {
          closeSalesModal();
        }
      });

      $(document).on('click', '.inventory-actions-toggle', function (e) {
        e.preventDefault();
        e.stopPropagation();

        var $menu = $(this).closest('.inventory-actions-menu');
        $('.inventory-actions-menu').not($menu).removeClass('is-open').find('.inventory-actions-toggle').attr('aria-expanded', 'false');
        $menu.toggleClass('is-open');
        $(this).attr('aria-expanded', $menu.hasClass('is-open') ? 'true' : 'false');
      });

      $(document).on('click', function () {
        $('.inventory-actions-menu').removeClass('is-open').find('.inventory-actions-toggle').attr('aria-expanded', 'false');
      });

      $(document).on('click', '.inventory-actions-dropdown', function (e) {
        e.stopPropagation();
      });

      $(document).on('click', '.inventory-hide-product', function () {
        if (!window.prestashopInventoryConfig.canEdit) {
          return;
        }

        var $btn = $(this);
        var idProduct = parseInt($btn.data('id-product') || '0', 10);
        if (!idProduct) {
          return;
        }

        $btn.prop('disabled', true);

        $.post(window.prestashopInventoryConfig.ajaxUrl + '&action=HideProduct', {
          id_product: idProduct
        }, null, 'json').done(function (resp) {
          if (!resp || !resp.ok) {
            alert(resp && resp.error ? resp.error : t('errorHide'));
            $btn.prop('disabled', false);
            return;
          }

          loadTable(getSearchQuery(), $('#activeOnly').is(':checked'), $('#onlyAvailable').is(':checked'), $('#missingPurchasePriceOnly').is(':checked'), $('#missingWeightOnly').is(':checked'));
        }).fail(function (xhr) {
          var error = xhr.responseJSON && xhr.responseJSON.error ? xhr.responseJSON.error : t('errorHide');
          alert(error);
          $btn.prop('disabled', false);
        });
      });

      $(document).on('click', '.inventory-page-edge, .inventory-page-nav', function () {
        if (this.disabled) {
          return;
        }

        var page = parseInt($(this).attr('data-page') || '1', 10);
        currentPage = page > 0 ? page : 1;
        localStorage.setItem(LS_PAGE, String(currentPage));
        loadTable(getSearchQuery(), $('#activeOnly').is(':checked'), $('#onlyAvailable').is(':checked'), $('#missingPurchasePriceOnly').is(':checked'), $('#missingWeightOnly').is(':checked'));
      });

      $(document).on('change', '.inventory-per-page-select', function () {
        var perPage = parseInt(this.value || '20', 10);
        currentPerPage = [20, 50, 100, 200].indexOf(perPage) !== -1 ? perPage : 20;
        currentPage = 1;
        localStorage.setItem(LS_PER_PAGE, String(currentPerPage));
        localStorage.setItem(LS_PAGE, String(currentPage));
        loadTable(getSearchQuery(), $('#activeOnly').is(':checked'), $('#onlyAvailable').is(':checked'), $('#missingPurchasePriceOnly').is(':checked'), $('#missingWeightOnly').is(':checked'));
      });

      function applyCurrentPageInput(input) {
        var min = parseInt(input.getAttribute('min') || '1', 10);
        var max = parseInt(input.getAttribute('max') || '1', 10);
        var page = parseInt(input.value || String(currentPage), 10);

        if (isNaN(page)) {
          page = currentPage;
        }

        page = Math.max(min, Math.min(max, page));
        input.value = String(page);

        if (page === currentPage) {
          return;
        }

        currentPage = page;
        localStorage.setItem(LS_PAGE, String(currentPage));
        loadTable(getSearchQuery(), $('#activeOnly').is(':checked'), $('#onlyAvailable').is(':checked'), $('#missingPurchasePriceOnly').is(':checked'), $('#missingWeightOnly').is(':checked'));
      }

      $(document).on('keydown', '.inventory-page-current', function (e) {
        if (e.key === 'Enter') {
          e.preventDefault();
          applyCurrentPageInput(this);
        }
      });

      $(document).on('change', '.inventory-page-current', function () {
        applyCurrentPageInput(this);
      });

      loadTable(getSearchQuery(), savedActiveOnly, savedOnly, savedMissingPurchaseOnly, savedMissingWeightOnly);
    });
  })();
</script>
