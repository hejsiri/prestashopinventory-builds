<?php
declare(strict_types=1);

namespace PrestaShop\Module\PrestashopInventory\Controller\Admin;

use PrestaShopBundle\Controller\Admin\FrameworkBundleAdminController;
use Symfony\Contracts\Translation\TranslatorInterface;
use Twig\Markup;

abstract class AbstractInventoryController extends FrameworkBundleAdminController
{
    private TranslatorInterface $translator;

    public function __construct(TranslatorInterface $translator)
    {
        $this->translator = $translator;
    }

    protected function buildHeaderTabContent(string $currentRoute): array|string
    {
        $tabsMarkup = $this->renderView('@Modules/prestashopinventory/views/templates/admin-modern/_head_tabs.html.twig', [
            'currentRoute' => $currentRoute,
        ]);

        if (version_compare(_PS_VERSION_, '9.0.0', '>=')) {
            return [new Markup($tabsMarkup, 'UTF-8')];
        }

        return $tabsMarkup;
    }

    protected function translate(string $message): string
    {
        return $this->translator->trans($message, [], 'Modules.Prestashopinventory.Admin');
    }

    protected function renderInventoryPage(string $template, string $currentRoute, string $sectionLabel, array $extra = [])
    {
        return $this->render($template, array_merge($extra, [
            'layoutTitle' => $this->translate('Inventory'),
            'headerTabContent' => $this->buildHeaderTabContent($currentRoute),
            'inventoryCurrentSectionLabel' => $this->translate($sectionLabel),
            'moduleVersion' => '0.1.86',
        ]));
    }
}
